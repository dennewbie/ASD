//
//  Graph.hpp
//  esercizio_18_3_Laboratorio
//
//  Created by Denny Caruso on 27/11/2020.
//

#ifndef Graph_hpp
#define Graph_hpp

#include <iostream>
#include <stack>
#include <queue>
#include <vector>
#include <map>
#include <algorithm>
#include "Node.hpp"

template <class T> class Graph {
private:
    std::vector<Node<T> *> * nodes;
    std::vector<Node<T> *> * getNodes();
    unsigned int time = 0;
    
    
    void DFS_visit(Node<T> * u);
    void DFS_visitTopologicalOrder(Node<T> * u, std::stack<Node<T> *> * inputStack);
    Graph<T> getTransposedGraph();
public:
    Graph() {
        this->nodes = new std::vector<Node<T> *>;
    }
    
    void addNode(Node<T> * nodeToAdd);
    Node<T> * getNodeAtIndex(unsigned int index);
    // qui forse va ritornato per valore e non per indirizzo ---> OOP
    
    void printAdjacentList();
    
    void BFS_iterative(Node<T> * root);
    void BFS_recursive(std::queue<Node<T> *> * inputQueue);
    void DFS_iterative();
    void DFS_recursive();
    
    std::stack<Node<T> *> getTopologicalOrderStack();
    
    std::vector<Node<T> *> getStrongConnectedComponents();
    void resetNodesProperties();
   
};

template <class T> std::vector<Node<T> *> * Graph<T>::getNodes() {
    return this->nodes;
}

template <class T> void Graph<T>::addNode(Node<T> * nodeToAdd) {
    this->nodes->push_back(nodeToAdd);
}

template <class T> Node<T> * Graph<T>::getNodeAtIndex(unsigned int index) {
    return this->nodes->at(index);
}

template <class T> void Graph<T>::printAdjacentList() {
    for(auto singleNode: *(getNodes())) {
        std::cout << "Adj(" << singleNode->getData() << "): ";
        
        for (auto adjacentNode: *(singleNode->getAdjacentList())) std::cout << "  " << adjacentNode->getData();
        std::cout << std::endl;
    }
}

template <class T> void Graph<T>::BFS_iterative(Node<T> * root) {
    resetNodesProperties();
    root->setParent(nullptr);
    root->setColor(GRAY);
    root->set_dTime(0);
    
    std::queue<Node<T> *> queueBFS;
//    std::cout << "\n" << root->getData();
    
    queueBFS.push(root);
    while (!queueBFS.empty()) {
        Node<T> * u = queueBFS.front();
        queueBFS.pop();
        
        for (auto & adjacentNodeToU: *(u->getAdjacentList())) {
            if (adjacentNodeToU->getColor() == WHITE) {
//                std::cout << "\n" << adjacentNodeToU->getData();
                adjacentNodeToU->setColor(GRAY);
                adjacentNodeToU->setParent(u);
                adjacentNodeToU->set_dTime(u->get_dTime() + 1);
                queueBFS.push(adjacentNodeToU);
            }
        }
        
        u->setColor(BLACK);
    }
    
    std::cout << "\n\n";
}

template <class T> void Graph<T>::BFS_recursive(std::queue<Node<T> *> * inputQueue) {
    if (!inputQueue->empty()) {
        Node <T> * u = inputQueue->front();
        inputQueue->pop();
        
        for (auto & adjacentNodeToU: *(u->getAdjacentList())) {
            if (adjacentNodeToU->getColor() == WHITE) {
//                std::cout << "\n" << adjacentNodeToU->getData();
                adjacentNodeToU->setColor(GRAY);
                adjacentNodeToU->setParent(u);
                adjacentNodeToU->set_dTime(u->get_dTime() + 1);
                inputQueue->push(adjacentNodeToU);
            }
        }
        u->setColor(BLACK);
        BFS_recursive(inputQueue);
    }
}

template <class T> void Graph<T>::DFS_iterative() {
    std::stack<Node<T> *> stackDFS;
    resetNodesProperties();
    stackDFS.push(getNodeAtIndex(0));
  
    while (!stackDFS.empty()) {
        Node <T> *u = stackDFS.top();
        stackDFS.pop();
  
        // Stack may contain same vertex twice. So need to print the popped item only if it is not visited.
        if (u->getColor() == WHITE) {
//            std::cout << u->getData() << "\n";
            u->setColor(GRAY);
        }
  
        // Get all adjacent vertices of the popped vertex s. If a adjacent has not been visited, then push it to the stack.
        for (auto & adjacentNodeToU: *(u->getAdjacentList())) {
            if (adjacentNodeToU->getColor() == WHITE) {
                stackDFS.push(adjacentNodeToU);
            }
        }
        u->setColor(BLACK);
    }
    
    time = 0;
    //    std::cout << "\n\n";
}

template <class T> void Graph<T>::DFS_recursive() {
    resetNodesProperties();
    
    for (auto & singleNode: *(getNodes())) {
        if (singleNode->getColor() == WHITE) DFS_visit(singleNode);
    }
    
    time = 0;
//    std::cout << "\n\n";
}

template <class T> void Graph<T>::DFS_visit(Node<T> * u) {
//    static unsigned int time = 0;
    u->setColor(GRAY);
    u->set_dTime(time++);
    
    for (auto & adjacentNodeToU: *(u->getAdjacentList())) {
        if (adjacentNodeToU->getColor() == WHITE) {
//            std::cout << "\n" << adjacentNodeToU->getData();
            adjacentNodeToU->setParent(u);
            DFS_visit(adjacentNodeToU);
        }
    }
    
    u->setColor(BLACK);
    u->set_fTime(time++);
}

template <class T> void Graph<T>::resetNodesProperties() {
    for (auto & node: *(getNodes())) node->resetNode();
}

template <class T> std::stack<Node<T> *> Graph<T>::getTopologicalOrderStack() {
    std::stack<Node<T> *> stackDFS_topologicalOrder;
    resetNodesProperties();
    
    for (auto & singleNode: *(getNodes())) {
        if (singleNode->getColor() == WHITE) {
            DFS_visitTopologicalOrder(singleNode, &stackDFS_topologicalOrder);
        }
    }
    
//    while (!stackDFS_topologicalOrder.empty()) {
//        std::cout << "\n" << stackDFS_topologicalOrder.top()->getData();
//        stackDFS_topologicalOrder.pop();
//    }
    
    time = 0;
    return stackDFS_topologicalOrder;
}

//O(V+E)
template <class T> void Graph<T>::DFS_visitTopologicalOrder(Node<T> * u, std::stack<Node<T> *> * inputStack) {
//    static unsigned int time = 0;
    u->setColor(GRAY);
    u->set_dTime(time++);
    
    for (auto & adjacentNodeToU: *(u->getAdjacentList())) {
        if (adjacentNodeToU->getColor() == WHITE) {
//            std::cout << "\n" << adjacentNodeToU->getData();
            adjacentNodeToU->setParent(u);
            DFS_visitTopologicalOrder(adjacentNodeToU, inputStack);
        }
    }
    
    u->setColor(BLACK);
    u->set_fTime(time++);
    inputStack->push(u);
}

//O(V+E)
template <class T> std::vector<Node<T> *> Graph<T>::getStrongConnectedComponents() {
    std::stack<Node<T> *> stackDFS_topologicalOrder;
    std::vector<Node<T> *> strongConnectedComponents;
    resetNodesProperties();
    
    for (auto & singleNode: *(getNodes())) {
        if (singleNode->getColor() == WHITE) {
            DFS_visitTopologicalOrder(singleNode, &stackDFS_topologicalOrder);
        }
    }
    
    //crea grafo trasposto gt
    Graph<T> transposedGraph = getTransposedGraph();
    
    while (!stackDFS_topologicalOrder.empty()) {
        Node<T> *v = stackDFS_topologicalOrder.top();
        stackDFS_topologicalOrder.pop();
        
        if (v->getColor() == WHITE) {
            transposedGraph.DFS_visit(v);
            strongConnectedComponents.push_back(v);
        }
    }
    
    transposedGraph = getTransposedGraph();
    time = 0;
    return strongConnectedComponents;
}

//O(V^2)
template <class T> Graph<T> Graph<T>::getTransposedGraph() {
    Graph<T> transposedGraph;
    std::map<T, int> nodesMap;
    std::vector<std::map<int, int>> reverseEdges;
    
    for (int i = 0; i < getNodes()->size(); i++) nodesMap[getNodes()->at(i)->getData()] = i;
    for(auto singleNode: *(getNodes())) transposedGraph.addNode(singleNode);
    
    transposedGraph.resetNodesProperties();
    
    for (auto i = 0; i < transposedGraph.getNodes()->size(); i++) {
        for (auto it = transposedGraph.getNodes()->at(i)->getAdjacentList()->begin(); it != transposedGraph.getNodes()->at(i)->getAdjacentList()->end(); it++) {
            std::map<int, int> firstIndexSecondIndex;
            firstIndexSecondIndex[nodesMap[(*it)->getData()]] = i;
            reverseEdges.push_back(firstIndexSecondIndex);
        }
    }
    
    for (int i = 0; i < transposedGraph.getNodes()->size(); i++) transposedGraph.getNodes()->at(i)->getAdjacentList()->clear();
    
    for (int i = 0; i < reverseEdges.size(); i++) {
        for (auto it: reverseEdges[i]) {
            transposedGraph.getNodeAtIndex(it.first)->addEdge(transposedGraph.getNodeAtIndex(it.second));
        }
    }
    
    return transposedGraph;
}

#endif /* Graph_hpp */
