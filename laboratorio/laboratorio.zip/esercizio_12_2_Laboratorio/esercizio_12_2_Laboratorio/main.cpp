//
//  main.cpp
//  esercizio_12_1_Laboratorio
//
//  Created by Denny Caruso on 06/11/2020.
//

/*
    Progettare una classe Priority Queue che implementi una coda di priorità
    basata su Binary Search Tree
 */

#include "MinPriorityQueue.hpp"

int main(int argc, const char * argv[]) {
    MinPriorityQueue<float> minPQ;
    minPQ.insertNode(15, 3.00);
    minPQ.insertNode(10, 5.00);
    minPQ.insertNode(20, 6.00);
    minPQ.insertNode(13, 7.00);
    minPQ.insertNode( 8, 8.00);
    minPQ.insertNode(21, 11.00);
    minPQ.insertNode(18, 13.00);
    
    std::cout << "MINIMUM: " << minPQ.getMinimum() << "\n\n";
    minPQ.extractMinimum();
    std::cout << "MINIMUM: " << minPQ.getMinimum() << "\n\n";
    
    minPQ.extractMinimum();
    minPQ.extractMinimum();
    minPQ.decreasePriorityAt(21, 4);
    minPQ.extractMinimum();
    minPQ.extractMinimum();
    minPQ.extractMinimum();
    minPQ.extractMinimum();
    
    return 0;
}
