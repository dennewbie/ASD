//
//  MinPriorityQueue.hpp
//  esercizio_10_2_Laboratorio
//
//  Created by Denny Caruso on 30/10/2020.
//

#ifndef MinPriorityQueue_hpp
#define MinPriorityQueue_hpp

#include "BinarySearchTree.hpp"

template <class T> class MinPriorityQueue: private BinarySearchTree<T> {
private:
    
public:
    MinPriorityQueue() {
        BinarySearchTree<T>();
    }
    
    virtual ~MinPriorityQueue() { }
    
    T getMinimum();
    bool extractMinimum();
    void insertNode(int key, T newNode);
    bool decreasePriorityAt(int oldKey, int newkey);
};

template <class T> T MinPriorityQueue<T>::getMinimum() {
    return (this->BinarySearchTree<T>::getMinimum(this->getRoot())->getKey());
}

template <class T> bool MinPriorityQueue<T>::extractMinimum() {
    if (this->getRoot() == nullptr) return false;
//    T min = (this->BinarySearchTree<T>::getMinimum(this->getRoot())->getData());
    std::cout << "Extract Node with Priority: \n" << (this->BinarySearchTree<T>::getMinimum(this->getRoot())->getKey()) << "\n";
    
    this->deleteNode((this->BinarySearchTree<T>::getMinimum(this->getRoot()))->getKey());
    return true;
}

template <class T> void MinPriorityQueue<T>::insertNode(int key, T newNode) {
    this->BinarySearchTree<T>::insertNode(key, newNode);
}

template <class T> bool MinPriorityQueue<T>::decreasePriorityAt(int oldKey, int newKey) {
    Node<T> * current = this->searchNode(oldKey, this->getRoot());
    if (current == nullptr) return false;
    if (newKey > current->getKey()) return false;
    
    this->deleteNode(current->getKey());
    this->BinarySearchTree<T>::insertNode(newKey, current->getData());
    return true;
}

#endif /* MinPriorityQueue_hpp */
