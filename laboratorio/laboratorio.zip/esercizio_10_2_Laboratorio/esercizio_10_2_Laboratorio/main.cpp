//
//  main.cpp
//  esercizio_10_2_Laboratorio
//
//  Created by Denny Caruso on 30/10/2020.
//

/*
 
 Progettare ed implementare una classe Priority-queue che implementi le seguenti operazioni:
    • Insert(S,x)
    • Maximum(S) / Minimum(S)
    • Extract-Max(S) / Extract-Min(S)
    • Increase-priority(S,x,k) / Decrease-priority(S,x,k)
 
 */

#include "MinPriorityQueue.hpp"

int main(int argc, const char * argv[]) {
    MinPriorityQueue<int> integerMinPriorityQueue = MinPriorityQueue<int>();
    
    integerMinPriorityQueue.insertNode(110);
    integerMinPriorityQueue.insertNode(109);
    integerMinPriorityQueue.insertNode(108);
    integerMinPriorityQueue.insertNode(107);
    integerMinPriorityQueue.insertNode(106);
    integerMinPriorityQueue.insertNode(105);
    integerMinPriorityQueue.insertNode(104);
    integerMinPriorityQueue.insertNode(103);
    
    
    integerMinPriorityQueue.extractMinimum();
    integerMinPriorityQueue.extractMinimum();
    integerMinPriorityQueue.extractMinimum();
    integerMinPriorityQueue.extractMinimum();
    
    integerMinPriorityQueue.decreasePriorityAt(100, 5);
    integerMinPriorityQueue.decreasePriorityAt(3, -5);
    
    integerMinPriorityQueue.extractMinimum();
    return 0;
}
