//
//  main.cpp
//  esercizio_9_1_2_Laboratorio
//
//  Created by Denny Caruso on 26/10/2020.
//

/*
 
 Progettare ed implementare una classe templata Min-Heap dotata delle seguenti operazioni:
    • Min-Heapify
    • Build-Min-Heap
    • Insert
    • PrintArray
    • (PrintAsciiTree)
 
 */

#include <iostream>
#include "MinHeap.hpp"

int main(int argc, const char * argv[]) {
    std::vector<int> testArray { 10, 1, 50, 80, 90, 100, 12, 23, 30, 11, 4, 1, 2 };
    MinHeap<int> integerHeap = MinHeap<int>(testArray);
    
    integerHeap.printHeap();
    integerHeap.buildMinHeap();
    integerHeap.printHeap();
    
    integerHeap.insert(101);
    integerHeap.printHeap();
    
    integerHeap.printHeapTree();
    integerHeap.heapSort();
    integerHeap.printHeap();
    integerHeap.printArray();
    
    return 0;
}
