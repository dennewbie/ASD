//
//  main.cpp
//  esercizio_21_3_Laboratorio
//
//  Created by Denny Caruso on 07/12/2020.
//

/*
    Si consideri il problema di trovare una via d'uscita in un labirinto data una posizione iniziale (es.: 0,0)
    ed una posizione finale (es.: N - 1, N - 1).
 
        • Il labirinto è rappresentato da una matrice di interi, in cui ogni cella contiene 0 se può
        essere attraversata e 1 se non può essere attraversata.
        • Ad ogni passo ci si può spostare di una sola casella in orizzontale, verticale o diagonale.
        • Progettare ed implementare un algoritmo che dato un labirinto restituisca una via d'uscita.
 */

#include "Maze.hpp"

int main(int argc, const char * argv[]) {
    srand((unsigned int) time(0));
    Maze simpleMaze(10, 0.4);
    // Il secondo parametro è la percentuale di ostacoli da inserire
    simpleMaze.printMaze();
    
    bool isThereAnExit = simpleMaze.solveOne();
    std::vector<bool> solution = simpleMaze.getSolution();
    
    if (isThereAnExit) {
        std::cout << "\nSOLUZIONE:\n";
        for (int i = 0; i < simpleMaze.getBoardSize(); i++) {
            for (int j = 0; j < simpleMaze.getBoardSize(); j++) std::cout << solution.at(i * simpleMaze.getBoardSize() + j) << "\t";
            std::cout << "\n";
        }
    } else {
        std::cout << "\nNON ESISTE SOLUZIONE...\n";
    }
    std::cout << "\n";
    
    return 0;
}
