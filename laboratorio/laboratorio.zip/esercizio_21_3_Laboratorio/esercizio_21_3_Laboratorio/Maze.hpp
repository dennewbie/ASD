//
//  Maze.hpp
//  esercizio_21_3_Laboratorio
//
//  Created by Denny Caruso on 07/12/2020.
//

#ifndef Maze_hpp
#define Maze_hpp

#include<iostream>
#include<vector>

class Maze{
private:
    int boardSize; //size labirinto
    std::vector<bool> board;
    std::vector<bool> solution;
    int start_i;
    int start_j;
    int end_i;
    int end_j;

    
    void init(int numberObstacles);
    void setBoardSize(int newBoardSize);
    void setBoard(std::vector<bool> newBoard);
    std::vector<bool> getBoard();
    
    void setStart_i(int newStart_i);
    void setStart_j(int newStart_j);
    int getStart_i();
    int getStart_j();
    
    void setEnd_i(int newEnd_i);
    void setEnd_j(int newEnd_j);
    int getEnd_i();
    int getEnd_j();
    
    void setSolution(std::vector<bool> newSolution);
    
    bool solveMaze(int x, int y, int oldX, int oldY);
    bool check(int x, int y);
    
    std::vector<bool> whereIWas;

public:
    Maze(int boardSize, float obstaclesPercentage) {
        setBoardSize(boardSize);
        setBoard(std::vector<bool>(getBoardSize() * getBoardSize(), 0));
        setSolution(std::vector<bool>(getBoardSize() * getBoardSize(), 0));
        setStart_i(0);
        setStart_j(0);
        setEnd_i(getBoardSize() - 1);
        setEnd_j(getBoardSize() - 1);
        
        init((int) getBoardSize() * getBoardSize() * obstaclesPercentage);
        whereIWas = std::vector<bool>(getBoardSize() * getBoardSize(), false);
    }
    
    Maze(int boardSize, float obstaclesPercentage, int start_i, int start_j, int end_i, int end_j) {
        setBoardSize(boardSize);
        setBoard(std::vector<bool>(getBoardSize() * getBoardSize(), 0));
        setStart_i(start_i);
        setStart_j(start_j);
        setEnd_i(end_i);
        setEnd_j(end_j);
        
        init((int) getBoardSize() * getBoardSize() * obstaclesPercentage);
    }
    
    ~Maze() { };

    int getBoardSize();
    void printMaze();
    bool solveOne();
    std::vector<bool> getSolution();
};


#endif /* Maze_hpp */
