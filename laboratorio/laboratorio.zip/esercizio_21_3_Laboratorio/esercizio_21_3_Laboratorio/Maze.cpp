//
//  Maze.cpp
//  esercizio_21_3_Laboratorio
//
//  Created by Denny Caruso on 07/12/2020.
//

#include "Maze.hpp"

void Maze::init(int obstaclesNumber) {
    for (int i = 0; i < obstaclesNumber; i++) {
        int x, y;
        if (getStart_i()  == 0 && getStart_j() == 0 && getEnd_i() == getBoardSize() - 1 && getEnd_j() == getBoardSize() - 1) {
            do {
                x = rand() % getBoardSize();
                y = rand() % getBoardSize();
                
            } while(board[x * getBoardSize() + y]  || (x == getStart_i() && y == getStart_j()) || (x == getBoardSize() - 1 && y == getBoardSize() - 1));
        } else {
            
            do {
                x = rand() % getBoardSize();
                y = rand() % getBoardSize();
                
            } while(board[x * getBoardSize() + y]  || (x == getStart_i() && y == getStart_j()) || (x == getEnd_i() && y == getEnd_j()));
        }
        // Fin quando non ho messo già l'ostacolo oppure sto mettendo l'ostacolo nella cella di partenza o di arrivo
        // (non posso mettere un ostacolo nel punto iniziale e finale)
        board[x * getBoardSize() + y] = true;
    }
}

void Maze::printMaze() {
    for (auto i = 0; i < getBoardSize(); i++) {
        for (auto j = 0; j < getBoardSize(); j++) std::cout << board.at(i * getBoardSize() + j) << "\t";
        std::cout << "\n";
    }
    std::cout << "\n";
}

void Maze::setBoardSize(int newBoardSize) {
    this->boardSize = newBoardSize;
}

void Maze::setBoard(std::vector<bool> newBoard) {
    this->board = newBoard;
}

int Maze::getBoardSize() {
    return this->boardSize;
}

std::vector<bool> Maze::getBoard() {
    return this->board;
}

void Maze::setStart_i(int newStart_i) {
    this->start_i = newStart_i;
}

void Maze::setStart_j(int newStart_j) {
    this->start_j = newStart_j;
}

int Maze::getStart_i() {
    return this->start_i;
}

int Maze::getStart_j() {
    return this->start_j;
}

void Maze::setEnd_i(int newEnd_i) {
    this->end_i = newEnd_i;
}

void Maze::setEnd_j(int newEnd_j) {
    this->end_j = newEnd_j;
}

int Maze::getEnd_i() {
    return this->end_i;
}

int Maze::getEnd_j() {
    return this->end_j;
}

void Maze::setSolution(std::vector<bool> newSolution) {
    this->solution = newSolution;
}

std::vector<bool> Maze::getSolution() {
    return this->solution;
}

bool Maze::solveOne() {
    if (solveMaze(0, 0, -1, -1)) return true;
    return false;
}

bool Maze::solveMaze(int x, int y, int oldX, int oldY) {
    if(x == getBoardSize() - 1 && y == getBoardSize() - 1 && this->board.at(x * getBoardSize() + y) == false && this->solution.at(x * getBoardSize() + y) == false) {
        this->solution.at((getBoardSize() - 1) * getBoardSize() + (getBoardSize() - 1)) = true;
        return true;
    }
    
    for (int i = 0; i < getBoardSize(); i++) {
        for (int j = 0; j < getBoardSize(); j++) std::cout << solution.at(i * getBoardSize() + j) << "\t";
        std::cout << "\n";
    }
    std::cout << "\n\n";
    
//    for (int i = 0; i < getBoardSize(); i++) {
//        for (int j = 0; j < getBoardSize(); j++) std::cout << solution.at(i * getBoardSize() + j) << "\t";
//        std::cout << "\n";
//    }
//    std::cout << "\n";
//
    if (check(x, y)) {
        if (x == oldX && y == oldY) {
            this->solution.at(x * getBoardSize() + y) = false;
            return false;
        }
        
        whereIWas.at(x * getBoardSize() + y) = true;
        solution.at(x * getBoardSize() + y) = true;
        
        //aggiungere soluzioni tutto lo spazio di ricerca
//        if (solveMaze(x + 1, y, x, y) == true) return  true;
//        if (solveMaze(x, y + 1, x , y) == true) return  true;
//        if (solveMaze(x + 1, y + 1, x, y) == true) return  true;
//
    
        if (x > 0 && y > 0 && whereIWas.at((x - 1) * getBoardSize() + (y - 1)) == false) {
            if (solveMaze(x - 1, y - 1, x, y) == true) return  true;
        }
        
        if (x > 0) {
            if (whereIWas.at((x - 1) * getBoardSize() + y) == false) {
                if (solveMaze(x - 1, y, x, y) == true) return  true;
            }
            
            if (y + 1 < getBoardSize()) {
                if (whereIWas.at((x - 1) * getBoardSize() + (y + 1)) == false) {
                    if (solveMaze(x - 1, y + 1, x, y) == true) return  true;
                }
            }
        }
        
        if (y > 0) {
            if (whereIWas.at(x * getBoardSize() + (y - 1)) == false) {
                if (solveMaze(x, y - 1, x , y) == true) return  true;
            }
            
            if (x + 1 < getBoardSize()) {
                if (whereIWas.at((x + 1) * getBoardSize() + (y - 1)) == false) {
                    if (solveMaze(x + 1, y - 1, x, y) == true) return  true;
                }
            }
        }
        
        if (x + 1 < getBoardSize()) {
            if (whereIWas.at((x + 1) * getBoardSize() + y) == false) {
                if (solveMaze(x + 1, y, x, y) == true) return  true;
            }
        }
        
        if (y + 1 < getBoardSize()) {
            if (whereIWas.at(x * getBoardSize() + (y + 1)) == false) {
                if (solveMaze(x, y + 1, x , y) == true) return  true;
            }
        }
    
        if (x + 1 < getBoardSize()  && y + 1 < getBoardSize()) {
            if (whereIWas.at((x + 1) * getBoardSize() + (y + 1)) == false) {
                if (solveMaze(x + 1, y + 1, x, y) == true) return  true;
            }
        }
        
        // Passaggo di Backtracking
        this->solution.at(x * getBoardSize() + y) = false;
        return false;
    }
    return false;
}
        
bool Maze::check(int x, int y) {
    int k = x * getBoardSize() + y;
    if (x >= 0 && x < getBoardSize() && y >= 0 && y < getBoardSize() && this->board.at(k) == false) return true;
    
    return false;
}
