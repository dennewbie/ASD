//
//  main.cpp
//  esercizio_11_1_3_Laboratorio
//
//  Created by Denny Caruso on 02/11/2020.
//

//Counting Sort Cormen Reverse

#include <iostream>

using namespace std;

void countingSort (int *A, int *B, int lengthA, int lengthC){
    int *C = new int[lengthC];

    for (int i = 0; i < lengthC; i++) C[i] = 0;
    for (int j = 0; j < lengthA; j++) C[    A[j]    ]++;

    for (int i = 1; i < lengthC; i++) C[i] = C[i] + C[i - 1];

    for (int j = lengthA - 1; j >= 0; j--) {
        B[  lengthA - (C[  A[j]    ])] = A[j];
        C[  A[j]    ] = C[  A[j]    ] - 1;
    }

    delete [] C;
}

void getMax(int *arr, int size, int *max) {
    if (size <= 0) return;
    *max = arr[0];
    for (int i = 1; i < size; i++) {
        if (arr[i] > *max) *max = arr[i];
    }
}

int main() {
    int arr[] = { 1, 2, 3, 1, 2, 2, 2, 3, 1, 3 };
    int size = sizeof(arr) / sizeof(arr[0]), max;
    int resArr[size];
    getMax(arr, size, &max);
    int sizeC = max + 1;

    countingSort(arr, resArr, size, sizeC);

    // Stampa in output il vettore ordinato
    for (int idx = 0; idx < size; idx++) cout << "Elemento [" << idx << "] = " << resArr[idx] << endl;
    return 0;
}
