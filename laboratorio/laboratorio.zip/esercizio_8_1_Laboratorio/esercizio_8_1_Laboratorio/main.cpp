//
//  main.cpp
//  esercizio_8_1_Laboratorio
//
//  Created by Denny Caruso on 23/10/2020.
//

/*
    Riscrivere il quicksort utilizzando il contenitore Vector ed gli iteratori
 */

#include <iostream>
#include <iterator>
#include <vector>
#include <ctime>
#include <cstdlib>
#define M 15

template <class T> void printArray(std::vector<T> arr);
template <class T> void swapper(T &firstElement, T &secondElement);
template <class T> void compswapper(T &firstElement, T &secondElement);

void insertionSort(std::vector<int>::iterator low, std::vector<int>::iterator high);
void quickSort(std::vector<int>::iterator low, std::vector<int>::iterator high);
    
std::vector<int>::iterator partition(std::vector<int>::iterator low, std::vector<int>::iterator high);
void randPartition(std::vector<int>::iterator low, std::vector<int>::iterator high);

int main(int argc, const char * argv[]) {
    srand((unsigned int) time(NULL));
    std::vector<int> array = { 100, 9, -1, 20, 6, 6, 32, 16, -5, 111, 2, -40, -1000, 30, 22, 1101, 33, 100, 9 };
    printArray(array);
    
    quickSort(array.begin(), array.end() - 1);
    printArray(array);
    return 0;
}

template <class T> void printArray(std::vector<T> arr) {
    typename std::vector<T>::iterator it;
    for (it = arr.begin(); it != arr.end(); it++) std::cout << *it << "\n";
    std::cout << "\n\n";
}

template <class T> void swapper(T &firstElement, T &secondElement) {
    T temp = firstElement;
    firstElement = secondElement;
    secondElement = temp;
}

template <class T> void compswapper(T &firstElement, T &secondElement) {
    if (secondElement > firstElement) swapper(firstElement, secondElement);
}

void insertionSort(std::vector<int>::iterator low, std::vector<int>::iterator high) {
    auto i = low, j = low;
    int key;
    for (i = low + 1; i <= high; i++) {
        key = *i;
        j = i - 1;

        while (j >= low && *j > key) {
            *(j + 1) = *j;
            j--;
        }
        j++;
        *j = key;
    }
}

void quickSort(std::vector<int>::iterator low, std::vector<int>::iterator high) {
    auto size = std::distance(low, high);
    
    if (size >= M) {
        auto itCenter = low + (std::distance(low, high) / 2);
        swapper(*itCenter, *(high - 1));
        compswapper(*low, *(high - 1));
        compswapper(*low, *high);
        compswapper(*(high - 1), *high);
        
        auto mid = partition(low, high);
        quickSort(low, mid - 1);
        quickSort(mid + 1, high);
    } else {
        insertionSort(low, high);
    }
}

std::vector<int>::iterator partition(std::vector<int>::iterator low, std::vector<int>::iterator high) {
    randPartition(low, high);
    
    auto pivot = low, i = low + 1;
    for(std::vector<int>::iterator j = low + 1; j <= high; j++){
        if(*j < *pivot){
            swapper(*j, *i);
            std::advance(i, 1);
        }
    }

    std::advance(i, -1);
    swapper(*low, *i);
    return i;
}

void randPartition(std::vector<int>::iterator low, std::vector<int>::iterator high) {
    auto randomIndex = 1 + rand() % (std::distance(low, high) + 1);
    auto pivot = low;
    std::advance(pivot, randomIndex);
    swapper(*pivot, *low);
}
