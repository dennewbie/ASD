//
//  main.cpp
//  esercizio_8_3_Laboratorio
//
//  Created by Denny Caruso on 23/10/2020.
//

/*
 Implementare il Quicksort con il doppio pivot
 Questa variante utilizza un pivot per la parte sinistra dell'array
 ed un pivot per la parte destra con il vincolo che il pivot sinistro
 sia minore del pivot destro.
 
 Al termine della procedura di partition, l'array sarà diviso in tre parti:
 1) La prima in cui gli elementi sono minori del pivot sinistro
 2) La seconda in cui gli elementi sono maggiori o uguali del pivot
 sinistro e minori uguali del pivot destro
 3) La terza in cui gli elementi sono maggiori del pivot destro
 
 L'algoritmo viene richiamato ricorsivamente sulle tre parti dell'array
 */

#include <iostream>

void doulePivotQuickSort(int *arr, int low, int high);
int doublePivotPartition(int *arr, int low, int high, int *);

template <class T> void printArray(T *arr, int size);
template <class T> void swapper(T *firstElement, T *secondElement);

int main(int argc, const char * argv[]) {
    int array[] = { 100, 9, -1, 20, 6, 6 };
    int size = sizeof(array) / sizeof(array[0]);
    printArray(array, size);
    
    doulePivotQuickSort(array, 0, size - 1);
    printArray(array, size);
    return 0;
}

void doulePivotQuickSort(int *arr, int low, int high) {
    if (low < high) {
        int leftPivot, rightPivot;
        
        rightPivot = doublePivotPartition(arr, low, high, &leftPivot);
        doulePivotQuickSort(arr, low, leftPivot - 1);
        doulePivotQuickSort(arr, leftPivot + 1, rightPivot - 1);
        doulePivotQuickSort(arr, rightPivot + 1, high);
    }
}

int doublePivotPartition(int *arr, int low, int high, int *originalLeftPivot) {
    if (arr[low] > arr[high]) swapper(&arr[low], &arr[high]);
    
    int j = low + 1;
    int g = high - 1;
    int k = low + 1;
    
    int leftPivot = arr[low], rightPivot = arr[high];
    while (k <= g) {
        // if elements are less than the left pivot
        if (arr[k] < leftPivot) {
            swapper(&arr[k], &arr[j]);
            j++;
        } else if (arr[k] >= rightPivot) {      // if elements are greater than or equal to the right pivot
            while (arr[g] > rightPivot && k < g) {
                g--;
            }
            swapper(&arr[k], &arr[g]);
            g--;
            if (arr[k] < leftPivot) {
                swapper(&arr[k], &arr[j]);
                j++;
            }
        }
        k++;
    }
    j--;
    g++;
    
    // bring pivots to their appropriate positions.
    swapper(&arr[low], &arr[j]);
    swapper(&arr[high], &arr[g]);
    
    // returning the indices of the pivots.
    *originalLeftPivot = j; // because we cannot return two elements
    // from a function.
    
    return g;
}

template <class T> void printArray(T *arr, int size) {
    for (int i = 0; i < size; i++) std::cout << arr[i] << "\n";
    std::cout << "\n\n";
}

template <class T> void swapper(T *firstElement, T *secondElement) {
    T temp = *firstElement;
    *firstElement = *secondElement;
    *secondElement = temp;
    
}
