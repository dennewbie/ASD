//
//  MinPriorityQueue.hpp
//  esercizio_10_2_Laboratorio
//
//  Created by Denny Caruso on 30/10/2020.
//

#ifndef MinPriorityQueue_hpp
#define MinPriorityQueue_hpp

#include "MinHeap.hpp"

template <class T, class K> class MinPriorityQueue: private MinHeap<T, K> {
private:
    
public:
    MinPriorityQueue() {
        MinHeap<T, K>();
    }
    
    virtual ~MinPriorityQueue() { }
    
    Node<T, K> getMinimum();
    bool extractMinimum();
    void insertNode(Node<T, K> newNode);
    bool decreasePriorityAt(int i, K key);
    void printMinPQ();
};

template <class T, class K> Node<T, K> MinPriorityQueue<T, K>::getMinimum() {
    return this->getHeap().at(0);
}

template <class T, class K> bool MinPriorityQueue<T, K>::extractMinimum() {
    if (this->getHeapSize() <= 0) return false;
    
    this->heap.at(0) = this->heap.at(this->getHeapSize() - 1);
    this->setHeapSize(this->getHeapSize() - 1);
    this->deleteLastElement();
    this->minHeapify(0);
    return true;
}

template <class T, class K> void MinPriorityQueue<T, K>::insertNode(Node<T, K> newNode) {
    this->insert(newNode);
}

template <class T, class K> bool MinPriorityQueue<T, K>::decreasePriorityAt(int i, K key) {
    if (i > this->getHeapSize() - 1) return false;
    if (key > this->getHeap().at(i).getPriority()) return false;
    
    this->changeValueAt(i, this->getHeap().at(i), key);
    return true;
}

template <class T, class K> void MinPriorityQueue<T, K>::printMinPQ() {
    this->printHeap();
}

#endif /* MinPriorityQueue_hpp */
