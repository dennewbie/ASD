//
//  main.cpp
//  Huffman
//
//  Created by Denny Caruso on 01/01/21.
//

/*
     Progettare ed implementare un codificatore / decodificatore di Huffman
     
     • Estrarre la frequenza di ogni lettera
     – file contenente le coppie <lettera,frequenza>
     – oppure file contenente solo lettere
     – oppure file contenente parole
     – negli ultimi due casi si può utilizzare l'esercizio wordcount visto nella lezione 5
     
     • Per la costruzione/gestione del min-heap/min-priority- queue si possono utilizzare gli esercizi delle lezioni 9 e 10
 */

/*
 TO DO:
 aggiungere lettura spazi bianchi e char a capo. Magari con la getline(...)
 */

#include "Huffman.hpp"

int main(int argc, const char * argv[]) {
    std::fstream inputFileStream, encodedFileStream, decodedFileStream;
    std::string inputFileName = "loremIpsum.txt";
    std::string encodedFileName = "loremIpsumEncoded.txt";
    std::string decodedFileName = "loremIpsumDecoded.txt";
    
    Huffman huffmanTree = Huffman(&inputFileStream, &encodedFileStream, &decodedFileStream, inputFileName, encodedFileName, decodedFileName);
    huffmanTree.encodeFile();
    huffmanTree.decodeFile();
    return 0;
}
