//
//  Huffman.hpp
//  esercizio_17_1_Laboratorio
//
//  Created by Denny Caruso on 25/11/2020.
//

#ifndef Huffman_hpp
#define Huffman_hpp

#include "MinPriorityQueue.hpp"
#include "Node.hpp"
#include "HuffmanNode.hpp"

#include <string>
#include <map>
#include <fstream>
#include <algorithm>

class Huffman {
private:
    std::fstream * inputFileStream;
    std::fstream * encodedFileStream;
    std::fstream * decodedFileStream;
    
    std::string inputFileName;
    std::string encodedFileName;
    std::string decodedFileName;
    
    std::vector<float> frequencyVector;
    std::map <char, float> frequencyMap;
    std::map <char, std::string> charToCodes;
    std::map<std::string, char> codesToChar;
    MinPriorityQueue <HuffmanNode, float> minPQ;
    Node<HuffmanNode, float> huffmanTreeRoot;
    
    void buildHuffmanTree();
    void initializeFileStream();
    void closeFileStream();
    void createFrequencyMap();
    void printMap();
    void calculateFrequencyForEachChar();
    void createFrequencyVector();
    void saveCodes();
    void searchForChar(std::string & code, char charToSearch, Node <HuffmanNode, float> * current);
    
public:
    Huffman(std::fstream * inputFileStream, std::fstream * encodedFileStream, std::fstream * decodedFileStream, std::string inputFileName, std::string encodedFileName, std::string decodedFileName) {
        this->inputFileStream = inputFileStream;
        this->encodedFileStream = encodedFileStream;
        this->decodedFileStream = decodedFileStream;
        this->inputFileName = inputFileName;
        this->encodedFileName = encodedFileName;
        this->decodedFileName = decodedFileName;
        initializeFileStream();
        createFrequencyMap();
        createFrequencyVector();
        buildHuffmanTree();
    }
    
    ~Huffman() {
        closeFileStream();
    }
    
    void encodeFile();
    void decodeFile();
    
};

void Huffman::createFrequencyVector() {
    for (auto singleMapElement: this->frequencyMap) this->frequencyVector.push_back(singleMapElement.second);
}

void Huffman::createFrequencyMap() {
    std::string singleWord;

    while (*inputFileStream >> singleWord) {
//        singleWord.erase(std::remove_if(singleWord.begin(), singleWord.end(), [](char c) { return (c == ',' || c== '.' || c == ' '); }));
        for (auto i = 0; i < singleWord.size(); i++) this->frequencyMap[singleWord.at(i)]++;
    }

    calculateFrequencyForEachChar();
}

void Huffman::calculateFrequencyForEachChar() {
    unsigned int totalOccurrences = 0;

    for (auto singleMapElement: this->frequencyMap) totalOccurrences += singleMapElement.second;
    for (auto & singleMapElement: this->frequencyMap) singleMapElement.second = (singleMapElement.second * 100) / totalOccurrences;
}

void Huffman::printMap() {
    std::cout << "\nMAP:\n";
    for (auto singleMapElement: frequencyMap) std::cout << std::setprecision(3) << "Key: " << singleMapElement.first << "\nValue: " << singleMapElement.second << "% \n\n";
    std::cout << "\n";
}

void Huffman::initializeFileStream() {
    this->inputFileStream->open(this->inputFileName.c_str());
    this->encodedFileStream->open(this->encodedFileName.c_str());
    this->decodedFileStream->open(this->decodedFileName.c_str());

    if (inputFileStream->fail() || encodedFileStream->fail() || decodedFileStream->fail()) exit(0);
}

void Huffman::closeFileStream() {
    this->inputFileStream->close();
    this->encodedFileStream->close();
    this->decodedFileStream->close();
}

void Huffman::buildHuffmanTree() {
    for (auto & it: frequencyMap) {
        HuffmanNode newHuffmanNode = HuffmanNode(it.first);
        Node<HuffmanNode, float> newNode = Node<HuffmanNode, float>(newHuffmanNode, it.second);
        newNode.setLeft(nullptr);
        newNode.setRight(nullptr);
        minPQ.insertNode(newNode);
    }
    
    for (int i = 0; i < frequencyMap.size() - 1; i++) {
        Node<HuffmanNode, float> x, y;
        x = minPQ.getMinimum();
        minPQ.extractMinimum();
        y = minPQ.getMinimum();
        minPQ.extractMinimum();
        
        Node<HuffmanNode, float> z = Node<HuffmanNode, float>(x.getPriority() + y.getPriority());
        x.getData().setHuffmanDigit(false);
        y.getData().setHuffmanDigit(true);
        
        Node<HuffmanNode, float> * ptrX = new Node<HuffmanNode, float>(x.getData(), x.getPriority());
        ptrX->setLeft(x.getLeft());
        ptrX->setRight(x.getRight());
        
        Node<HuffmanNode, float> * ptrY = new Node<HuffmanNode, float>(y.getData(), y.getPriority());
        ptrY->setLeft(y.getLeft());
        ptrY->setRight(y.getRight());
        
        z.setLeft(ptrX);
        z.setRight(ptrY);
        minPQ.insertNode(z);
    }
    
    huffmanTreeRoot = minPQ.getMinimum();
    minPQ.extractMinimum();
    saveCodes();
}

bool isFound;

void Huffman::saveCodes() {
    Node<HuffmanNode, float> * current = new Node <HuffmanNode, float>(huffmanTreeRoot.getData(), huffmanTreeRoot.getPriority(), huffmanTreeRoot.getLeft(), huffmanTreeRoot.getRight());
        
    for (auto it = frequencyMap.begin(); it != frequencyMap.end(); it++) {
        std::string tempString = "";
        isFound = false;
        searchForChar(tempString, it->first, current);
        tempString.pop_back();
        
        charToCodes.insert(std::make_pair(it->first, "0"));
        codesToChar.insert(std::make_pair(tempString, 0));
        
        std::map<char, std::string>::iterator localIt_1 = charToCodes.find(it->first);
        if (localIt_1 != charToCodes.end()) localIt_1->second = tempString;
        
        std::map<std::string, char>::iterator localIt_2 = codesToChar.find(tempString);
        if (localIt_2 != codesToChar.end()) localIt_2->second = it->first;
    }
    
//    for (auto it: charCodes) std::cout << "CHAR: " << it.first << " CODE: " << it.second << "\n";
}

void Huffman::searchForChar(std::string & code, char charToSearch, Node <HuffmanNode, float> * current) {
    if (current != nullptr) {
        if (current->getData().getHuffmanChar() == charToSearch) {
            code.append(std::to_string((int) current->getData().getHuffmanDigit()));
            isFound = true;
            return;
        } else {
            if (!isFound) searchForChar(code.append("0"), charToSearch, current->getLeft());
            if (!isFound) code.pop_back();
            if (!isFound) searchForChar(code.append("1"), charToSearch, current->getRight());
            if (!isFound) code.pop_back();
        }
    }
}

void Huffman::encodeFile() {
    std::string singleWord = "";
    
    inputFileStream->close();
    inputFileStream->open(inputFileName.c_str());
    if (inputFileStream->fail()) exit(0);
    
    while (*inputFileStream >> singleWord) {
//        singleWord.erase(std::remove_if(singleWord.begin(), singleWord.end(), [](char c) { return (c == ',' || c== '.' || c == ' '); }));

        for (auto i = 0; i < singleWord.size(); i++) {
            std::map<char, std::string>::iterator it = charToCodes.find(singleWord.at(i));
            if (it != charToCodes.end()) {
                *encodedFileStream << it->second;
                std::cout << "\nSCRIVO: " << it->second;
            }
        }
    }
    
    printMap();
}

void Huffman::decodeFile() {
    std::string singleWord = "";
    std::string temp = "";
    encodedFileStream->close();
    encodedFileStream->open(encodedFileName.c_str());
    if (encodedFileStream->fail()) exit(0);
    
    decodedFileStream->close();
    decodedFileStream->open(decodedFileName.c_str());
    if (decodedFileStream->fail()) exit(0);
    
    while (*encodedFileStream >> singleWord) {
//        singleWord.erase(std::remove_if(singleWord.begin(), singleWord.end(), [](char c) { return (c == ',' || c== '.' || c == ' '); }));
        for (int i = 0; i < singleWord.size(); i++) {
            temp.append(std::string(1, singleWord.at(i)));
            std::map<std::string, char>::iterator it = codesToChar.find(temp);
            if (it != codesToChar.end()) {
                *decodedFileStream << it->second;
                temp = "";
            }
        }
        
    }
}

/*
 Lorem ipsum dolor sit amet, consectetur adipiscing elit. In ornare lorem sed consequat ultrices. Aenean mattis massa eget magna malesuada, id commodo eros interdum. Vivamus maximus mi vitae imperdiet egestas. Maecenas eleifend varius nunc, sit amet varius turpis dapibus vel. Donec non ante nibh. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Curabitur non nisi vitae lacus condimentum sodales. Vestibulum tempus feugiat massa, nec pretium mi viverra quis. Fusce eu massa vitae dui egestas vestibulum ut ut lacus. Donec imperdiet egestas ex, nec congue urna ultrices at.

 */

#endif /* Huffman_hpp */
