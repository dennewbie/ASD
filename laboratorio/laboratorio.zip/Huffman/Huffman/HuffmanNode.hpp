//
//  HuffmanNode.hpp
//  Huffman
//
//  Created by Denny Caruso on 01/01/21.
//

#ifndef HuffmanNode_hpp
#define HuffmanNode_hpp

class HuffmanNode {
private:
    char huffmanChar;
    bool huffmanDigit;
    
public:
    HuffmanNode() { }
    
    HuffmanNode(char huffmanChar, bool huffmanDigit) {
        setHuffmanChar(huffmanChar);
        setHuffmanDigit(huffmanDigit);
    }
    
    HuffmanNode(bool huffmanDigit) {
        setHuffmanDigit(huffmanDigit);
    }
    
    HuffmanNode(char huffmanChar) {
        setHuffmanChar(huffmanChar);
    }
    
    bool getHuffmanDigit() {
        return this->huffmanDigit;
    }
    
    void setHuffmanDigit(bool huffmanDigit) {
        this->huffmanDigit = huffmanDigit;
    }
  
    char getHuffmanChar() {
        return this->huffmanChar;
    }
    
    void setHuffmanChar(char huffmanChar) {
        this->huffmanChar = huffmanChar;
    }
    
    virtual ~HuffmanNode() { }
};


#endif /* HuffmanNode_hpp */
