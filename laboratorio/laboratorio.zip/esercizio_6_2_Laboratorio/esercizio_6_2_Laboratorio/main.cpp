//
//  main.cpp
//  esercizio_6_2_Laboratorio
//
//  Created by Denny Caruso on 16/10/2020.
//

/*
    Dato un insieme di N numeri, trovare la coppia di numeri che hanno la più piccola differenza tra di loro.
 */

#include <iostream>

void insertionSort(int *, int);
template <class T> void findTwoNumbers(int *, int, T &, T &);
void printArray(int *, int);

int main(int argc, const char * argv[]) {
    int array[] = { 100, 30, 130, 50, 1 , 20, 10, 11, 13 };
    int size = ( sizeof(array) / sizeof(array[0]) ), firstNumber, secondNumber;
    
    insertionSort(array, size);
    findTwoNumbers(array, size, firstNumber, secondNumber);
    printArray(array, size);
    
    std::cout << "Numeri la cui coppia ha la differenza più piccola: " << firstNumber << " - " << secondNumber << "\n\n";
    return 0;
}

void insertionSort(int *arr, int size) {
    int i, key, j;
    for (i = 1; i < size; i++) {
        key = arr[i];
        j = i - 1;

        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

template <class T> void findTwoNumbers(int *arr, int size, T &firstNumber, T &secondNumber) {
    int difference = arr[1] - arr[0];
    firstNumber = arr[0], secondNumber = arr[1];
    
    for (int i = 2; i < size; i++) {
        int locDifference = (arr[i] - arr[i - 1]);
        if (locDifference < difference) {
            difference = locDifference;
            firstNumber = arr[i], secondNumber = arr[i - 1];
        }
    }
}

void printArray(int *arr, int size) {
    for (int i = 0; i < size; i++) std::cout << arr[i] << "\n";
}
