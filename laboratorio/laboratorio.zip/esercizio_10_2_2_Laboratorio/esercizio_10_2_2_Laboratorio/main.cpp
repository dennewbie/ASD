//
//  main.cpp
//  esercizio_10_2_2_Laboratorio
//
//  Created by Denny Caruso on 30/10/2020.
//

/*
 
 Progettare ed implementare una classe Priority-queue che implementi le seguenti operazioni:
    • Insert(S,x)
    • Maximum(S) / Minimum(S)
    • Extract-Max(S) / Extract-Min(S)
    • Increase-priority(S,x,k) / Decrease-priority(S,x,k)
 
 */

#include "MaxPriorityQueue.hpp"

int main(int argc, const char * argv[]) {
    MaxPriorityQueue<int> integerMaxPriorityQueue = MaxPriorityQueue<int>();
    
    integerMaxPriorityQueue.insertNode(106);
    integerMaxPriorityQueue.insertNode(105);
    integerMaxPriorityQueue.insertNode(104);
    integerMaxPriorityQueue.insertNode(103);
    integerMaxPriorityQueue.insertNode(110);
    integerMaxPriorityQueue.insertNode(109);
    integerMaxPriorityQueue.insertNode(108);
    integerMaxPriorityQueue.insertNode(107);

    integerMaxPriorityQueue.extractMaximum();
    integerMaxPriorityQueue.extractMaximum();
    integerMaxPriorityQueue.extractMaximum();
    integerMaxPriorityQueue.extractMaximum();
    
    integerMaxPriorityQueue.increasePriorityAt(100, 5);
    integerMaxPriorityQueue.increasePriorityAt(3, 1000);
    
    integerMaxPriorityQueue.extractMaximum();
    return 0;
}

