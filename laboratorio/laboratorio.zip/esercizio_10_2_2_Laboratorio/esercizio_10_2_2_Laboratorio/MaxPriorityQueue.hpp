//
//  MaxPriorityQueue.hpp
//  esercizio_10_2_2_Laboratorio
//
//  Created by Denny Caruso on 30/10/2020.
//

#ifndef MaxPriorityQueue_hpp
#define MaxPriorityQueue_hpp

#include "MaxHeap.hpp"

template <class T> class MaxPriorityQueue: private MaxHeap<T> {
private:
    
public:
    MaxPriorityQueue() {
        MaxHeap<T>();
    }
    
    virtual ~MaxPriorityQueue() { }
    
    T getMaximum();
    bool extractMaximum();
    void insertNode(T newNode);
    bool increasePriorityAt(int i, T key);
};

template <class T> T MaxPriorityQueue<T>::getMaximum() {
    return this->getHeap().at(0);
}

template <class T> bool MaxPriorityQueue<T>::extractMaximum() {
    if (this->getHeapSize() < 0) return false;
    
    T max = getMaximum();
    std::cout << "\n" << max << "\n";
    this->heap.at(0) = this->heap.at(this->getHeapSize() - 1);
    this->setHeapSize(this->getHeapSize() - 1);
    this->maxHeapify(0);
    return true;
}

template <class T> void MaxPriorityQueue<T>::insertNode(T newNode) {
    this->insert(newNode);
}

template <class T> bool MaxPriorityQueue<T>::increasePriorityAt(int i, T key) {
    if (i > this->getHeapSize() - 1) return false;
    if (key < this->getHeap().at(i)) return false;
    
    this->changeValueAt(i, key);
    return true;
}

#endif /* MaxPriorityQueue_hpp */
