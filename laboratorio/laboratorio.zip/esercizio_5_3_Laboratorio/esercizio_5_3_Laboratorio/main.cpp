//
//  main.cpp
//  esercizio_5_3_Laboratorio
//
//  Created by Denny Caruso on 13/10/2020.
//
// Progettare ed implementare un programma che utilizzando una Map, conti il numero di occorrenze di ogni parola contenuta in un file.

#include <iostream>
#include <string>
#include <map>
#include <fstream>
#include <algorithm>

int main(int argc, const char * argv[]) {
    std::fstream inputFileStream;
    std::string fileName = "loremIpsum.txt", singleWord;
    std::map<std::string, int> words;
    
    inputFileStream.open(fileName.c_str());
    if (inputFileStream.fail()) {
        std::cout << "Error while opening Input stream ......";
    } else {
        while (inputFileStream >> singleWord) {
            singleWord.erase(std::remove_if(singleWord.begin(), singleWord.end(), [](char c) { return (c == ',' || c== '.' || c == ' '); }));
            words[singleWord.c_str()]++;
        }
        for (auto singleMapElement: words) std::cout << "Key: " << singleMapElement.first << "\nValue: " << singleMapElement.second << "\n\n";
    }
    
    inputFileStream.close();
    return 0;
}
