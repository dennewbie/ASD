//
//  main.cpp
//  esercizio_16_2_Laboratorio
//
//  Created by Denny Caruso on 20/11/2020.
//

/*
    Risolvere il problema dello Zaino 0-1 e stampare la soluzione ottima trovata
 */

#include <iostream>
#include <vector>

template <class T> void printMatrix(std::vector<std::vector<T>>);
std::vector<std::vector<int>> knapsackZeroOne(int totalWeight, std::vector<int> objValues, std::vector<int> objWeight, std::vector<bool> * objectToTake);
void calculateSolution(int totalWeight, std::vector<int> objValues, std::vector<int> objWeight, std::vector<bool> * objectToTake, std::vector<std::vector<int>> matrix);

int main(int argc, const char * argv[]) {
    int totalWeight = 5;
    std::vector<int> objValues = { 3, 4, 5, 6 };
    std::vector<int> objWeight = { 2, 3, 4, 5 };
    std::vector<bool> objToTake(objValues.size(), 0);
    std::vector<std::vector<int>> matrix = knapsackZeroOne(totalWeight, objValues, objWeight, &objToTake);
    
    printMatrix(matrix);
    
    std::cout << "\nOggetti Presi:\n";
    for (auto i: objToTake) std::cout << i << "\t";
    std::cout << "\n\n";
    
    return 0;
}

std::vector<std::vector<int>> knapsackZeroOne(int totalWeight, std::vector<int> objValues, std::vector<int> objWeight, std::vector<bool> * objectToTake) {
    int n = (int) objValues.size();
    std::vector<std::vector<int>> matrix(n + 1, std::vector<int>(totalWeight + 1, 0));
    
    for (int i = 1; i <= n; i++) {
        for (int w = 1; w <= totalWeight; w++) {
            if (w < objWeight.at(i - 1)) {
                matrix.at(i).at(w) = matrix.at(i - 1).at(w);
            } else {
                if (matrix.at(i - 1).at(w) > matrix.at(i - 1).at(w - objWeight.at(i - 1)) + objValues.at(i - 1)) {
                    matrix.at(i).at(w) = matrix.at(i - 1).at(w);
                } else {
                    matrix.at(i).at(w) = matrix.at(i - 1).at(w - objWeight.at(i - 1)) + objValues.at(i - 1);
                }
            }
        }
    }
    
    calculateSolution(totalWeight, objValues, objWeight, objectToTake, matrix);
    return matrix;
}

void calculateSolution(int totalWeight, std::vector<int> objValues, std::vector<int> objWeight, std::vector<bool> * objectToTake, std::vector<std::vector<int>> matrix) {
    int first, second;
    bool exitFlag = false;
    
    int n = (int) objValues.size();
    for (int i = n; i >= 0; i--) {
        if (exitFlag == true) break;
        for (int w = totalWeight; w >= 0; w--) {
            if (w == 0) {
                exitFlag = true;
                break;
            }
            first = matrix.at(i - 1).at(w);
            second = matrix.at(i - 1).at(w - objWeight.at(i - 1)) + objValues.at(i - 1);
            
            if (first < second) {
                if (matrix.at(i - 1).at(w - objWeight.at(i - 1)) != second) {
                    objectToTake->at(i - 1) = 1;
                }
                
                i--;
                w = (w - objWeight.at(i)) + 1;
            } else {
                i--;
                w++;
            }
        }
    }
}

template <class T> void printMatrix(std::vector<std::vector<T>> matrix) {
    auto rows = matrix.size();
    auto cols = matrix.at(0).size();
    
    for (auto i = 0; i < rows; i++) {
        for (auto j = 0; j < cols; j++) std::cout << matrix.at(i).at(j) << "\t\t";
        std::cout << "\n";
    }
}

