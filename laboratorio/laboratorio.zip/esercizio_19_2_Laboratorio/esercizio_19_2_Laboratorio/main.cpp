//
//  main.cpp
//  esercizio_19_2_Laboratorio
//
//  Created by Denny Caruso on 30/11/2020.
//

/*
    Implementare l'algoritmo per trovare le componenti connesse
 */

#include "Graph.hpp"

int main(int argc, const char * argv[]) {
    Graph<char> simpleGraph;
    simpleGraph.addNode(new Node<char>('A')); // 0
    simpleGraph.addNode(new Node<char>('B')); // 1
    simpleGraph.addNode(new Node<char>('C')); // 2
    simpleGraph.addNode(new Node<char>('D')); // 3
    simpleGraph.addNode(new Node<char>('E')); // 4
    simpleGraph.addNode(new Node<char>('F')); // 5
    simpleGraph.addNode(new Node<char>('G')); // 6
    simpleGraph.addNode(new Node<char>('H')); // 7
    simpleGraph.addNode(new Node<char>('I')); // 8
    simpleGraph.addNode(new Node<char>('J')); // 9
    
    //ABCD
    simpleGraph.addEdge(0, 1, 4);
    simpleGraph.addEdge(1, 0, 4);
    simpleGraph.addEdge(1, 2, 8);
    simpleGraph.addEdge(2, 1, 8);
    simpleGraph.addEdge(0, 2, 7);
    simpleGraph.addEdge(2, 0, 7);
    simpleGraph.addEdge(1, 3, 9);
    simpleGraph.addEdge(3, 1, 9);
    
    //EFG
    simpleGraph.addEdge(4, 5, 10);
    simpleGraph.addEdge(5, 4, 10);
    simpleGraph.addEdge(4, 6, 2);
    simpleGraph.addEdge(6, 4, 2);
    
    //HI
    simpleGraph.addEdge(7, 8, 1);
    simpleGraph.addEdge(8, 7, 1);
    
    
    std::cout << "\nArchi delle Componenti Connesse:\n";
    simpleGraph.getConnectedComponents();
    simpleGraph.printConnectedComponents();
}
