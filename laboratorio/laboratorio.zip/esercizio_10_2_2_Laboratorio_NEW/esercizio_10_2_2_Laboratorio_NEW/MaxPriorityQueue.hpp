//
//  MaxPriorityQueue.hpp
//  esercizio_10_2_2_Laboratorio
//
//  Created by Denny Caruso on 30/10/2020.
//

#ifndef MaxPriorityQueue_hpp
#define MaxPriorityQueue_hpp

#include "MaxHeap.hpp"

template <class T, class K> class MaxPriorityQueue: private MaxHeap<T, K> {
private:
    
public:
    MaxPriorityQueue() {
        MaxHeap<T, K>();
    }
    
    virtual ~MaxPriorityQueue() { }
    
    Node<T, K> getMaximum();
    bool extractMaximum();
    void insertNode(Node<T, K> newNode);
    bool increasePriorityAt(int i, K key);
    void printMaxPQ();
};

template <class T, class K> Node<T, K> MaxPriorityQueue<T, K>::getMaximum() {
    return this->getHeap().at(0);
}

template <class T, class K> bool MaxPriorityQueue<T, K>::extractMaximum() {
    if (this->getHeapSize() <= 0) return false;
    
//    T max = getMaximum();
//    std::cout << "\n" << max << "\n";
    this->heap.at(0) = this->heap.at(this->getHeapSize() - 1);
    this->setHeapSize(this->getHeapSize() - 1);
    this->deleteLastElement();
    this->maxHeapify(0);
    return true;
}

template <class T, class K> void MaxPriorityQueue<T, K>::insertNode(Node<T, K> newNode) {
    this->insert(newNode);
}

template <class T, class K> bool MaxPriorityQueue<T, K>::increasePriorityAt(int i, K key) {
    if (i > this->getHeapSize() - 1) return false;
    if (key < this->getHeap().at(i).getPriority()) return false;
    
    this->changeValueAt(i, this->getHeap().at(i), key);
    return true;
}

template <class T, class K> void MaxPriorityQueue<T, K>::printMaxPQ() {
    this->printHeap();
}

#endif /* MaxPriorityQueue_hpp */
