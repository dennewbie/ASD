//
//  MaxHeap.hpp
//  esercizio_10_2_2_Laboratorio
//
//  Created by Denny Caruso on 30/10/2020.
//

#ifndef MaxHeap_hpp
#define MaxHeap_hpp

#include <iostream>
#include <vector>
#include <math.h>
#include "Node.hpp"

template <class T, class K> class MaxHeap {
private:
    int heapSize;
    bool isHeap;
//    std::vector<T> heap;
    
//    void setHeapSize(int currentHeapSize);
    void setIsHeap(bool);
    
//    std::vector<T> getHeap();
    
    int parent(int i);
    int left(int i);
    int right(int i);
    
//    void maxHeapify(int i);
    void swap(Node<T, K> &firstNode, Node<T, K> &secondNode);
    
    void putSpaces(int numberOfSpaces);

protected:
    std::vector<Node<T, K>> heap;
    std::vector<Node<T, K>> getHeap();
    
    void maxHeapify(int i);
    void setHeapSize(int currentHeapSize);
    void deleteLastElement();
public:
    MaxHeap() {
        this->heapSize = 0;
        this->isHeap = true;
    }
    
    MaxHeap(std::vector<Node<T, K>> heap) {
        this->heap = heap;
        this->heapSize = 0;
        this->isHeap = false;
    }
    
    virtual ~MaxHeap() { }
    int getHeapSize();
    bool getIsHeap();
    void printHeap();
    void printArray();
    void printHeapTree();
    void buildMaxHeap();
    void insert(Node<T, K> newNode);
    void heapSort();
    void changeValueAt(int index, Node<T, K>, K key);
};

template <class T, class K> int MaxHeap<T, K>::parent(int i){
    return (i - 1) / 2;
}

template <class T, class K> int MaxHeap<T, K>::left(int i){
    return (2 * i) + 1;
}

template <class T, class K> int MaxHeap<T, K>::right(int i){
    return (2 * i) + 2;
}

template <class T, class K> void MaxHeap<T, K>::printHeap() {
    for (int i = 0; i < getHeapSize(); i++) std::cout << "\nPRIORITY: " << getHeap().at(i).getPriority() << " DATA: " << getHeap().at(i).getData() << "\n";
    std::cout << "\n\n";
}
//fix
template <class T, class K> void MaxHeap<T, K>::printArray() {
    for (auto node: this->heap) std::cout << node << "\n";
    std::cout << "\n\n";
}
//fix
template <class T, class K> void MaxHeap<T, K>::printHeapTree() {
    int j = 1, k = getHeapSize(), l = 0;
    putSpaces(k + k/2); k--;
    std::cout << getHeap().at(0) << "\n";
    
    for (int i = 1; i < getHeapSize(); i++) {
        if (l == j) {
            j = pow(2, j + 1);
            putSpaces(k - 1);
            k = (k + 1)/ 2;
            std::cout << getHeap().at(i) << "\n";
        } else {
            l++;
            putSpaces(k);
            std::cout << getHeap().at(i);
        }
    }
    std::cout << "\n\n";
}

template <class T, class K> void MaxHeap<T, K>::putSpaces(int numberOfSpaces) {
    for (int i = 0; i < numberOfSpaces; i++) std::cout <<" ";
}

template <class T, class K> void MaxHeap<T, K>::setHeapSize(int currentHeapSize) {
    this->heapSize = currentHeapSize;
}

template <class T, class K> void MaxHeap<T, K>::setIsHeap(bool newValueIsHeap) {
    this->isHeap = newValueIsHeap;
}

template <class T, class K> std::vector<Node<T, K>> MaxHeap<T, K>::getHeap() {
    return this->heap;
}

template <class T, class K> int MaxHeap<T, K>::getHeapSize() {
    return this->heapSize;
}

template <class T, class K> bool MaxHeap<T, K>::getIsHeap() {
    return this->isHeap;
}

template <class T, class K> void MaxHeap<T, K>::buildMaxHeap() {
    setHeapSize((int) getHeap().size());
    
    for (int i = (getHeapSize() / 2) - 1; i >= 0; i--) maxHeapify(i);
    setIsHeap(true);
}

template <class T, class K> void MaxHeap<T, K>::maxHeapify(int index) {
    int largest = index;
    int l = left(largest), r = right(largest);
    
    if (l < getHeapSize() && getHeap().at(l).getPriority() > getHeap().at(largest).getPriority()) largest = l;
    if (r < getHeapSize() && getHeap().at(r).getPriority() > getHeap().at(largest).getPriority()) largest = r;
    
    if (largest != index) {
        swap(this->heap.at(index), this->heap.at(largest));
        maxHeapify(largest);
    }
    setIsHeap(true);
}

template <class T, class K> void MaxHeap<T, K>::swap(Node<T, K> &firstNode, Node<T, K> &secondNode) {
    Node<T, K> temp = firstNode;
    firstNode = secondNode;
    secondNode = temp;
}

template <class T, class K> void MaxHeap<T, K>::insert(Node<T, K> newNode) {
    setHeapSize(getHeapSize() + 1);
    this->heap.push_back(newNode);
    
    int i = getHeapSize() - 1;
    while (i > 0 && getHeap().at(parent(i)).getPriority() < getHeap().at(i).getPriority()) {
        swap(this->heap.at(i), this->heap.at(parent(i)));
        i = parent(i);
    }
}

template <class T, class K> void MaxHeap<T, K>::heapSort() {
    buildMaxHeap();
    for (int i = getHeapSize() - 1; i > 0; i--) {
        swap(this->heap.at(0), this->heap.at(i));
        setHeapSize(getHeapSize() - 1);
        maxHeapify(0);
    }
}

template <class T, class K> void MaxHeap<T, K>::changeValueAt(int index, Node<T, K> genericNode,  K key) {
    this->heap.at(index).setPriority(key);
    
    
    int i = getHeapSize() - 1;
//    std::cout << "\nPARENT PRIORITY: " << getHeap().at(parent(index)).getPriority();
//    std::cout << "\nCHILD PRIORITY: " << getHeap().at(index).getPriority();
    while (i > 0 && getHeap().at(parent(index)).getPriority() < getHeap().at(index).getPriority()) {
//        printHeap();
        swap(this->heap.at(index), this->heap.at(parent(index)));
        i = parent(i);
        index = parent(index);
    }
    
//    printHeap();
}

template <class T, class K> void MaxHeap<T, K>::deleteLastElement() {
    this->heap.pop_back();
}
#endif /* MaxHeap_hpp */
