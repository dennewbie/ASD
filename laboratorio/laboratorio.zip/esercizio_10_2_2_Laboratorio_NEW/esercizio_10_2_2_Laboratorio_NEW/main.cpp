//
//  main.cpp
//  esercizio_10_2_2_Laboratorio_NEW
//
//  Created by Denny Caruso on 15/12/2020.
//
//

/*
 
 Progettare ed implementare una classe Priority-queue che implementi le seguenti operazioni:
    • Insert(S,x)
    • Maximum(S) / Minimum(S)
    • Extract-Max(S) / Extract-Min(S)
    • Increase-priority(S,x,k) / Decrease-priority(S,x,k)
 
 */

#include "MaxPriorityQueue.hpp"
#include <string>

int main(int argc, const char * argv[]) {
//    MaxPriorityQueue<int> integerMaxPriorityQueue = MaxPriorityQueue<int>();
//
//    integerMaxPriorityQueue.insertNode(106);
//    integerMaxPriorityQueue.insertNode(105);
//    integerMaxPriorityQueue.insertNode(104);
//    integerMaxPriorityQueue.insertNode(103);
//    integerMaxPriorityQueue.insertNode(110);
//    integerMaxPriorityQueue.insertNode(109);
//    integerMaxPriorityQueue.insertNode(108);
//    integerMaxPriorityQueue.insertNode(107);
//
//    integerMaxPriorityQueue.extractMaximum();
//    integerMaxPriorityQueue.extractMaximum();
//    integerMaxPriorityQueue.extractMaximum();
//    integerMaxPriorityQueue.extractMaximum();
//
//    integerMaxPriorityQueue.increasePriorityAt(100, 5);
//    integerMaxPriorityQueue.increasePriorityAt(3, 1000);
//
//    integerMaxPriorityQueue.extractMaximum();
    
    MaxPriorityQueue<std::string, int> stringPQ = MaxPriorityQueue<std::string, int>();
    
    
    stringPQ.insertNode(Node<std::string, int>("GINO", 10));
    stringPQ.insertNode(Node<std::string, int>("PINO", 2));
    stringPQ.insertNode(Node<std::string, int>("LINO", 3));
    stringPQ.insertNode(Node<std::string, int>("RINO", 4));
    stringPQ.insertNode(Node<std::string, int>("AINO", 11));
    stringPQ.insertNode(Node<std::string, int>("BINO", 122));
    stringPQ.insertNode(Node<std::string, int>("CINO", 33));
    stringPQ.insertNode(Node<std::string, int>("DINO", 44));
    
    Node<std::string, int> temp = stringPQ.getMaximum();
    std::cout << "NODO MAX: " << temp.getPriority() << " " << temp.getData() << "\n\n";
    
    stringPQ.increasePriorityAt(5, 121);
    temp = stringPQ.getMaximum();
    std::cout << "\nNODO MAX: " << temp.getPriority() << " " << temp.getData() << "\n\n";
    
    
    stringPQ.printMaxPQ();
    stringPQ.extractMaximum();
    return 0;
}

