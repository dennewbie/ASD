//
//  Node.hpp
//  esercizio_10_2_2_Laboratorio_NEW
//
//  Created by Denny Caruso on 15/12/2020.
//

#ifndef Node_hpp
#define Node_hpp

template <class T, class K> class Node {
private:
    K priority;
    //        Nodo<T> *left;
    //        Nodo<T> *right;
    T data;
    //        char Huffman;
public:
    Node() {
        this->priority = -1;
    }
    
    Node(T data, K priority) {
        this->priority = priority;
        this->data = data;
    }
    
    Node(K priority) {
        this->priority = priority;
    }
    
    K getPriority() {
        return this->priority;
    }
    
    void setPriority(K priority) {
        this->priority = priority;
    }
    
//    void setLeft(Nodo<T> *l) {left = l;}
//    Nodo<T> *getLeft() {return left;}
//    void setRight(Nodo<T> *r) {right = r;}
//    Nodo<T> *getRight() {return right;}
    T & getData() {
        return this->data;
    }
    
//    char getHuffman() {return Huffman; }
//    void setHuffman(char value) {Huffman = value;}
    void setData(T data) {
        this->data = data;
    }
    
    virtual ~Node() { }
};


#endif /* Node_hpp */
