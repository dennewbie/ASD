//
//  main.cpp
//  esercizio_12_1_Laboratorio
//
//  Created by Denny Caruso on 06/11/2020.
//

/*
     Progettare una classe BinarySearchTree che implementi un
     albero binario di ricerca con le seguenti funzioni
         • SEARCH
         • MINIMUM
         • MAXIMUM
         • PREDECESSOR
         • SUCCESSOR
         • INSERT
         • DELETE
 */

#include "BinarySearchTree.hpp"

int main(int argc, const char * argv[]) {
    BinarySearchTree<int> binSrchTree;
    binSrchTree.insertNode(13, 1);
    binSrchTree.insertNode(15, 2);
    binSrchTree.insertNode(12, 1);
    binSrchTree.insertNode(16, 3);
    binSrchTree.insertNode(10, 1);
    binSrchTree.insertNode(11, 1);
    binSrchTree.insertNode(14, 1);
    binSrchTree.insertNode(17, 4);
    
    binSrchTree.inorderVisit(binSrchTree.getRoot());
    std::cout << std::endl;
    std::cout << "Min = " << binSrchTree.getMinimum(binSrchTree.getRoot())->getKey()
    << " Max = " << binSrchTree.getMaximum(binSrchTree.getRoot())->getKey() << std::endl;
    
    Node<int> *newNode;
    newNode = binSrchTree.getPredecessor(binSrchTree.getRoot());
    if (newNode != nullptr) std::cout << "\nPredecessor: " << newNode->getKey() << "\n";
    
    newNode = binSrchTree.getSuccessor(binSrchTree.getRoot());
    if (newNode != nullptr) std::cout << "\nSuccessor: " << newNode->getKey() << "\n";
    
    newNode = binSrchTree.searchNode(21, binSrchTree.getRoot());
    if (newNode != nullptr) std::cout << "\nValore Trovato: " << newNode->getKey() << "\n";
    
    std::cout << "\n\nCancello node con Chiave 15...";
    binSrchTree.deleteNode(15);
    std::cout << "\n\nINORDER: ";
    binSrchTree.inorderVisit(binSrchTree.getRoot());
    std::cout << "\n\nPOSTRDER: ";
    binSrchTree.postorderVisit(binSrchTree.getRoot());
    std::cout << "\n\nPREORDER: ";
    binSrchTree.preorderVisit(binSrchTree.getRoot());
    std::cout << "\n\n";
    
    std::cout << "\nAltezza Albero: " << binSrchTree.getHeight(binSrchTree.getRoot()) << "\n\n";
    return 0;
}
