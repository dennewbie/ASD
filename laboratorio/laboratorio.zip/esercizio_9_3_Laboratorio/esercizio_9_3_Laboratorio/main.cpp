//
//  main.cpp
//  esercizio_9_3_Laboratorio
//
//  Created by Denny Caruso on 26/10/2020.
//

/*
    Progettare ed implementare un algoritmo ricorsivo che dato un array verifichi se rappresenta un heap binario
 */

#include <iostream>

bool checkMaxHeap(int *arr, int n, int i);
int left(int index);
int right(int index);

int main(int argc, const char * argv[]) {
    int array[] = { 20, 19, 18, 17, 16, 15, 14, 10 };

    bool isHeap = checkMaxHeap(array, sizeof(array) / sizeof(array[0]), 0);
    std::cout << std::boolalpha << "isHeap: " << isHeap << "\n\n";
    
    return 0;
}

bool checkMaxHeap(int *arr, int n, int i) {
    if (i > (n - 2) / 2) return true;

    bool l = ((arr[i] >= arr[left(i)]) && checkMaxHeap(arr, n, left(i)));
    bool r = ((arr[i] >= arr[right(i)]) && checkMaxHeap(arr, n, right(i)));
    return l && r;
}

int left(int index) { return (2 * index) + 1; }
int right(int index) { return (2 * index) + 2; }
