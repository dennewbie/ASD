//
//  main.cpp
//  esercizio_7_1_Laboratorio
//
//  Created by Denny Caruso on 19/10/2020.
//

/*
//    Riscrivere il Merge Sort utilizzando il contenitore Vector ed un iteratore
// */

//Con Template ma non funziona per le stringhe. Testata solo per interi
//#include <iostream>
//#include <vector>
//
//template <class T> void mergeSort(typename std::vector<T>::iterator low,
//                                  typename std::vector<T>::iterator high);
//template <class T> void merge(typename std::vector<T>::iterator low,
//                              typename std::vector<T>::iterator mid,
//                              typename std::vector<T>::iterator high);
//template <class T> void printArray(std::vector<T> arr);
//
//int main(int argc, const char * argv[]) {
//    std::vector<int> array = { 100, 9, -1, 20, 6, 6, 32, 16, -5, 111, 2 };
//
//    mergeSort<int>(array.begin(), array.end());
//    printArray(array);
//    return 0;
//}
//
//template <class T> void printArray(std::vector<T> arr) {
//    typename std::vector<T>::iterator it;
//    std::cout << "------------------\n";
//    for (it = arr.begin(); it != arr.end(); it++) std::cout << *it << "\n";
//    std::cout << "\n\n";
//}
//
//template <class T> void mergeSort(typename std::vector<T>::iterator low, typename std::vector<T>::iterator high) {
//    auto size = std::distance(low, high);
//    if (size < 2) return;
//    auto mid = std::next(low, size / 2);
//
//    mergeSort<T>(low, mid);
//    mergeSort<T>(mid, high);
//    merge<T>(low, mid, high);
//}
//
//template <class T> void merge(typename std::vector<T>::iterator low, typename std::vector<T>::iterator mid, typename std::vector<T>::iterator high) {
//    auto distance = std::distance(low, high);
//    std::vector<T> localArray(distance);
//    int index = (int) distance / 2;
//
//    typename std::vector<T>::iterator i, j, k;
//    for (i = mid; i != low; i--) localArray.at(index--) = *i;
//    localArray.at(index--) = *i;
//
//    index = (int) distance - 1;
//    for (i = mid; i != high; i++) localArray.at(index--) = *i;
//
//    i = localArray.begin(), j = localArray.end() - 1;
//    for (k = low; k != high; k++) {
//        if (*j < *i) {
//            *k = *j;
//            std::advance(j, -1);
//        } else {
//            *k = *i;
//            std::advance(i, 1);
//        }
//    }
//}



//Versione senza Template Mia
#include <iostream>
#include <vector>

void mergeSort(std::vector<int>::iterator low, std::vector<int>::iterator high);
void merge(std::vector<int>::iterator low, std::vector<int>::iterator mid, std::vector<int>::iterator high);
template <class T> void printArray(std::vector<T> arr);

int main(int argc, const char * argv[]) {
    std::vector<int> array = { 100, 9, -1, 20, 6, 6, 32, 16, -5, 111, 2 };

    mergeSort(array.begin(), array.end());
    printArray(array);
    return 0;
}

template <class T> void printArray(std::vector<T> arr) {
    typename std::vector<T>::iterator it;
    for (it = arr.begin(); it != arr.end(); it++) std::cout << *it << "\n";
    std::cout << "\n\n";
}

void mergeSort(std::vector<int>::iterator low, std::vector<int>::iterator high) {
    auto size = std::distance(low, high);
    if (size < 2) return;
    auto mid = std::next(low, size / 2);

    mergeSort(low, mid);
    mergeSort(mid, high);
    merge(low, mid, high);
}

void merge(typename std::vector<int>::iterator low, typename std::vector<int>::iterator mid, typename std::vector<int>::iterator high) {
    auto distance = std::distance(low, high);
    std::vector<int> localArray(distance);
    int index = (int) distance / 2;

    std::vector<int>::iterator i, j, k;
    for (i = mid; i != low; i--) localArray.at(index--) = *i;
    localArray.at(index--) = *i;

    index = (int) distance - 1;
    for (i = mid; i != high; i++) localArray.at(index--) = *i;

    i = localArray.begin();
    j = localArray.end() - 1;
    for (k = low; k != high; k++) {
        if (*j < *i) {
            *k = *j;
            std::advance(j, -1);
        } else {
            *k = *i;
            std::advance(i, 1);
        }
    }
}



// Versione Professore
//#include <iterator>
//#include <vector>
//#include <iostream>
//
//void printv(std::vector<int> p) {
//    std::vector<int>::iterator i;
//    for (i = p.begin(); i < p.end(); i++) std::cout<< *i << " ";
//    std::cout << std::endl;
//}
//
//void mergeR(std::vector<int> *out,
//            std::vector<int>::iterator begin,
//            std::vector<int>::iterator mid,
//            std::vector<int>::iterator midp,
//            std::vector<int>::iterator end) {
//    if (begin <= mid && midp <= end) {
//        out->push_back((*begin <= *midp) ? *begin++ : *midp++);
//        mergeR(out, begin, mid, midp, end);
//    } else if(midp > end){
//        out->insert(out->end(), begin, mid + 1);
//    } else{
//        out->insert(out->end(), midp, end);
//    }
//}
//
//void merge_sort(std::vector<int>::iterator begin, std::vector<int>::iterator end) {
//    if (begin < end){
//        auto off = distance(begin, end) / 2;
//        auto mid = begin + off;
//        merge_sort(begin, mid);
//        merge_sort(mid + 1, end);
//        std::vector<int> v;
//        mergeR(&v, begin, mid, mid + 1, end);
//        move(v.begin(), v.end(), begin);
//    }
//}
//
//int main(){
//    std::vector<int> v{ 10, 34, 6, 9, 16, 33 };
//    merge_sort(v.begin(), v.end() - 1);
//    printv(v);
//}
