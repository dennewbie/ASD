//
//  HashTable.hpp
//  esercizio_22_1_1_Laboratorio
//
//  Created by Denny Caruso on 12/12/2020.
//

#ifndef HashTable_hpp
#define HashTable_hpp

#include <iostream>
#include <list>
#include <vector>
#define knutSuggestion 0.6180339887

class HashTable {
private:
    unsigned int dim;
    std::vector<std::list<int>> table;
    unsigned int hashFunctionDivsion(int key);
    unsigned int hashFunctionMultiplication(int key);
    
    void setDim(unsigned int newDim);
    void setTable(std::vector<std::list<int>> newTable);
    
    std::vector<std::list<int>> getTable();
    
public:
    HashTable(unsigned int N) {
        setDim(N);
        setTable(std::vector<std::list<int>>(getDim()));
    }
    
    unsigned int getDim();
    
    void hashInsert(int key);
    void hashDelete(int key);
    bool hashSearch(int key);
    void displayHash();
    
    bool containsThisMap(HashTable anotherMap);
};

#endif /* HashTable_hpp */
