//
//  Stack.hpp
//  esercizio_8_2_Laboratorio
//
//  Created by Denny Caruso on 23/10/2020.
//

#ifndef Stack_hpp
#define Stack_hpp

#include <iostream>

template <typename T> class Stack {
private:
    int dim;
    int top;
    T  *vett;
    
    void setDim(int newDim);
    void setTop(int newTop);
public:
    Stack() {
        dim = 0;
        top = -1;
        vett = nullptr;
    }
    
    void push(T elementToPush);
    bool pop(T &poppedElement);
    int getDim();
    int getTop();
};

template <typename T> void Stack<T>::push(T elementToPush) {
    if (getTop() == getDim() - 1) {
        T* tempArray = new T[getDim() + 10];
        for (int i = 0; i < getDim(); i++) tempArray[i] = this->vett[i];
        
        setDim(getDim() + 10);
        delete [] this->vett;
        this->vett = tempArray;
    }
    int newTop = getTop();
    this->vett[newTop++] = elementToPush;
    setTop(newTop++);
}

template <typename T> bool Stack<T>::pop(T &poppedElement) {
    bool isElementPopped;
    if (getTop() >= 0) {
        isElementPopped = true;

        poppedElement = this->vett[getTop() - 1];
        setTop(getTop() - 1);
    } else {
        isElementPopped = false;
    }
    
    return isElementPopped;
}

template <typename T> int Stack<T>::getDim() {
    return this->dim;
}

template <typename T> int Stack<T>::getTop() {
    return this->top;
}

template <typename T> void Stack<T>::setDim(int newDim) {
    this->dim = newDim;
}
    
template <typename T> void Stack<T>::setTop(int newTop) {
    this->top = newTop;
}

#endif /* Stack_hpp */
