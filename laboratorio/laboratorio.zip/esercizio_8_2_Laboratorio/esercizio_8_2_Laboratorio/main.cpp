//
//  main.cpp
//  esercizio_8_2_Laboratorio
//
//  Created by Denny Caruso on 23/10/2020.
//

/*
    Progettare ed implementare una procedura quicksort iterativa. Usare lo stack illustrato nella lezione 4
 */

#include <iostream>
#include <map>
#include <vector>
#include <iterator>
#include <ctime>
#include <cstdlib>
#include "Stack.hpp"

#define M 15

template <class T> void printArray(std::vector<T> arr);
template <class T> void swapper(T &firstElement, T &secondElement);

void insertionSort(std::vector<int>::iterator low, std::vector<int>::iterator high);
void iterativeQuickSort(std::vector<int>::iterator low, std::vector<int>::iterator high);

std::vector<int>::iterator partition(std::vector<int>::iterator low, std::vector<int>::iterator high);
void randPartition(std::vector<int>::iterator low, std::vector<int>::iterator high);


int main(int argc, const char * argv[]) {
    srand((unsigned int) time(NULL));
    std::vector<int> array = { 100, 9, -1, 20, 6, 6, 32, 16, -5, 111, 2, -40, -1000, 30, 22, 1101, 33, 100, 9 };
    printArray(array);
    
    iterativeQuickSort(array.begin(), array.end() - 1);
    printArray(array);
    return 0;
}

template <class T> void printArray(std::vector<T> arr) {
    typename std::vector<T>::iterator it;
    for (it = arr.begin(); it != arr.end(); it++) std::cout << *it << "\n";
    std::cout << "\n\n";
}

template <class T> void swapper(T &firstElement, T &secondElement) {
    T temp = firstElement;
    firstElement = secondElement;
    secondElement = temp;
}

void insertionSort(std::vector<int>::iterator low, std::vector<int>::iterator high) {
    auto i = low, j = low;
    int key;
    for (i = low + 1; i <= high; i++) {
        key = *i;
        j = i - 1;

        while (j >= low && *j > key) {
            *(j + 1) = *j;
            j--;
        }
        j++;
        *j = key;
    }
}

void iterativeQuickSort(std::vector<int>::iterator low, std::vector<int>::iterator high) {
    Stack<std::pair<std::vector<int>::iterator, std::vector<int>::iterator>> quickSortPairs;
    quickSortPairs.push(std::make_pair(low, high));
    std::pair<std::vector<int>::iterator, std::vector<int>::iterator> tempPair;
    int distance;
    
    while (quickSortPairs.getTop() > -1) {
        if (quickSortPairs.pop(tempPair)) {
            auto mid = partition(tempPair.first, tempPair.second);
            
            distance = (int) (std::distance(tempPair.first, mid - 1));
            if (distance > M) {
                quickSortPairs.push(std::make_pair(tempPair.first, mid - 1));
            } else {
                insertionSort(tempPair.first, mid - 1);
            }
            
            distance = (int) (std::distance(mid + 1, tempPair.second));
            if (distance > M) {
                quickSortPairs.push(std::make_pair(mid + 1, tempPair.second));
            } else {
                insertionSort(mid + 1, tempPair.second);
            }
        }
    }
}

std::vector<int>::iterator partition(std::vector<int>::iterator low, std::vector<int>::iterator high) {
    randPartition(low, high);
    
    auto pivot = low, i = low + 1;
    for(std::vector<int>::iterator j = low + 1; j <= high; j++){
        if(*j < *pivot){
            swapper(*j, *i);
            std::advance(i, 1);
        }
    }

    std::advance(i, -1);
    swapper(*low, *i);
    return i;
}

void randPartition(std::vector<int>::iterator low, std::vector<int>::iterator high) {
    auto randomIndex = 1 + rand() % (std::distance(low, high) + 1);
    auto pivot = low;
    std::advance(pivot, randomIndex);
    swapper(*pivot, *low);
}
