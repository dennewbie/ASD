//
//  main.cpp
//  esercizio_14_2_Laboratorio
//
//  Created by Denny Caruso on 14/11/2020.
//

/*
    Dato un ABR, trovare la minima differenza tra le chiavi di due nodi
 */

#include "BinarySearchTree.hpp"

int main(int argc, const char * argv[]) {
    BinarySearchTree<float> binSrchTree;
    binSrchTree.insertNode(50, 1);
    binSrchTree.insertNode(29, 1);
    binSrchTree.insertNode(60, 1);
    binSrchTree.insertNode(9, 1);
    binSrchTree.insertNode(51, 1);
    binSrchTree.insertNode(39, 1);
    binSrchTree.insertNode(69, 1);

//    std::cout << "\n\n";
//    binSrchTree.preorderVisit(50);
//    std::cout << "\n\n";
    
    int minDiff = (binSrchTree.getRootKey() - binSrchTree.getPredecessor(binSrchTree.getRootKey()).getKey());
    Node<float> minNode1 = Node<float>();
    Node<float> minNode2 = Node<float>();
    
    binSrchTree.lessDifferenceBetweenNode(50, &minDiff, &minNode1, &minNode2);
    
    std::cout << "MIN DIFF: " << minDiff << "\n" << "NODE1: " << minNode1.getKey() << "\nNODE2: "<< minNode2.getKey() << "\n";
    return 0;
}
