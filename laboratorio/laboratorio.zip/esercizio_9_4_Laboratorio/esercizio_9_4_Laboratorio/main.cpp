//
//  main.cpp
//  esercizio_9_4_Laboratorio
//
//  Created by Denny Caruso on 26/10/2020.
//

#include "KMaxHeap.hpp"

int main(int argc, const char * argv[]) {
    std::vector<int> testArray { 10, 1, 50, 80, 90, 100, 12, 23 };
//    std::vector<int> testArray { 10, 9, 8, 7, 6, 5, 4, 3 };
    KMaxHeap<int> integerHeap = KMaxHeap<int>(testArray, 3);
    
    integerHeap.printHeap();
    integerHeap.buildMaxHeap();
    integerHeap.printHeap();
    
    integerHeap.insert(110);
    integerHeap.printHeapTree();
    return 0;
}
