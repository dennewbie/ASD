//
//  KHeap.hpp
//  esercizio_9_4_Laboratorio
//
//  Created by Denny Caruso on 26/10/2020.
//

#ifndef KMaxHeap_hpp
#define KMaxHeap_hpp

#include <iostream>
#include <vector>
#include <math.h>

template <class T> class KMaxHeap {
private:
    int heapSize;
    bool isHeap;
    std::vector<T> heap;
    int kChild;
    
    void setHeapSize(int currentHeapSize);
    void setIsHeap(bool);
    
    std::vector<T> getHeap();
    int getHeapSize();
    bool getIsHeap();
    int getK();
    
    int parent(int i);
    //    int left(int i);
    //    int right(int i);
    
    void maxHeapify(int i);
    void swap(T &firstNode, T &secondNode);
    
    void putSpaces(int numberOfSpaces);
public:
    KMaxHeap() {
        this->heapSize = 0;
        this->isHeap = true;
        this->kChild = 2;
    }
    
    KMaxHeap(int kChild) {
        this->heapSize = 0;
        this->isHeap = true;
        if (kChild > 0) {
            this->kChild = kChild;
        } else {
            this->kChild = 2;
        }
    }
    
    KMaxHeap(std::vector<T> heap) {
        this->heap = heap;
        this->heapSize = 0;
        this->isHeap = false;
    }
    
    KMaxHeap(std::vector<T> heap, int kChild) {
        this->heap = heap;
        this->heapSize = 0;
        this->isHeap = false;
        if (kChild > 0) {
            this->kChild = kChild;
        } else {
            this->kChild = 2;
        }
    }
    
    
    
    virtual ~KMaxHeap() { }
    void printHeap();
    void printHeapTree();
    void buildMaxHeap();
    void insert(T newNode);
};

template <class T> int KMaxHeap<T>::parent(int i){
    return (i - 1) / getK();
}

//template <class T> int KMaxHeap<T>::left(int i, int k){
//    return (2 * i) + 1;
//}
//
//template <class T> int KMaxHeap<T>::right(int i){
//    return (2 * i) + 2;
//}

template <class T> void KMaxHeap<T>::printHeap() {
    for (auto node: this->heap) std::cout << node << "\n";
    std::cout << "\n\n";
}

template <class T> void KMaxHeap<T>::printHeapTree() {
    int j = 1, k = getHeapSize(), l = 2 - getK();
    putSpaces(k + k/2); k--;
    std::cout << getHeap().at(0) << "\n";

    for (int i = 1; i < getHeapSize(); i++) {
        if (l == j) {
            j = pow(getK(), j + 1);
            putSpaces(k - 1);
            k = (k + 1)/ 2;
            std::cout << getHeap().at(i) << "\n";
        } else {
            l++;
            putSpaces(k);
            std::cout << getHeap().at(i);
        }
    }
    std::cout << "\n\n";
}

template <class T> void KMaxHeap<T>::putSpaces(int numberOfSpaces) {
    for (int i = 0; i < numberOfSpaces; i++) std::cout <<" ";
}

template <class T> void KMaxHeap<T>::setHeapSize(int currentHeapSize) {
    this->heapSize = currentHeapSize;
}

template <class T> void KMaxHeap<T>::setIsHeap(bool newValueIsHeap) {
    this->isHeap = newValueIsHeap;
}

template <class T> std::vector<T> KMaxHeap<T>::getHeap() {
    return this->heap;
}

template <class T> int KMaxHeap<T>::getHeapSize() {
    return this->heapSize;
}

template <class T> bool KMaxHeap<T>::getIsHeap() {
    return this->isHeap;
}

template <class T> int KMaxHeap<T>::getK() {
    return this->kChild;
}

template <class T> void KMaxHeap<T>::buildMaxHeap() {
    setHeapSize((int) getHeap().size());
    
    for (int i = (getHeapSize() / getK()) - 1; i >= 0; i--) maxHeapify(i);
    setIsHeap(true);
}

template <class T> void KMaxHeap<T>::maxHeapify(int index) {
    int k = getK();
//    per comodità faccio partire l'array dei figli da 1
    T child[getK() + 1];
    
    while (true) {
        // child[i] = -1 se il nodo figlio è un nodo foglia oltre che figlio
        for (int i = 1; i <= k; i++) {
            if ((k * index + i) < getHeapSize()) {
                child[i] = k * index + i;
            } else {
                child[i] = -1;
            }
        }
        
        int maxChild = -1, maxChildIndex = 0 ;
        
        // trova il massimo nodo figlio tra quelli dati
        for (int i = 1; i <= k; i++) {
            if (child[i] != -1 && getHeap().at(child[i]) > maxChild) {
                maxChildIndex = child[i];
                maxChild = getHeap().at(child[i]);
            }
        }
        
        // nodo foglia
        if (maxChild == -1) break;
        
        if (getHeap().at(index) < getHeap().at(maxChildIndex)) {
            swap(this->heap[index], this->heap[maxChildIndex]);
        }
        index = maxChildIndex;
    }
}

template <class T> void KMaxHeap<T>::swap(T &firstNode, T &secondNode) {
    T temp = firstNode;
    firstNode = secondNode;
    secondNode = temp;
}

template <class T> void KMaxHeap<T>::insert(T newNode) {
    setHeapSize(getHeapSize() + 1);
    this->heap.push_back(newNode);

    int i = getHeapSize() - 1;
    while (i > 0 && getHeap().at(parent(i)) < getHeap().at(i)) {
        swap(this->heap[i], this->heap[parent(i)]);
        i = parent(i);
    }
}

#endif /* KMaxHeap_hpp */

