//
//  main.cpp
//  esercizio_15_1_Laboratorio
//
//  Created by Denny Caruso on 16/11/2020.
//

/*
     Implementare l'algoritmo FASTEST-WAY.
    Progettare ed implementare una procedura che visualizzi il percorso tra le due catene di montaggio
    dalla stazione 1 alla stazione n.
    
    Un'altra soluzione è la seguente: S1,1-S2,2-S1,3-S1,4-S2,5- S1,6 oppure 1-2-1-1-2-1 (non quella evidenziata in figura)
 */

#include <iostream>
#include "AssemblyLine.hpp"


// error: there is something doesn't work while printing solution
int main(int argc, const char * argv[]) {
    unsigned int assemblyLineStationDimension = 6;
    
    unsigned int enterTime_1 = 2,   enterTime_2 = 4;
    unsigned int exitTime_1 = 3,    exitTime_2 = 2;
    
    std::vector<unsigned int> time1 = { 2, 3, 1, 1, 4 };
    std::vector<unsigned int> time2 = { 2, 1, 2, 2, 1 };
    
    std::vector<unsigned int> activitiesTime_1 = { 7, 9, 3, 4, 8, 4 };
    std::vector<unsigned int> activitiesTime_2 = { 8, 5, 6, 4, 5, 7 };
    
    AssemblyLine carAssemblyLine = AssemblyLine(assemblyLineStationDimension, enterTime_1, enterTime_2, exitTime_1, exitTime_2, time1, time2, activitiesTime_1, activitiesTime_2);
    
    
    std::string fastestWayString = carAssemblyLine.fastestWay();
    std::cout << "FASTEST WAY: " << fastestWayString << "\nTotal Time: " << carAssemblyLine.getTotalTime() << "\nLast Choice: " << carAssemblyLine.getLastChoice() << "\n";
    
    return 0;
}
