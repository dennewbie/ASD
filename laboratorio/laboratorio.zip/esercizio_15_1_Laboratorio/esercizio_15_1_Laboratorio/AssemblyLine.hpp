//
//  AssemblyLine.hpp
//  esercizio_15_1_Laboratorio
//
//  Created by Denny Caruso on 16/11/2020.
//

#ifndef AssemblyLine_hpp
#define AssemblyLine_hpp

#include <string>
#include <vector>

class AssemblyLine {
private:
    unsigned int assemblyLineStationDimension;
    
    std::vector<std::string> assemblyLineStation_1;
    std::vector<std::string> assemblyLineStation_2;
    
    unsigned int enterTime_1;
    unsigned int enterTime_2;
    unsigned int exitTime_1;
    unsigned int exitTime_2;
    
    std::vector<unsigned int> time1;
    std::vector<unsigned int> time2;
    
    std::vector<unsigned int> choices_1;
    std::vector<unsigned int> choices_2;
    
    std::vector<unsigned int> partialTime_1;
    std::vector<unsigned int> partialTime_2;
    
    std::vector<unsigned int> activitiesTime_1;
    std::vector<unsigned int> activitiesTime_2;
    
    unsigned int totalTime;
    unsigned int lastChoice;
    
    void calculateFastestWay();

public:
    AssemblyLine(unsigned int assemblyLineStationDimension, unsigned int enterTime_1, unsigned int enterTime_2, unsigned int exitTime_1, unsigned int exitTime_2, std::vector<unsigned int> time1, std::vector<unsigned int> time2, std::vector<unsigned int> activitiesTime_1, std::vector<unsigned int> activitiesTime_2) {
        this->assemblyLineStationDimension = assemblyLineStationDimension;
        this->enterTime_1 = enterTime_1;
        this->enterTime_2 = enterTime_2;
        this->exitTime_1 = exitTime_1;
        this->exitTime_2 = exitTime_2;
        this->time1 = time1;
        this->time2 = time2;
        this->activitiesTime_1 = activitiesTime_1;
        this->activitiesTime_2 = activitiesTime_2;
        this->totalTime = 0;
        this->lastChoice = 0;
        
        for (int i = 0; i < this->assemblyLineStationDimension; i++) {
            std::string newString1 = "S [1, ";
            newString1.append(std::to_string(i + 1));
            newString1.append("] <- ");
            assemblyLineStation_1.push_back(newString1);
            
            
            std::string newString2 = "S [2, ";
            newString2.append(std::to_string(i + 1));
            newString2.append("] <- ");
            assemblyLineStation_2.push_back(newString2);
            
            this->partialTime_1.push_back(0);
            this->partialTime_2.push_back(0);
            this->choices_1.push_back(0);
            this->choices_2.push_back(0);
        }
    }
    
    unsigned int getTotalTime();
    unsigned int getLastChoice();
    
    std::string fastestWay();
};

#endif /* AssemblyLine_hpp */
