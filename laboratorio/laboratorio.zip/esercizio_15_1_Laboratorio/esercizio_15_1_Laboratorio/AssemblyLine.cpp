//
//  AssemblyLine.cpp
//  esercizio_15_1_Laboratorio
//
//  Created by Denny Caruso on 16/11/2020.
//

#include "AssemblyLine.hpp"

unsigned int AssemblyLine::getTotalTime() {
    return this->totalTime;
}

unsigned int AssemblyLine::getLastChoice() {
    return this->lastChoice;
}

void AssemblyLine::calculateFastestWay() {
    this->partialTime_1.at(0) = this->enterTime_1 + this->activitiesTime_1.at(0);
    this->partialTime_2.at(0) = this->enterTime_2 + this->activitiesTime_2.at(0);
    
    for (int j = 1; j < this->assemblyLineStationDimension; j++) {
        if (this->partialTime_1.at(j - 1) + this->activitiesTime_1.at(j) <= this->partialTime_2.at(j - 1) + this->activitiesTime_1.at(j) + this->time2.at(j-1)) {
            this->partialTime_1.at(j) = this->partialTime_1.at(j - 1) + this->activitiesTime_1.at(j);
            this->choices_1.at(j) = 1;
        } else {
            this->partialTime_1.at(j) = this->partialTime_2.at(j - 1) + this->activitiesTime_1.at(j) + this->time2.at(j - 1);
            this->choices_1.at(j) = 2;
        }
        
        if (this->partialTime_2.at(j - 1) + this->activitiesTime_2.at(j) <= this->partialTime_1.at(j - 1) + this->activitiesTime_2.at(j) + this->time1.at(j-1)) {
            this->partialTime_2.at(j) = this->partialTime_2.at(j - 1) + this->activitiesTime_2.at(j);
            this->choices_2.at(j) = 2;
        } else {
            this->partialTime_2.at(j) = this->partialTime_1.at(j - 1) + this->activitiesTime_2.at(j) + this->time1.at(j - 1);
            this->choices_2.at(j) = 1;
        }
    }
    
    if ((this->partialTime_1.at(this->assemblyLineStationDimension - 1) + this->exitTime_1) <= (this->partialTime_2.at(this->assemblyLineStationDimension - 1) + this->exitTime_2)) {
        this->totalTime = (this->partialTime_1.at(this->assemblyLineStationDimension - 1) + this->exitTime_1);
        this->lastChoice = 1;
    } else {
        this->totalTime = (this->partialTime_2.at(this->assemblyLineStationDimension - 1) + this->exitTime_2);
        this->lastChoice = 2;
    }
}

std::string AssemblyLine::fastestWay() {
    calculateFastestWay();
    std::vector<std::string> printString;
    
    switch (this->lastChoice) {
        case 1:
            printString.push_back(this->assemblyLineStation_1.at(assemblyLineStationDimension - 1));
            
            for (int i = assemblyLineStationDimension - 1; i >= 1; i--) {
                switch (this->choices_1.at(i)) {
                    case 1:
                        printString.push_back(this->assemblyLineStation_1.at(i - 1));
                        break;
                    case 2:
                        printString.push_back(this->assemblyLineStation_2.at(i - 1));
                        break;
                    default:
                        exit(0);
                        break;
                }
            }
            break;
        case 2:
            printString.push_back(this->assemblyLineStation_2.at(assemblyLineStationDimension - 1));

            for (int i = assemblyLineStationDimension - 1; i >= 1; i--) {
                switch (this->choices_2.at(i)) {
                    case 1:
                        printString.push_back(this->assemblyLineStation_1.at(i - 1));
                        break;
                    case 2:
                        printString.push_back(this->assemblyLineStation_2.at(i - 1));
                        break;
                    default:
                        exit(0);
                        break;
                }
            }
            break;
        default:
            exit(0);
            break;
    }
    
    std::string finalString;
    for (auto it = printString.begin(); it != printString.end(); it++) finalString.append(*it);
    return finalString;
}
