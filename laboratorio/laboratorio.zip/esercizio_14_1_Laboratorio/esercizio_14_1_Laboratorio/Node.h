//
//  Node.h
//  esercizio_14_1_Laboratorio
//
//  Created by Denny Caruso on 14/11/2020.
//

#ifndef Node_h
#define Node_h

enum color { BLACK, RED };

template <class T> class Node {
private:
    int key;
    bool color;
    Node * parent;
    Node * left;
    Node * right;
    T data;
    
public:
    Node() : parent { nullptr }, left { nullptr }, right { nullptr } {
        this->color = BLACK;
//        this->key = -1;
    }
    
    Node(int key, T data) : parent { nullptr }, left { nullptr }, right { nullptr } {
        this->key = key;
        this->data = data;
    }
    
    int getKey() {
        return this->key;
    }
    
    void setParent(Node *newParent) {
        parent = newParent;
    }
    
    Node * getParent() {
        return this->parent;
    }
    
    void setLeft(Node *newLeft) {
        this->left = newLeft;
    }
    
    Node * getLeft() {
        return this->left;
    }
    
    void setRight(Node *newRight) {
        this->right = newRight;
    }
    
    Node * getRight() {
        return right;
    }
    
    T & getData() {
        return this->data;
    }
    
    virtual ~Node() { }
    
    void setColor(bool newColor);
    bool getColor();
};

template <class T> void Node<T>::setColor(bool newColor) {
    this->color = newColor;
}

template <class T> bool Node<T>::getColor() {
    return this->color;
}

#endif /* Node_h */
