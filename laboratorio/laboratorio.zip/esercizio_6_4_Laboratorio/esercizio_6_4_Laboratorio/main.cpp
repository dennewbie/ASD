//
//  main.cpp
//  esercizio_6_4_Laboratorio
//
//  Created by Denny Caruso on 16/10/2020.
//

/*
    Dato un insieme di N numeri, trovare il numero più frequente
 */

#include <iostream>
#include <map>

void printMap(std::map<int, int>);
int getNumberWithMostOccourrences(std::map<int, int>);
int getNumberWithMostOccourrences(int *arr, int size);
void insertionSort(int *, int);

int main(int argc, const char * argv[]) {
    int array[] = { 100, 30, 20, 50, 1 , 20, 10, 10, 13, 20 };
    int size = ( sizeof(array) / sizeof(array[0]) );
    std::map<int, int> numberMap;

//    for (auto i = 0; i < size; i++) numberMap[array[i]]++;

//    printMap(numberMap);
//    int numberWithMostOccurrences = getNumberWithMostOccourrences(numberMap);
    
    insertionSort(array, size);
    int numberWithMostOccurrences = getNumberWithMostOccourrences(array, size);
    std::cout << "\nNumero con maggiori occorrenze: " << numberWithMostOccurrences << "\n\n";
    for (int i = 0; i < 10; i++) std::cout << array[i] << std::endl;
    
    return 0;
}

void printMap(std::map<int, int> numberMap) {
    for (auto i = numberMap.begin(); i != numberMap.end(); i++) std::cout << "Numero: " << i->first << "\t\tOccorrenze: " << i->second << "\n";
}

int getNumberWithMostOccourrences(std::map<int, int> numberMap) {
    if (numberMap.size() == 0) return -1;
    int max = 0, key;
    for (auto i = numberMap.begin(); i != numberMap.end(); i++) {
        if (i->second > max) {
            max = i->second;
            key = i->first;
        }
    }
    return numberMap.find(key)->first;
}


int getNumberWithMostOccourrences(int *arr, int size) {
    int maxOccourrences = 1, numberWithMostOccurrences = arr[0];
    int i = 1;
    int locMaxOcc = 0;

    while (i < size) {
        if (arr[i] == arr[i - 1]) {
            ++locMaxOcc;
            
            if (locMaxOcc > maxOccourrences) {
                maxOccourrences = locMaxOcc;
                numberWithMostOccurrences = arr[i];
            }
        } else {
            locMaxOcc = 0;
        }
        i++;
    }
    
    return numberWithMostOccurrences;
}

void insertionSort(int *arr, int size) {
    int i, key, j;
    for (i = 1; i < size; i++) {
        key = arr[i];
        j = i - 1;

        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}
