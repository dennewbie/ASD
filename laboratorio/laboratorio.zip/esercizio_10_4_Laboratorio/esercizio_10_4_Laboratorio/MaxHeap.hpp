//
//  MaxHeap.hpp
//  esercizio_10_4_Laboratorio
//
//  Created by Denny Caruso on 30/10/2020.
//

#ifndef MaxHeap_hpp
#define MaxHeap_hpp

#include <iostream>
#include <vector>
#include <math.h>

template <class T> class MaxHeap {
private:
    int heapSize;
    bool isHeap;
    std::vector<T> heap;
    
    void setHeapSize(int currentHeapSize);
    void setIsHeap(bool);
    
    std::vector<T> getHeap();
    int getHeapSize();
    bool getIsHeap();
    
    int parent(int i);
    int left(int i);
    int right(int i);
    
    void maxHeapify(int i);
    void swap(T &firstNode, T &secondNode);
    
    void putSpaces(int numberOfSpaces);
public:
    MaxHeap() {
        this->heapSize = 0;
        this->isHeap = true;
    }
    
    MaxHeap(std::vector<T> heap) {
        this->heap = heap;
        this->heapSize = 0;
        this->isHeap = false;
    }
    
    virtual ~MaxHeap() { }
    void printHeap();
    void printArray();
    void printHeapTree();
    void buildMaxHeap();
    void insert(T newNode);
    void heapSort();
};

template <class T> int MaxHeap<T>::parent(int i){
    return (i - 1) / 2;
}

template <class T> int MaxHeap<T>::left(int i){
    return (2 * i) + 1;
}

template <class T> int MaxHeap<T>::right(int i){
    return (2 * i) + 2;
}

template <class T> void MaxHeap<T>::printHeap() {
    for (int i = 0; i < getHeapSize(); i++) std::cout << getHeap().at(i) << "\n";
    std::cout << "\n\n";
}

template <class T> void MaxHeap<T>::printArray() {
    for (auto node: this->heap) std::cout << node << "\n";
    std::cout << "\n\n";
}

template <class T> void MaxHeap<T>::printHeapTree() {
    int j = 1, k = getHeapSize(), l = 0;
    putSpaces(k + k/2); k--;
    std::cout << getHeap().at(0) << "\n";
    
    for (int i = 1; i < getHeapSize(); i++) {
        if (l == j) {
            j = pow(2, j + 1);
            putSpaces(k - 1);
            k = (k + 1)/ 2;
            std::cout << getHeap().at(i) << "\n";
        } else {
            l++;
            putSpaces(k);
            std::cout << getHeap().at(i);
        }
    }
    std::cout << "\n\n";
}

template <class T> void MaxHeap<T>::putSpaces(int numberOfSpaces) {
    for (int i = 0; i < numberOfSpaces; i++) std::cout <<" ";
}

template <class T> void MaxHeap<T>::setHeapSize(int currentHeapSize) {
    this->heapSize = currentHeapSize;
}

template <class T> void MaxHeap<T>::setIsHeap(bool newValueIsHeap) {
    this->isHeap = newValueIsHeap;
}

template <class T> std::vector<T> MaxHeap<T>::getHeap() {
    return this->heap;
}

template <class T> int MaxHeap<T>::getHeapSize() {
    return this->heapSize;
}

template <class T> bool MaxHeap<T>::getIsHeap() {
    return this->isHeap;
}

template <class T> void MaxHeap<T>::buildMaxHeap() {
    setHeapSize((int) getHeap().size());
    
    for (int i = (getHeapSize() / 2) - 1; i >= 0; i--) maxHeapify(i);
    setIsHeap(true);
}

template <class T> void MaxHeap<T>::maxHeapify(int index) {
    int largest = index;
    int l = left(largest), r = right(largest);
    
    if (l < getHeapSize() && getHeap().at(l) > getHeap().at(largest)) largest = l;
    if (r < getHeapSize() && getHeap().at(r) > getHeap().at(largest)) largest = r;
    
    if (largest != index) {
        swap(this->heap.at(index), this->heap.at(largest));
        maxHeapify(largest);
    }
    setIsHeap(true);
}

template <class T> void MaxHeap<T>::swap(T &firstNode, T &secondNode) {
    T temp = firstNode;
    firstNode = secondNode;
    secondNode = temp;
}

template <class T> void MaxHeap<T>::insert(T newNode) {
    setHeapSize(getHeapSize() + 1);
    this->heap.push_back(newNode);
    
    int i = getHeapSize() - 1;
    while (i > 0 && getHeap().at(parent(i)) < getHeap().at(i)) {
        swap(this->heap.at(i), this->heap.at(parent(i)));
        i = parent(i);
    }
}

template <class T> void MaxHeap<T>::heapSort() {
    buildMaxHeap();
    for (int i = getHeapSize() - 1; i > 0; i--) {
        swap(this->heap.at(0), this->heap.at(i));
        setHeapSize(getHeapSize() - 1);
        maxHeapify(0);
    }
}


#endif /* MaxHeap_hpp */
