//
//  main.cpp
//  esercizio_15_2_Laboratorio
//
//  Created by Denny Caruso on 16/11/2020.
//

/*
 
    Si supponga di avere una scacchiera NxN, contenente in ogni casella un numero intero, su cui si può muovere una pedina.
    Ogni volta che la pedina passa su una casella accumula il valore contenuto nella casella.
     
    • La pedina parte dall'ultima casella in basso a destra e deve raggiungere la prima casella in alto
    a sinistra potendosi muovere solo di una casella alla volta verso l'alto, verso sinistra o in diagonale (alto-sinistra)
 
    • Si vuole calcolare un percorso che massimizzi il valore accumulato dalla pedina
 
 */

#include <iostream>
#include <vector>
#include <string>

std::vector<std::vector<int>> getMaxPath(std::vector<std::vector<int>> matrix, int rows, int cols, int * maxSum, std::vector<std::string> * maxPath);
template <class T> void printMatrix(std::vector<std::vector<T>>);
void pushString(int first, int second, std::vector<std::string> * stringVec);

int main(int argc, const char * argv[]) {
    std::vector<std::vector<int>> inputMatrix = {
        { 6, 7, 4, 7, 8 },
        { 7, 6, 1, 1, 4 },
        { 3, 5, 7, 8, 2 },
        { 2, 6, 7, 0, 2 },
        { 7, 3, 5, 6, 1 }
    };
    
    int inputMatrixRows = (int) inputMatrix.size();
    int inputMatrixCols = (int) inputMatrix.at(0).size();
    std::vector<std::string> inputMatrixMaxPath;
    int inputMatrixMaxSum = 0;
    
    std::vector<std::vector<int>> sumMatrix = getMaxPath(inputMatrix, inputMatrixRows, inputMatrixCols, &inputMatrixMaxSum, &inputMatrixMaxPath);
    
    std::cout << "\nINPUT MATRIX: \n";
    printMatrix(inputMatrix);
    
    std::cout << "\nPARTIAL SUM MATRIX: \n";
    printMatrix(sumMatrix);
    
    std::cout << "\nTOTAL SUM: " << inputMatrixMaxSum << "\n";
    std::cout << "\nPATH:\n";
    for (auto i = 0; i < inputMatrixMaxPath.size(); i++) std::cout << inputMatrixMaxPath.at(i) << "\n";
    
    return 0;
}

std::vector<std::vector<int>> getMaxPath(std::vector<std::vector<int>> matrix, int rows, int cols, int * maxSum, std::vector<std::string> * maxPath) {
    std::vector<std::vector<int>> partialSumMatrix(rows, std::vector<int>(cols, 0));
    partialSumMatrix.at(0).at(0) = matrix.at(0).at(0);
    
    for (auto i = 0; i < rows; i++) {
        for (auto j = 0; j < cols; j++) {
            if (i == 0 && j == 0) continue;
            if (i == 0) {
                partialSumMatrix.at(i).at(j) = matrix.at(i).at(j) + partialSumMatrix.at(i).at(j - 1);
                continue;
            }
            
            if (j == 0) {
                partialSumMatrix.at(i).at(j) = matrix.at(i).at(j) + partialSumMatrix.at(i - 1).at(j);
                continue;
            }

            int max = std::max(partialSumMatrix.at(i - 1).at(j - 1), partialSumMatrix.at(i - 1).at(j));
            max = std::max(max, partialSumMatrix.at(i).at(j - 1));
            partialSumMatrix.at(i).at(j) = max;
            
            partialSumMatrix.at(i).at(j) += matrix.at(i).at(j);
        }
    }
    
    pushString(rows - 1, cols - 1, maxPath);
    
    for (auto i = rows - 1; i >= 0; i--) {
        for (auto j = cols - 1; j >= 0; j--) {
            if (i == 0 && j == 0) continue;
            if (i == 0) {
                pushString(i, j - 1, maxPath);
                continue;
            }
            
            if (j == 0) {
                pushString(i - 1, j, maxPath);
                i--;
                continue;
            }
            
            int l = partialSumMatrix.at(i - 1).at(j - 1);
            int m = partialSumMatrix.at(i - 1).at(j);
            int k = partialSumMatrix.at(i).at(j - 1);
            
            if (l >= m && l >= k) {
                pushString(i - 1, j - 1, maxPath);
                i--;
            } else if (m >= k && m >= l) {
                pushString(i - 1, j, maxPath);
                i--;
                j++;
            } else {
                pushString(i, j - 1, maxPath);
            }
        }
    }
    
    *maxSum = partialSumMatrix.at(rows - 1).at(cols - 1);
    return partialSumMatrix;
}

template <class T> void printMatrix(std::vector<std::vector<T>> matrix) {
    int rows = (int) matrix.size();
    int cols = (int) matrix.at(0).size();
    
    for (auto i = 0; i < rows; i++) {
        for (auto j = 0; j < cols; j++) std::cout << matrix.at(i).at(j) << "\t\t";
        std::cout << "\n";
    }
}

void pushString(int first, int second, std::vector<std::string> * stringVec) {
    std::string temp = "a[";
    temp.append(std::to_string(first));
    temp.append(",");
    temp.append(std::to_string(second));
    temp.append("]");
    stringVec->push_back(temp);
    temp = "";
}
