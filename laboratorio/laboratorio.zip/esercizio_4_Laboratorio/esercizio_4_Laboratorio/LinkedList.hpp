//
//  LinkedList.hpp
//  esercizio_4_Laboratorio
//
//  Created by Denny Caruso on 09/10/2020.
//

#ifndef LinkedList_hpp
#define LinkedList_hpp

#include "Node.hpp"

template <class T> class LinkedList {
private:
    Node<T> *head;
    Node<T> *tail;
    int nElements;
    
    void setHead(Node <T> *newHead);
    void setTail(Node <T> *newTail);
    void set_nElements(int nElements);
    
public:
    LinkedList() {
        this->head = this->tail = nullptr;
        this->nElements = 0;
    }
    
    ~LinkedList() { }
    
    Node<T> *getHead();
    Node<T> *getTail();
    bool getIsEmpty();
    int get_nElements();
    
    void pushToHead(T * tObject);
    bool popFromHead(T &poppedElement);
    
    /*
    void pushToBack(T * tObject);
    T * popFromBack();
     */
};

template <class T> void LinkedList<T>::setHead(Node<T> *newHead) {
    this->head = newHead;
}

template <class T> void LinkedList<T>::setTail(Node<T> *newTail) {
    this->tail = newTail;
}

template <class T> void LinkedList<T>::set_nElements(int nElements) {
    this->nElements = nElements;
}

template <class T> Node<T> * LinkedList<T>::getHead() {
    return this->head;
}

template <class T> Node<T> * LinkedList<T>::getTail() {
    return this->tail;
}

template <class T> int LinkedList<T>::get_nElements() {
    return this->nElements;
}

template <class T> bool LinkedList<T>::getIsEmpty() {
    return (get_nElements() == 0);
}

template <class T> void LinkedList<T>::pushToHead(T * tObject) {
    Node<T> *newNode = new Node<T>();
    newNode->set_tObject(tObject);
    newNode->setNext(getHead());
    setHead(newNode);
    set_nElements(get_nElements() + 1);
    
    if (getTail() == nullptr) setTail(getHead());
}

template <class T> bool LinkedList<T>::popFromHead(T &poppedElement) {
    if (getHead() != nullptr) {
        poppedElement = *(getHead()->get_tObject());
        delete getHead();
        setHead(getHead()->getNext());
        
        set_nElements(get_nElements() - 1);
        return true;
    } else {
        return false;
    }
}

#endif /* LinkedList_hpp */
