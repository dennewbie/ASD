//
//  Transaction.hpp
//  esercizio_4_Laboratorio
//
//  Created by Denny Caruso on 09/10/2020.
//

#ifndef Transaction_hpp
#define Transaction_hpp

#include <string>
#include <sstream>

class Transaction {
private:
    std::string from;
    std::string to;
    int quantity;
    static int currID;
    const int ID;
    
public:
    Transaction() : ID(this->currID++) { }
    Transaction(std::string from, std::string to, int quantity) : from(from), to(to), quantity(quantity), ID(this->currID++) { }
    
    Transaction(const Transaction &other) : ID(other.ID) { }

    ~Transaction() {
        this->currID--;
    }
    
    Transaction& operator=(const Transaction& other) {
        Transaction *returnTransaction = (new Transaction(other));
        this->from = other.from;
        this->to = other.to;
        this->quantity = other.quantity;
        
        return *returnTransaction;
    }

    std::string getFrom();
    std::string getTo();
    int getQuantity();
    int getTransactionID();
    std::string getTransactionDataString();
};

#endif /* Transaction_hpp */
