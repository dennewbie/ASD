//
//  Transaction.cpp
//  esercizio_4_Laboratorio
//
//  Created by Denny Caruso on 09/10/2020.
//

#include "Transaction.hpp"

int Transaction::currID = 1;

std::string Transaction::getFrom() {
    return this->from;
}

std::string Transaction::getTo(){
    return this->to;
}

int Transaction::getQuantity(){
    return this->quantity;
}

int Transaction::getTransactionID(){
    return this->ID;
}

std::string Transaction::getTransactionDataString() {
    std::stringstream returnStringStream("", std::ios_base::app | std::ios_base::out);
    returnStringStream << "\n------------------------------\n";
    
    returnStringStream << "ID: \t" << this->getTransactionID() <<"\nFROM: \t" << this->getFrom() << "\nTO: \t" << this->getTo() << "\nQTY: \t" << this->getQuantity() << "\n\n";
    
    returnStringStream << "------------------------------\n";
    return returnStringStream.str();
}
