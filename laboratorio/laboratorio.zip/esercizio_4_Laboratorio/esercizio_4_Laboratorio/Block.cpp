//
//  Block.cpp
//  esercizio_4_Laboratorio
//
//  Created by Denny Caruso on 09/10/2020.
//

#include "Block.hpp"

int Block::currID = 1;

int Block::getBlockID() {
    return this->ID;
}

bool Block::getClose() {
    return this->close;
}
void Block::setClose(bool toggleSwitch) {
    this->close = toggleSwitch;
}

std::string Block::getBlockTransactionListString() {
    Node<Transaction> *current = this->transactionList.getHead();
    std::stringstream returnStringStream("", std::ios_base::app | std::ios_base::out);
    returnStringStream << "\n------------------------------\n";
    
    while (current != nullptr) {
        returnStringStream << "ID: \t" << current->get_tObject()->getTransactionID() <<"\nFROM: \t" << current->get_tObject()->getFrom() << "\nTO: \t" << current->get_tObject()->getTo() << "\nQTY: \t" << current->get_tObject()->getQuantity() << "\n\n";
        current = current->getNext();
    }
    
    returnStringStream << "------------------------------\n";
    
    return returnStringStream.str();
}

std::string Block::getUserBlockTransactionListString(std::string username) {
    Node<Transaction> *current = this->transactionList.getHead();
    std::stringstream returnStringStream("", std::ios_base::app | std::ios_base::out);
    returnStringStream << "\n" << username << " Transaction # " << this->getBlockID() << " Block:\n------------------------------\n";
    
    while (current != nullptr) {
        if (current->get_tObject()->getFrom() == username || current->get_tObject()->getTo() == username) {
            returnStringStream << "ID: \t" << current->get_tObject()->getTransactionID() <<"\nFROM: \t" << current->get_tObject()->getFrom() << "\nTO: \t" << current->get_tObject()->getTo() << "\nQTY: \t" << current->get_tObject()->getQuantity() << "\n\n";
        }
        current = current->getNext();
    }
    
    returnStringStream << "------------------------------\n";
    
    return returnStringStream.str();
}

void Block::pushTransaction(Transaction *newTransaction) {
    if (!getClose()) transactionList.pushToHead(newTransaction);
}

bool Block::popTransaction(Transaction &poppedTransaction) {
    return (transactionList.popFromHead(poppedTransaction)) ? true : false;
}

int Block::getBlockBalanceOfUser(std::string username, std::string &userTransactionList) {
    int sum = 0;
    userTransactionList = getUserBlockTransactionListString(username);
    Node<Transaction> *current = this->transactionList.getHead();
    
    while (current != nullptr) {
        if (username == current->get_tObject()->getFrom()) {
            sum -= current->get_tObject()->getQuantity();
        } else if (username == current->get_tObject()->getTo()) {
            sum += current->get_tObject()->getQuantity();
        }
        
        current = current->getNext();
    }
    
    return sum;
}
