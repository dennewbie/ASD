//
//  main.cpp
//  esercizio_4_Laboratorio
//
//  Created by Denny Caruso on 09/10/2020.
//

#include "LinkedList.hpp"
#include "Node.hpp"
#include "Transaction.hpp"
#include "Block.hpp"
#include <iostream>

void printBlocks(LinkedList<Block> blockList);
int getBlockchainBalanceOfUser(std::string username, LinkedList<Block> blockList);

int main(int argc, const char * argv[]) {
//    Creazione Transazione
    Transaction * pTransaction1 =  new Transaction("Pino",      "Giorgio",   100);
    Transaction * pTransaction2 =  new Transaction("Pino",      "Matteo",    200);
    Transaction * pTransaction3 =  new Transaction("Luca",      "Pino",      300);
    Transaction * pTransaction4 =  new Transaction("Giorgio",   "Pino",      400);
    Transaction * pTransaction5 =  new Transaction("Giorgio",   "Matteo",    500);
    Transaction * pTransaction6 =  new Transaction("Luca",      "Giorgio",   600);
    Transaction * pTransaction7 =  new Transaction("Luca",      "Pino",      700);
    Transaction * pTransaction8 =  new Transaction("Matteo",    "Luca",      800);
    Transaction * pTransaction9 =  new Transaction("Matteo",    "Giorgio",   900);
    Transaction * pTransaction10 = new Transaction("Giorgio",   "Pino",      1000);
    
//    Creazione Lista di Blocchi e Blocchi
    LinkedList<Block> blockList = LinkedList<Block>();
    Block * pBlock1 = new Block();
    Block * pBlock2 = new Block();
    Block * pBlock3 = new Block();
    Block * pBlock4 = new Block();
    
//    Aggiunta dei Blocchi alla Lista di Blocchi
    blockList.pushToHead(pBlock1);
    blockList.pushToHead(pBlock2);
    blockList.pushToHead(pBlock3);
    blockList.pushToHead(pBlock4);
    
//    Aggiunta delle Transazioni ai Blocchi e Chiusura Blocchi
    pBlock1->pushTransaction(pTransaction1);
    pBlock1->pushTransaction(pTransaction2);
    pBlock1->setClose(true);
    
    pBlock2->pushTransaction(pTransaction3);
    pBlock2->pushTransaction(pTransaction4);
    pBlock2->pushTransaction(pTransaction5);
    pBlock2->setClose(true);
    
    pBlock3->pushTransaction(pTransaction6);
    pBlock3->setClose(true);
    
    pBlock4->pushTransaction(pTransaction7);
    pBlock4->pushTransaction(pTransaction8);
    pBlock4->pushTransaction(pTransaction9);
    pBlock4->pushTransaction(pTransaction10);
    pBlock4->setClose(true);
    
//    Ricerca Indirizzo e Stampa del Bilancio
    std::string inputAddress = "Luca";
    int userBalance = getBlockchainBalanceOfUser(inputAddress, blockList);
    std::cout << "\n" << inputAddress << " Balance: $" << userBalance << "\n\n";
  
    /*
//    Stampa Lista Transazioni
    printBlocks(blockList);
   
//  Rimozione Nodi Singoli Blocchi
    Transaction tempTransaction;
    if (pBlock1->popTransaction(tempTransaction)) std::cout << "Rimozione dal Blocco " << "# " << pBlock1->getBlockID() << "... \n";
    if (pBlock1->popTransaction(tempTransaction)) std::cout << "Rimozione dal Blocco " << "# " << pBlock1->getBlockID() << "... \n";
    
    if (pBlock2->popTransaction(tempTransaction)) std::cout << "Rimozione dal Blocco " << "# " << pBlock2->getBlockID() << "... \n";
    if (pBlock2->popTransaction(tempTransaction)) std::cout << "Rimozione dal Blocco " << "# " << pBlock2->getBlockID() << "... \n";
    if (pBlock2->popTransaction(tempTransaction)) std::cout << "Rimozione dal Blocco " << "# " << pBlock2->getBlockID() << "... \n";
    
    if (pBlock3->popTransaction(tempTransaction)) std::cout << "Rimozione dal Blocco " << "# " << pBlock3->getBlockID() << "... \n";
    
    if (pBlock4->popTransaction(tempTransaction)) std::cout << "Rimozione dal Blocco " << "# " << pBlock4->getBlockID() << "... \n";
    if (pBlock4->popTransaction(tempTransaction)) std::cout << "Rimozione dal Blocco " << "# " << pBlock4->getBlockID() << "... \n";
    if (pBlock4->popTransaction(tempTransaction)) std::cout << "Rimozione dal Blocco " << "# " << pBlock4->getBlockID() << "... \n";
    if (pBlock4->popTransaction(tempTransaction)) std::cout << "Rimozione dal Blocco " << "# " << pBlock4->getBlockID() << "... \n";
    
//    Stampa Lista Transazioni
    printBlocks(blockList);
     */
    return 0;
}

void printBlocks(LinkedList<Block> blockList) {
    std::cout << "\n\n";
    
    Node<Block> *tempBlock = blockList.getHead();
    while (tempBlock != nullptr) {
        std::cout << "#" << tempBlock->get_tObject()->getBlockID() << " Block Transactions: \n" << tempBlock->get_tObject()->getBlockTransactionListString();
        tempBlock = tempBlock->getNext();
    }
}

int getBlockchainBalanceOfUser(std::string username, LinkedList<Block> blockList) {
    int sum = 0;
    std::cout << "Searching for: " << username << " Transactions...\n\n";
    std::string userTransactionList;
    Node<Block> *tempBlock = blockList.getHead();
    while (tempBlock != nullptr) {
        sum += tempBlock->get_tObject()->getBlockBalanceOfUser(username, userTransactionList);
        std::cout << userTransactionList << "\n";
        tempBlock = tempBlock->getNext();
    }
    
    return sum;
}
