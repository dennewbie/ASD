//
//  Block.hpp
//  esercizio_4_Laboratorio
//
//  Created by Denny Caruso on 09/10/2020.
//

#ifndef Block_hpp
#define Block_hpp

#include "LinkedList.hpp"
#include "Node.hpp"
#include "Transaction.hpp"
#include <sstream>

class Block {
private:
    static int currID;
    const int ID;
    bool close;
    LinkedList<Transaction> transactionList;
    
public:
    Block() : ID(currID++), close(false), transactionList(LinkedList<Transaction>()) { }
    
    Block(int ID, bool close, LinkedList<Transaction> transactionList) : ID(currID++), close(false), transactionList() {
        this->close = close;
        this->transactionList = transactionList;
    }
    
    ~Block() { this->currID--; }
    
    int getBlockID();
    bool getClose();
    void setClose(bool toggleSwitch);
    
    std::string getBlockTransactionListString();
    std::string getUserBlockTransactionListString(std::string username);
    
    void pushTransaction(Transaction *newTransaction);
    bool popTransaction(Transaction &poppedTransaction);
    
    int getBlockBalanceOfUser(std::string username, std::string & userTransactionList);
};

#endif /* Block_hpp */
