//
//  Node.hpp
//  esercizio_4_Laboratorio
//
//  Created by Denny Caruso on 09/10/2020.
//

#ifndef Node_hpp
#define Node_hpp

template <class T>
class Node {
private:
    T * tObject;
    Node * next;
    
public:
    Node() {
        this->tObject = nullptr;
        this->next = nullptr;
    }
    
    ~Node() { }
    
    void set_tObject(T * tObject);
    T * get_tObject();
    
    void setNext(Node *next);
    Node<T> * getNext();
    
};

template <class T> void Node<T>::set_tObject(T * tObject) {
    this->tObject = tObject;
}

template <class T> T * Node<T>::get_tObject() {
    return this->tObject;
}

template <class T> void Node<T>::setNext(Node *next) {
    this->next = next;
}

template <class T> Node<T> * Node<T>::getNext() {
    return this->next;
}

#endif /* Node_hpp */
