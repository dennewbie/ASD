//
//  main.cpp
//  esercizio_9_1_Laboratorio
//
//  Created by Denny Caruso on 26/10/2020.
//

/*
 
 Progettare ed implementare una classe templata Max-Heap dotata delle seguenti operazioni:
    • Max-Heapify
    • Build-Max-Heap
    • Insert
    • PrintArray
    • (PrintAsciiTree)
    • HeapSort
 */

#include <iostream>
#include "MaxHeap.hpp"

int main(int argc, const char * argv[]) {
    std::vector<int> testArray { 10, 1, 50, 80, 90, 100, 12, 23, 30, 11 };
    MaxHeap<int> integerHeap = MaxHeap<int>(testArray);
    
    integerHeap.printHeap();
    integerHeap.buildMaxHeap();
    integerHeap.printHeap();

    integerHeap.insert(101);
    integerHeap.printHeap();

    integerHeap.printHeapTree();
    integerHeap.heapSort();
    integerHeap.printArray();
    integerHeap.printHeap();
    return 0;
}



