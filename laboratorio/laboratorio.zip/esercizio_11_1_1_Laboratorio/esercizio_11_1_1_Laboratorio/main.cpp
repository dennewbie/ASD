//
//  main.cpp
//  esercizio_11_1_1_Laboratorio
//
//  Created by Denny Caruso on 02/11/2020.
//

// Counting Sort Ferone Version

#include <iostream>
using namespace std;

void countingSort (int *A, int lengthA){
    int max = A[0], min = A[0];
    //Calcolo elementi max e min
    for(int i = 1; i < lengthA; i++){
        if(A[i] > max) {
            max = A[i];
        } else if(A[i] < min) {
            min = A[i];
        }
    }
    
    int lengthC = max - min + 1;
    //Costruzione dell'array
    int *C = new int[lengthC];
    //crea l'array C
    for(int i = 0; i < lengthC; i++) C[i] = 0;
    //inizializza a zero gli elementi di C
    // aumenta il numero di volte che si è incontrato il valore
    for(int i = 0; i < lengthA; i++) {
        C[A[i] - min]++;
    }
    
    // Ordinamento in base al contenuto dell'array delle frequenze
    int k = 0;
    // indice per l'array A
    for (int i = 0; i < lengthC; i++) {
        //scrive C[i] volte il valore  i + min nell'array A
        while (C[i] > 0){
            A[k++] = i + min;
            C[i]--;
        }
    }
    delete[ ] C;
}


int main() {
    int arr[] = { 1, 2, -3, -1, 2, 2, 2, 3, -1, -3 };
    int size = sizeof(arr) / sizeof(arr[0]);
    countingSort(arr, size);
    
    // Stampa in output il vettore ordinato
    for (int idx = 0; idx < size; idx++) {
        cout << "Elemento[" << idx << "] = " << arr[idx] << endl;
    }
    return 0;
}
