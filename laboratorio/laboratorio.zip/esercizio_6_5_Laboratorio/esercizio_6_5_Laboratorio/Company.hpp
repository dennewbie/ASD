//
//  Company.hpp
//  esercizio_6_5_Laboratorio
//
//  Created by Denny Caruso on 16/10/2020.
//

#ifndef Company_hpp
#define Company_hpp

#include <iostream>
#include <vector>

class Company {
private:
    std::vector<int> quotes;
    
public:
    Company(std::vector<int> quotes) : quotes(quotes) { }
    
    std::vector<int> getQuotes();
    int findIndex(int low, int high);
    void printQuotes();
};

#endif /* Company_hpp */
