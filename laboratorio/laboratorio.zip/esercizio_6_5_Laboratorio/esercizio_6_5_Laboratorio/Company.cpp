//
//  Company.cpp
//  esercizio_6_5_Laboratorio
//
//  Created by Denny Caruso on 16/10/2020.
//

#include "Company.hpp"

std::vector<int> Company::getQuotes() {
    return this->quotes;
}

void Company::printQuotes() {
    std::cout << "\nQuote:\n";
    for (auto quote: getQuotes()) std::cout << quote << "\t\t";
    std::cout << "\n";
}


//SBAGLIATO secondo il Prof.
//int Company::findIndex(int low, int high) {
//    if (low == high) return low;
//    auto mid = (low + high) / 2;
//
//    auto leftIndex = findIndex(low, mid);
//    auto rightIndex = findIndex(mid + 1, high);
//
//    auto isLeftLessThanRight = (getQuotes().at(leftIndex) < getQuotes().at(rightIndex));
//    return isLeftLessThanRight ? leftIndex : rightIndex;
//}

//CORRETTO secondo il Prof.
int Company::findIndex(int low, int high) {
    if (low + 1 == high) return low;
    int mid = (low + high) / 2;
    
    if (getQuotes().at(low) < getQuotes().at(mid)) {
        return findIndex(low, mid);
    } else {
        return findIndex(mid, high);
    }
}
