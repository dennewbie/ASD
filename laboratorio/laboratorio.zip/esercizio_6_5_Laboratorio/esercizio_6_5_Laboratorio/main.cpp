//
//  main.cpp
//  esercizio_6_5_Laboratorio
//
//  Created by Denny Caruso on 16/10/2020.
//

/*
    Esercizio 6_5:
    Un'azienda è quotata in borsa.
    Si supponga di avere un array A[1...N] contenente la quotazione delle azioni in un periodo di N giorni e che A[1]<A[N].
    È possibile dimostrare che esiste almeno una coppia di giorni consecutivi i, i+1 tali che A[i]<A[i+1].
    Progettare ed implementare un algoritmo divide-et-impera che trovi un indice i che verifichi la condizione data.
 */

#include "Company.hpp"

int main(int argc, const char * argv[]) {
    std::vector<int> quotes = { 26, 25, 21, 18, 32 };
    
    Company fakeCompany = Company(quotes);
    int index = fakeCompany.findIndex(0 ,(int) quotes.size() - 1);
    
    std::cout << "L'indice i che rispetta la condizione A[i] < A[i + 1] è: " << index
    << "\n\nA[" << index << "]: " << fakeCompany.getQuotes().at(index)
    << " < A[" << index + 1 << "]: " << fakeCompany.getQuotes().at(index + 1) << "\n\n";
    
    fakeCompany.printQuotes();
    return 0;
}
