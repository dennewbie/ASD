//
//  HashTable.hpp
//  esercizio_22_1_2_Laboratorio
//
//  Created by Denny Caruso on 12/12/2020.
//

#ifndef HashTable_hpp
#define HashTable_hpp

#include <iostream>
#include <list>
#include <vector>
#define knutSuggestion 0.6180339887

#include "Node.hpp"

template<typename K, typename V> class HashTable {
    Node<K, V> ** table;
    int capacity;
    int size;
    Node<K, V> * temp;
    
    void setCapacity(unsigned int newCapacity);
    void setSize(unsigned int newSize);
    void setTable(Node<K, V> ** newTable);
    std::vector<Node<K, V>> getTable();
    
    unsigned int hashFunctionDivsion(int key);
    unsigned int hashFunctionMultiplication(int key);
    
public:
    HashTable(unsigned int N) {
        setCapacity(N);
        setSize(0);
        setTable(new Node<K, V> * [getCapacity()]);
        
        for(auto i = 0 ; i < getCapacity() ; i++) table[i] = nullptr;
        
        temp =  new Node<K,V>(-1, -1);
        temp->isDeleted = false;
    }
    
    unsigned int getCapacity();
    unsigned int getSize();
    void insertNode(K key, V value);
    K * searchNode(K key);
    K * deleteNode(K key);
    
    V getValueAtKey(K key);
    
    void displayHash();
    
};

template <typename K, typename V> void HashTable<K, V>::setCapacity(unsigned int newCapacity) {
    this->capacity = newCapacity;
}

template <typename K, typename V> void HashTable<K, V>::setSize(unsigned int newSize) {
    this->size = newSize;
}

template <typename K, typename V> void HashTable<K, V>::setTable(Node<K, V> ** newTable) {
    this->table = newTable;
}

template <typename K, typename V> std::vector<Node<K, V>> HashTable<K, V>::getTable() {
    return this->table;
}

template <typename K, typename V> unsigned int HashTable<K, V>::getCapacity() {
    return this->capacity;
}

template <typename K, typename V> unsigned int HashTable<K, V>::getSize() {
    return this->size;
}

template <typename K, typename V> void HashTable<K, V>::displayHash() {
    std::cout << "\n";
    for(auto i = 0 ; i < getCapacity() ; i++) {
        if(table[i] != nullptr && table[i]->isDeleted != true) {
            std::cout << "INDEX: " << i << "\n";
            std::cout << table[i]->getKey() << " : " << table[i]->getValue() << " : " << table[i]->isDeleted << " \n";
        }
    }
    std::cout << "\n";
}

template <typename K, typename V> unsigned int HashTable<K, V>::hashFunctionDivsion(int key) {
    return (key % getCapacity());
}

template <typename K, typename V> unsigned int HashTable<K, V>::hashFunctionMultiplication(int key) {
    unsigned int unsignedKey = (unsigned int) key;
    double value = unsignedKey * knutSuggestion;
    return (floor(getCapacity() * fmod(value, 1.0)));
}

template <typename K, typename V> void HashTable<K, V>::insertNode(K key, V value) {
    Node<K, V> * temp = new Node<K,V>(key, value);
    if (getSize() == getCapacity()) return;
    
    int hashIndex = hashFunctionDivsion(key);
    
    while(table[hashIndex] != nullptr && table[hashIndex]->getKey() != key && table[hashIndex]->isDeleted != true) {
        hashIndex++;
        hashIndex %= capacity;
    }
    
    if(table[hashIndex] == nullptr || table[hashIndex]->isDeleted != false) {
        size++;
        table[hashIndex] = temp;
        table[hashIndex]->isDeleted = false;
    }
}

template <typename K, typename V> K * HashTable<K, V>::searchNode(K key) {
    int hashIndex = hashFunctionDivsion(key);
    
    while(table[hashIndex] != nullptr) {
        int counter = 0;
        if (counter++ > capacity) return nullptr;
        
        
        if(table[hashIndex]->getKey() == key) {
            K * ptrKey = new K;
            *ptrKey = table[hashIndex]->getKey();
            return ptrKey;
        }
        
        hashIndex++;
        hashIndex %= getCapacity();
    }
    
    return nullptr;
}

template <typename K, typename V> V HashTable<K, V>::getValueAtKey(K key) {
    int hashIndex = hashFunctionDivsion(key);
    return table[hashIndex]->getValue();
}

template <typename K, typename V> K * HashTable<K, V>::deleteNode(K key) {
    int hashIndex = hashFunctionDivsion(key);

    while(table[hashIndex] != nullptr) {
        if(table[hashIndex]->getKey() == key) {
//            Node<K, V> * localTemp = table[hashIndex];
            
            table[hashIndex] = temp;
            table[hashIndex]->isDeleted = true;
            
            size--;
            K * ptrKey = new K;
            *ptrKey = table[hashIndex]->getKey();
            return ptrKey;
        }
        hashIndex++;
        hashIndex %= getCapacity();
        
    }
    
    return nullptr;
}

#endif /* HashTable_hpp */
