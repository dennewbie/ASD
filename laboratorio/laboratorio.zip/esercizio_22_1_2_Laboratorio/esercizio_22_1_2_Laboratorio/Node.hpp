//
//  Node.hpp
//  esercizio_22_1_2_Laboratorio
//
//  Created by Denny Caruso on 12/12/2020.
//

#ifndef Node_hpp
#define Node_hpp

template <typename K, typename V> class Node {
private:
    K key;
    V value;
    
public:
    Node() { }
    
    Node(K key, V value) {
        setKey(key);
        setValue(value);
        isDeleted = false;
    }
    
    void setKey(K newKey);
    void setValue(V newValue);
    K getKey();
    V getValue();
    bool isDeleted;
    
    
};

template <typename K, typename V> void Node<K, V>::setKey(K newKey) {
    this->key = newKey;
}

template <typename K, typename V> void Node<K, V>::setValue(V newValue) {
    this->value = newValue;
}

template <typename K, typename V> K Node<K, V>::getKey() {
    return this->key;
}

template <typename K, typename V> V Node<K, V>::getValue() {
    return this->value;
}

#endif /* Node_hpp */
