//
//  main.cpp
//  esercizio_22_1_2_Laboratorio
//
//  Created by Denny Caruso on 12/12/2020.
//

/*
    Implementare una hash map con indirizzamento aperto
 */

#include "HashTable.hpp"

int main(int argc, const char * argv[]) {
//    int arrKey[] = { 15, 11, 27, 8, 12, 20, 37, 34, 33, 1, 2, -10, -20, 100 };
//    int arrValue[] = { 100, -20, -10, 2, 1, 33, 34, 37, 20, 12, 8, 27, 11, 15 };
    int arrKey[] = {    15,     11,     27,     8,  12,     20 };
    int arrValue[] = { 100,     -20,    -10,    2,  1,      33 };
    int arrKeySize = sizeof(arrKey) / sizeof(arrKey[0]);
    
    HashTable<int, int> simpleHashTable(15);
    for (auto i = 0; i < arrKeySize; i++) simpleHashTable.insertNode(arrKey[i], arrValue[i]);
    
    simpleHashTable.displayHash();
    
    int exampleKey_one = 15;
    int * searchedNode = simpleHashTable.searchNode(exampleKey_one);
    if (searchedNode == nullptr) {
        std::cout << "\nNode with key: " << exampleKey_one << " not found...\n";
    } else {
        std::cout << "\nNode with key: " << exampleKey_one << " found. Value: " << simpleHashTable.getValueAtKey(exampleKey_one) << "\n";
    }
    
    int exampleKey_two = 12;
    int * deletedNode = simpleHashTable.deleteNode(exampleKey_two);
    if (deletedNode == nullptr || * deletedNode == -1) {
        std::cout << "\nNode with key: " << exampleKey_two << " not found...\n";
    } else {
        std::cout << "\nNode with key: " << exampleKey_two << " found. Value: " << simpleHashTable.getValueAtKey(exampleKey_two) << "\n";
    }
    
    simpleHashTable.displayHash();
    
    simpleHashTable.insertNode(-50, 3);
    simpleHashTable.insertNode(-1, 300);
    simpleHashTable.displayHash();

    return 0;
}
