//
//  main.cpp
//  esercizio_5_1_Laboratorio
//
//  Created by Denny Caruso on 12/10/2020.
//

#include <iostream>
#include <vector>
#include <fstream>
#include <string>
#include <mutex>
#include <thread>

#define nRows 4

std::mutex mux;
std::fstream configurationInputFileStream;
std::string correctMessage = "\nLa matrice presente nel file è soluzione per il gioco del 15...\n";
std::string incorrectMessage = "\nLa matrice presente nel file non è soluzione per il gioco del 15...\n";

void printMatrix(std::vector<std::vector<int>>);
void fillMatrix(std::vector<std::vector<int>> &matrix);
bool checkConfigurationMatrix(std::vector<std::vector<int>> matrix);
void printMessage(std::string);

void firstFunctionCheck(std::vector<std::vector<int>> &matrix);
void secondFunctionCheck(std::vector<std::vector<int>> &matrix);

int main(int argc, const char * argv[]) {
    std::vector<std::vector<int>> matrix(nRows, std::vector<int>(nRows));
    
    //    I thread operano con le copie. Così si riesce a passare per reference la matrice.
    auto firstThread = std::thread(firstFunctionCheck, std::ref(matrix));
    auto secondThread = std::thread(secondFunctionCheck, std::ref(matrix));
    firstThread.join();
    secondThread.join();
    return 0;
}

void fillMatrix(std::vector<std::vector<int>> &matrix) {
    std::string row, delimiter = " ", token;
    int i = 0, j = 0;
    while (getline(configurationInputFileStream, row)) {
        j= 0;
        while(token != row) {
            token = row.substr(0, row.find_first_of(delimiter));
            row = row.substr(row.find_first_of(delimiter) + 1);
            try {
                matrix[i][j++] = std::stoi(token);
            } catch (...) {
                break;
            }
        }
        i++;
    }
}

void printMatrix(std::vector<std::vector<int>> matrix) {
    for(auto row: matrix) {
        for(auto col: row) std::cout << col<< "\t";
        std::cout << std::endl;
    }
}

bool checkConfigurationMatrix(std::vector<std::vector<int>> matrix) {
    std::vector<std::vector<int> >::iterator row;
    std::vector<int>::iterator col;
    int j = 1;
    for (row = matrix.begin(); row != matrix.end(); row++) {
        for (col = row->begin(); col != row->end(); col++) {
            if (j == matrix.size() * matrix.size()) {
                if (* col == j) return false;
                return true;
            }
            if (*col != j) return false;
            j++;
        }
    }
    return true;
}

void firstFunctionCheck(std::vector<std::vector<int>> &matrix) {
    mux.lock();
    std::string correctConfiguration = "configurazioneCorretta.txt";
    configurationInputFileStream.open(correctConfiguration.c_str());
    
    if (configurationInputFileStream.fail()) {
        std::cout << "Error while opening Input stream ......";
    } else {
        fillMatrix(matrix);
        printMatrix(matrix);
        checkConfigurationMatrix(matrix) ? printMessage(correctMessage) : printMessage(incorrectMessage);
    }
    configurationInputFileStream.close();
    mux.unlock();
}

void secondFunctionCheck(std::vector<std::vector<int>> &matrix) {
    mux.lock();
    std::string incorrectConfiguration = "configurazioneScorretta.txt";
    configurationInputFileStream.open(incorrectConfiguration.c_str());
    
    if (configurationInputFileStream.fail()) {
        std::cout << "Error while opening Input stream ......";
    } else {
        fillMatrix(matrix);
        printMatrix(matrix);
        checkConfigurationMatrix(matrix) ? printMessage(correctMessage) : printMessage(incorrectMessage);
    }
    configurationInputFileStream.close();
    mux.unlock();
}

void printMessage(std::string message) {
    std::cout << "\n" << message << "\n";
}
