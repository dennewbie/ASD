//
//  RBTree.hpp
//  esercizio_14_1_Laboratorio
//
//  Created by Denny Caruso on 14/11/2020.
//

#ifndef RBTree_hpp
#define RBTree_hpp

#include "BinarySearchTree.hpp"

template <class T> class RBTree: public BinarySearchTree<T> {
private:
    void leftRotate(Node<T> * current);
    void rightRotate(Node<T> * current);
    Node<T> * nilT;
    
    void transplantRB(Node<T> * to, Node<T> * from);
    void deleteFixupRB(Node<T> * x);
    
public:
    RBTree() {
        BinarySearchTree<T>();
        this->nilT = new Node<T>();
        (this->nilT)->setColor(false);
        this->nilT = nullptr;
//        (this->nilT)->setLeft(nullptr);
//        (this->nilT)->setRight(nullptr);
    }
    
    ~RBTree() { }
    void insertNodeRB(int key, T data);
    void deleteNodeRB(int key);
    
    Node<T> * getBlackSuccessor(int key);
};

template <class T> void RBTree<T>::leftRotate(Node<T> * x) {
    Node<T> * y = x->getRight();
    
    if (y == nilT) return;
    x->setRight(y->getLeft());
    
    if (y->getLeft() != nilT) {
        (y->getLeft())->setParent(x);
    }
    
    y->setParent(x->getParent());
    
    if (x->getParent() == nilT) {
        this->setRoot(y);
    } else if (x == (x->getParent()->getLeft())) {
        (x->getParent())->setLeft(y);
    } else {
        (x->getParent())->setRight(y);
    }
    
    y->setLeft(x);
    x->setParent(y);
}

template <class T> void RBTree<T>::rightRotate(Node<T> * x) {
    Node<T> * y = x->getLeft();
    
    if (y == nilT) return;
    x->setLeft(y->getRight());
    
    if (y->getRight() != nilT) {
        (y->getRight())->setParent(x);
    }
    
    y->setParent(x->getParent());
    
    if (x->getParent() == nilT) {
        this->setRoot(y);
    } else if (x == (x->getParent()->getRight())) {
        (x->getParent())->setRight(y);
    } else {
        (x->getParent())->setLeft(y);
    }
    
    y->setRight(x);
    x->setParent(y);
}

template <class T> void RBTree<T>::insertNodeRB(int key, T data) {
    this->insertNode(key, data);
    Node<T> * x = this->searchNode(key, this->getRoot());
//    x->setLeft(nullptr);
//    x->setRight(nullptr);
    x->setLeft(nilT);
    x->setRight(nilT);
//    (x->getLeft())->setColor(false);
//    (x->getRight())->setColor(false);
    x->setColor(true);
    
    while (x != this->getRoot() && (x->getParent()->getColor() == true)) {
        if (x->getParent() == ((x->getParent())->getParent())->getLeft()) {
            Node<T> * y = ((x->getParent())->getParent())->getRight();
            
            if (y != nilT && y->getColor() == true) {
                (x->getParent())->setColor(false);
                y->setColor(false);
                ((x->getParent())->getParent())->setColor(true);
                x = ((x->getParent())->getParent());
            } else {
                if (x == (x->getParent())->getRight()) {
                    x = x->getParent();
                    leftRotate(x);
                }
                
                (x->getParent())->setColor(false);
                ((x->getParent())->getParent())->setColor(true);
                rightRotate(((x->getParent())->getParent()));
            }
        } else {
            Node<T> * y = ((x->getParent())->getParent())->getLeft();
            
            if (y != nilT && y->getColor() == true) {
                (x->getParent())->setColor(false);
                y->setColor(false);
                ((x->getParent())->getParent())->setColor(true);
                x = ((x->getParent())->getParent());
            } else {
                if (x == (x->getParent())->getLeft()) {
                    x = x->getParent();
                    rightRotate(x);
                }
                
                (x->getParent())->setColor(false);
                ((x->getParent())->getParent())->setColor(true);
                leftRotate(((x->getParent())->getParent()));
            }
        }
    }
    
    (this->getRoot())->setColor(false);
}

template <class T> void RBTree<T>::transplantRB(Node<T> * to, Node<T> * from) {
    if (to->getParent() == nilT) {
        this->setRoot(from);
    } else if (to == (to->getParent())->getLeft()) {
        (to->getParent())->setLeft(from);
    } else {
        (to->getParent())->setRight(from);
    }

    //here possible change: HELP
    if (from != nilT) from->setParent(to->getParent());
//    from->setParent(to->getParent());
}

template <class T> void RBTree<T>::deleteNodeRB(int key) {
    Node<T> * z = this->searchNode(key, this->getRoot());
    Node<T> * x;
    Node<T> * y;
    bool yOriginalColor;
    
    //possible change
//    if (z != nilT) {
        y = z;
        yOriginalColor = y->getColor();
        
        if (z->getLeft() == nilT) {
            x = z->getRight();
            transplantRB(z, z->getRight());
        } else if (z->getRight() == nilT) {
            x = z->getLeft();
            transplantRB(z, z->getLeft());
        } else {
            y = this->getMinimum(z->getRight());
            yOriginalColor = y->getColor();
            x = y->getRight();
            
            if (y->getParent() == z) {
                x->setParent(y);
            } else {
                transplantRB(y, y->getRight());
                y->setRight(z->getRight());
                (y->getRight())->setParent(y);
            }
            
            transplantRB(z, y);
            
            y->setLeft(z->getLeft());
            (y->getLeft())->setParent(y);
            y->setColor(z->getColor());
        }
        
        if (yOriginalColor == false) {
            if (x != nilT) {
                deleteFixupRB(x);
            }
        }
    //}
}

template <class T> void RBTree<T>::deleteFixupRB(Node<T> * x) {
    Node <T> * w;
    while (x != this->getRoot() && x->getColor() == false) {
        if (x == (x->getParent())->getLeft()) {
            w = (x->getParent())->getRight();
            
            if (w->getColor() == true) {
                w->setColor(false);
                (x->getParent())->setColor(true);
                this->leftRotate(x->getParent());
                w = (x->getParent())->getRight();
            }
            
            if ((w->getLeft())->getColor() == false && (w->getRight())->getColor() == false) {
                w->setColor(true);
                x = x->getParent();
            } else {
                if ((w->getRight())->getColor() == false) {
                    (w->getLeft())->setColor(false);
                    w->setColor(true);
                    this->rightRotate(w);
                    w = (x->getParent())->getRight();
                }
                
                w->setColor((x->getParent()->getColor()));
                (x->getParent())->setColor(false);
                (w->getRight())->setColor(false);
                this->leftRotate(x->getParent());
                x = this->getRoot();
            }
        } else {
            w = (x->getParent())->getLeft();
            
            if (w->getColor() == true) {
                w->setColor(false);
                (x->getParent())->setColor(true);
                this->rightRotate(x->getParent());
                w = (x->getParent())->getLeft();
            }
            
            if ((w->getRight())->getColor() == false && (w->getLeft())->getColor() == false) {
                w->setColor(true);
                x = x->getParent();
            } else {
                if ((w->getLeft())->getColor() == false) {
                    (w->getRight())->setColor(false);
                    w->setColor(true);
                    this->leftRotate(w);
                    w = (x->getParent())->getLeft();
                }
                
                w->setColor((x->getParent()->getColor()));
                (x->getParent())->setColor(false);
                (w->getLeft())->setColor(false);
                this->rightRotate(x->getParent());
                x = this->getRoot();
            }
        }
    }
}
//O(log n) perchè il prossimo successore è sempre nero
template <class T> Node<T> * RBTree<T>::getBlackSuccessor(int key) {
    Node<T> * z = this->searchNode(key, this->getRoot());
    if (z == nullptr) return nullptr;
    
    Node<T> * succ = this->getSuccessor(z);
    if (succ == nullptr) return nullptr;
    if (succ->getColor() == false) return succ;
    
    Node<T> * recSucc = getBlackSuccessor(succ->getKey());
    return recSucc;
}

#endif /* RBTree_hpp */
