//
//  main.cpp
//  esercizio_14_1_Laboratorio
//
//  Created by Denny Caruso on 14/11/2020.
//

/*
    Dato un RB-Tree scrivere una funzione che restituisca il successore nero di un nodo
 */

#include "RBTree.hpp"
#include "Node.h"

int main(int argc, const char * argv[]) {
    RBTree<float> redBlackTree;
    
    redBlackTree.insertNodeRB(26, 20.0);
    redBlackTree.insertNodeRB(17, 20.0);
    redBlackTree.insertNodeRB(41, 20.0);
    redBlackTree.insertNodeRB(14, 20.0);
    redBlackTree.insertNodeRB(21, 20.0);
    redBlackTree.insertNodeRB(10, 20.0);
    redBlackTree.insertNodeRB(16, 20.0);
    
    redBlackTree.insertNodeRB(19, 20.0);
    redBlackTree.insertNodeRB(23, 20.0);
    redBlackTree.insertNodeRB(7, 20.0);
    redBlackTree.insertNodeRB(15, 20.0);
    redBlackTree.insertNodeRB(20, 20.0);
    redBlackTree.insertNodeRB(3, 20.0);
    redBlackTree.insertNodeRB(30, 20.0);
    
    redBlackTree.insertNodeRB(47, 20.0);
    redBlackTree.insertNodeRB(28, 20.0);
    redBlackTree.insertNodeRB(38, 20.0);
    redBlackTree.insertNodeRB(35, 20.0);
    redBlackTree.insertNodeRB(39, 20.0);
    
    std::cout << "PREORDER: \n\n";
    redBlackTree.preorderVisit(redBlackTree.getRootKey());
    std::cout << "\n\n";
    
    Node<float> min = redBlackTree.getMinimum(redBlackTree.getRootKey());
    std::cout << "MIN: " << min.getKey() << "\n";
    
    Node<float> max = redBlackTree.getMaximum(redBlackTree.getRootKey());
    std::cout << "MAX: " << max.getKey() << "\n";
    
    std::cout << "PREORDER: \n\n";
    redBlackTree.preorderVisit(redBlackTree.getRootKey());
    std::cout << "\n\n";
    
    Node<float> *blackSucc = redBlackTree.getBlackSuccessor(19);
    std::cout << "BLACK SUCC: " << blackSucc->getKey() << "\n\n";
    
    return 0;
}
