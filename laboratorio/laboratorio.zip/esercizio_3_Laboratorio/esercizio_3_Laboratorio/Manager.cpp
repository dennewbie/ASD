//
//  Manager.cpp
//  esercizio_3_Laboratorio
//
//  Created by Denny Caruso on 05/10/2020.
//

#include "Manager.hpp"

void Manager::print() {
    Employee::print();
    std::cout << "\nBonus:\t\t$ " << getBonus();
}

float Manager::getBonus() {
    return this->bonus;
}

//float Manager::operator+(Employee secondManager) {
//    return (this->getSalary() + secondManager.getSalary() +  this->getBonus() + secondManager.getBonus());
//}
