//
//  Impiegato.hpp
//  esercizio_3_Laboratorio
//
//  Created by Denny Caruso on 05/10/2020.
//

#ifndef Employee_hpp
#define Employee_hpp

#include <iostream>
#include <forward_list>
#include <string>
#include <iterator>

#endif /* Employee_hpp */

class Employee {
private:
    std::string name;
    float salary;
    
public:
    Employee(std::string name, float salary) : name(name),  salary(0.00) {
        this->salary = (salary >= 0.00) ? salary : 0.00;
    }
    
    virtual ~Employee() { }
    
    virtual void print();
    std::string getName();
    float getSalary();
    
    float operator+(Employee secondEmployee);
};
