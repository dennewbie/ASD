//
//  Nodo.cpp
//  esercizio_3_Laboratorio
//
//  Created by Denny Caruso on 06/10/2020.
//

#include "EmployeeList.hpp"

void EmployeeList::push(Employee *newEmployee) {
    this->empList.push_front(newEmployee);
}

void EmployeeList::pop() {
    this->empList.pop_front();
}

Employee EmployeeList::getEmployee() {
    return *(this->empList.front());
}

void EmployeeList::printAll() {
    for (auto singleEmployee: empList) singleEmployee->print();
    std::cout << "\n\n";
}

float EmployeeList::getSumSalary() {
    float sum = 0.00;
    int distance = (int) std::distance(empList.begin(), empList.end());
    int size = distance/ 2;
    
    std::forward_list<Employee *>::iterator firstIterator = empList.begin(), secondIterator = empList.begin();
    std::advance(secondIterator, 1);
    
//    Senza Conteggio Bonus
        for (int i = 0; i < size; i += 1) {
            sum += **firstIterator + **secondIterator;
            if (distance % 2 == 0) {
                if (i != size - 1) {
                    std::advance(firstIterator, 2);
                    std::advance(secondIterator, 2);
                }
            } else {
                std::advance(firstIterator, 2);
                std::advance(secondIterator, 2);
            }
        }
    
    
    if (distance % 2 != 0) sum += (**firstIterator).getSalary();
    return sum;
}

float EmployeeList::getSumSalaryAndBonus() {
    float sum = 0.00;
    int distance = (int) std::distance(empList.begin(), empList.end());
    int size = distance/ 2;
    
    std::forward_list<Employee *>::iterator firstIterator = empList.begin(), secondIterator = empList.begin();
    std::advance(secondIterator, 1);
    
//    Con Conteggio Bonus
    for (auto i = 0; i < size; i += 1) {
        if (((Manager *) *firstIterator)->getBonus() > 0.00) {
            if (((Manager *) *secondIterator)->getBonus() > 0.00) {
                sum += **firstIterator + **secondIterator + (((Manager *) *firstIterator)->getBonus()) + (((Manager *) *secondIterator)->getBonus());
            } else {
                sum += **firstIterator + **secondIterator + (((Manager *) *firstIterator)->getBonus());
            }
        } else {
            if (((Manager *) *secondIterator)->getBonus() > 0.00) {
                sum += **firstIterator + **secondIterator + (((Manager *) *secondIterator)->getBonus());
            } else {
                sum += **firstIterator + **secondIterator;
            }
        }
        std::advance(firstIterator, 2);
        std::advance(secondIterator, 2);
    }
    
    if (distance % 2 != 0) sum += (**firstIterator).getSalary();
    return sum;
}
