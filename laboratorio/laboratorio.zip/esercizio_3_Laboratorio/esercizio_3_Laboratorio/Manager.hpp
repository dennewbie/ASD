//
//  Manager.hpp
//  esercizio_3_Laboratorio
//
//  Created by Denny Caruso on 05/10/2020.
//

#ifndef Manager_hpp
#define Manager_hpp

#include "Employee.hpp"

#endif /* Manager_hpp */

class Manager : public Employee {
private:
    float bonus;
    
public:
    Manager(std::string name, float salary, float bonus) : bonus(0.00), Employee(name, salary) {
        this->bonus = (bonus >= 0.00) ? bonus : 0.00;
    }
    
    virtual ~Manager() { }
    
    void print();
    float getBonus();
//    void float operator+(Employee secondManager);
};
