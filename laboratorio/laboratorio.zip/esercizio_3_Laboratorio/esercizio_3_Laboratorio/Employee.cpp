//
//  Impiegato.cpp
//  esercizio_3_Laboratorio
//
//  Created by Denny Caruso on 05/10/2020.
//

#include "Employee.hpp"

void Employee::print() {
    std::cout << "\n\nNome:\t\t" << getName() << "\nSalario:\t$ " << getSalary();
}

std::string Employee::getName() {
    return this->name;
}

float Employee::getSalary() {
    return this->salary;
}

float Employee::operator+(Employee secondEmployee) {
    return (this->getSalary() + secondEmployee.getSalary());
}
