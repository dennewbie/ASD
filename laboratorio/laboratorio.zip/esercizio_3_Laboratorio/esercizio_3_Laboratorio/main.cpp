//
//  main.cpp
//  esercizio_3_Laboratorio
//
//  Created by Denny Caruso on 05/10/2020.
//

/*
    Progettare ed implementare una lista (linked list) di impiegati di un'azienda.
    Un impiegato ha un nome ed un salario.
    Un manager è un impiegato cui viene corrisposto un bonus oltre al salario.
 
    1. Creare una lista di impiegati e stamparla a video sfruttando il principio del polimorfismo
    2. Implementare l'overload dell'operatore + in modo da sommare i salari di tutti gli impiegati.
 */

#include "EmployeeList.hpp"

float getSumSalary(std::forward_list<Employee *>);

int main(int argc, const char * argv[]) {
    Employee * pFirstEmployee   =     new Employee(std::string("Pino Laurenti"),   1200);
    Employee * pSecondEmployee  =     new Employee(std::string("Giorgio Tarallo"), 1250);
    Employee * pThirdEmployee   =     new Employee(std::string("Luca Reo"),        1300);
    Employee * pFourthEmployee  =     new Manager(std::string("Raimondo Cusani"),   1900, 150);
    Employee * pFifthEmployee   =     new Manager(std::string("Vanessa Ravenna"),   2000, 100);
    
    EmployeeList empList = EmployeeList();
    empList.push(pFirstEmployee);
    empList.push(pSecondEmployee);
    empList.push(pThirdEmployee);
    empList.push(pFourthEmployee);
    empList.push(pFifthEmployee);
    
//    Stampa Informazioni Impiegati
    empList.printAll(); 
    
//    Somma Salari Impiegati
    float salarySum = empList.getSumSalary();
    std::cout << "\nSomma Salari Impiegati: $ " << salarySum;
    
//    float salaryAndBonusSum = empList.getSumSalaryAndBonus();
//    std::cout << "\nSomma Salari Impiegati + Bonus: $ " << salaryAndBonusSum << "\n\n";
    
    return 0;
}
