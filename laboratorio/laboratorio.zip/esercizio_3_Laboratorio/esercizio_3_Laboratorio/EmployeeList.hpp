//
//  Nodo.hpp
//  esercizio_3_Laboratorio
//
//  Created by Denny Caruso on 06/10/2020.
//

#ifndef List_hpp
#define List_hpp

#include "Manager.hpp"

#endif /* List_hpp */

class EmployeeList {
private:
    std::forward_list<Employee *> empList;
    
public:
    ~EmployeeList() { }
    
    void push(Employee *);
    void pop();
    
    Employee getEmployee();
    void printAll();
    float getSumSalary();
    float getSumSalaryAndBonus();
};
