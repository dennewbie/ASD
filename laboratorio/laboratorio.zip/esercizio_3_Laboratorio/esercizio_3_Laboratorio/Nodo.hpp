//
//  Nodo.hpp
//  esercizio_3_Laboratorio
//
//  Created by Denny Caruso on 06/10/2020.
//

#ifndef Nodo_hpp
#define Nodo_hpp

#include "Manager.hpp"

#endif /* Nodo_hpp */

class List {
    
}
