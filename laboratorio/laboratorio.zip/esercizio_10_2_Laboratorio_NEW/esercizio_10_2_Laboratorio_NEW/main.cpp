//
//  main.cpp
//  esercizio_10_2_Laboratorio_NEW
//
//  Created by Denny Caruso on 15/12/2020.
//

/*
 
 Progettare ed implementare una classe Priority-queue che implementi le seguenti operazioni:
    • Insert(S,x)
    • Maximum(S) / Minimum(S)
    • Extract-Max(S) / Extract-Min(S)
    • Increase-priority(S,x,k) / Decrease-priority(S,x,k)
 
 */

#include "MinPriorityQueue.hpp"
#include <string>

int main(int argc, const char * argv[]) {
//    MinPriorityQueue<int> integerMinPriorityQueue = MinPriorityQueue<int>();
//
//    integerMinPriorityQueue.insertNode(110);
//    integerMinPriorityQueue.insertNode(109);
//    integerMinPriorityQueue.insertNode(108);
//    integerMinPriorityQueue.insertNode(107);
//    integerMinPriorityQueue.insertNode(106);
//    integerMinPriorityQueue.insertNode(105);
//    integerMinPriorityQueue.insertNode(104);
//    integerMinPriorityQueue.insertNode(103);
//
//
//    integerMinPriorityQueue.extractMinimum();
//    integerMinPriorityQueue.extractMinimum();
//    integerMinPriorityQueue.extractMinimum();
//    integerMinPriorityQueue.extractMinimum();
//
//    integerMinPriorityQueue.decreasePriorityAt(100, 5);
//    integerMinPriorityQueue.decreasePriorityAt(3, -5);
//
//    integerMinPriorityQueue.extractMinimum();
    
    
    MinPriorityQueue<std::string, int> stringPQ = MinPriorityQueue<std::string, int>();
    
    
    stringPQ.insertNode(Node<std::string, int>("GINO", 10));
    stringPQ.insertNode(Node<std::string, int>("PINO", 20));
    stringPQ.insertNode(Node<std::string, int>("LINO", 3));
    stringPQ.insertNode(Node<std::string, int>("RINO", 4));
    stringPQ.insertNode(Node<std::string, int>("AINO", 11));
    stringPQ.insertNode(Node<std::string, int>("BINO", 122));
    stringPQ.insertNode(Node<std::string, int>("CINO", 33));
    stringPQ.insertNode(Node<std::string, int>("DINO", 44));
    
    Node<std::string, int> temp = stringPQ.getMinimum();
    std::cout << "NODO MAX: " << temp.getPriority() << " " << temp.getData() << "\n\n";
    
    stringPQ.printMinPQ();
    
    stringPQ.decreasePriorityAt(5, 1);
    temp = stringPQ.getMinimum();
    std::cout << "\nNODO MAX: " << temp.getPriority() << " " << temp.getData() << "\n\n";
    
    stringPQ.extractMinimum();
    stringPQ.extractMinimum();
    stringPQ.extractMinimum();
    stringPQ.extractMinimum();
    stringPQ.extractMinimum();
    stringPQ.extractMinimum();
    stringPQ.extractMinimum();
    stringPQ.extractMinimum();
    stringPQ.extractMinimum();
    
    return 0;
}
