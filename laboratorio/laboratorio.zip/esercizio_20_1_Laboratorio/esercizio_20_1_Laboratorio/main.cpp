//
//  main.cpp
//  esercizio_20_1_Laboratorio
//
//  Created by Denny Caruso on 04/12/2020.
//

/*
    Implementare gli algoritmi di Dijkstra e Bellman-Ford
 */
#include "Graph.hpp"

int main(int argc, const char * argv[]) {
    Graph<char> simpleGraph;
//    simpleGraph.addNode(new Node<char>('A')); // 0
//    simpleGraph.addNode(new Node<char>('B')); // 1
//    simpleGraph.addNode(new Node<char>('C')); // 2
//    simpleGraph.addNode(new Node<char>('D')); // 3
//    simpleGraph.addNode(new Node<char>('E')); // 4
//    simpleGraph.addNode(new Node<char>('F')); // 5
//    simpleGraph.addNode(new Node<char>('G')); // 6
//    simpleGraph.addNode(new Node<char>('H')); // 7
//    simpleGraph.addNode(new Node<char>('I')); // 8
//
//    simpleGraph.addEdge(0, 1, 4);
//    simpleGraph.addEdge(1, 0, 4);
//    simpleGraph.addEdge(1, 2, 8);
//    simpleGraph.addEdge(2, 1, 8);
//    simpleGraph.addEdge(2, 3, 7);
//    simpleGraph.addEdge(3, 2, 7);
//    simpleGraph.addEdge(3, 4, 9);
//    simpleGraph.addEdge(4, 3, 9);
//    simpleGraph.addEdge(4, 5, 10);
//    simpleGraph.addEdge(5, 4, 10);
//    simpleGraph.addEdge(5, 6, 2);
//    simpleGraph.addEdge(6, 5, 2);
//    simpleGraph.addEdge(6, 7, 1);
//    simpleGraph.addEdge(7, 6, 1);
//    simpleGraph.addEdge(7, 8, 7);
//    simpleGraph.addEdge(8, 7, 7);
//    simpleGraph.addEdge(8, 2, 2);
//    simpleGraph.addEdge(2, 8, 2);
//    simpleGraph.addEdge(0, 7, 8);
//    simpleGraph.addEdge(7, 0, 8);
//    simpleGraph.addEdge(2, 5, 4);
//    simpleGraph.addEdge(5, 2, 4);
//    simpleGraph.addEdge(3, 5, 14);
//    simpleGraph.addEdge(5, 3, 14);
//    simpleGraph.addEdge(8, 6, 6);
//    simpleGraph.addEdge(6, 8, 6);
//    simpleGraph.addEdge(1, 7, 11);
//    simpleGraph.addEdge(7, 1, 11);
    
    simpleGraph.addNode(new Node<char>('S')); //0
    simpleGraph.addNode(new Node<char>('U')); //1
    simpleGraph.addNode(new Node<char>('V')); //2
    simpleGraph.addNode(new Node<char>('X')); //3
    simpleGraph.addNode(new Node<char>('Y')); //4

//    simpleGraph.addEdge(0, 1, 10);
//    simpleGraph.addEdge(0, 3, 5);
//    simpleGraph.addEdge(3, 4, 2);
//    simpleGraph.addEdge(4, 0, 7);
//    simpleGraph.addEdge(3, 1, 3);
//    simpleGraph.addEdge(1, 3, 4);
//    simpleGraph.addEdge(3, 2, 9);
//    simpleGraph.addEdge(2, 4, 4);
//    simpleGraph.addEdge(4, 2, 6);
    
    
    
//    simpleGraph.addEdge(0, 1, 10);
//    simpleGraph.addEdge(1, 0, 10);
//    simpleGraph.addEdge(0, 3, 5);
//    simpleGraph.addEdge(3, 0, 5);
//    simpleGraph.addEdge(3, 4, 2);
//    simpleGraph.addEdge(4, 3, 2);
//    simpleGraph.addEdge(4, 0, 7);
//    simpleGraph.addEdge(0, 4, 7);
//
//    simpleGraph.addEdge(3, 1, 3);
//    simpleGraph.addEdge(1, 3, 3);
//    simpleGraph.addEdge(3, 2, 9);
//    simpleGraph.addEdge(2, 3, 9);
//    simpleGraph.addEdge(2, 4, 4);
//    simpleGraph.addEdge(4, 2, 4);
//    simpleGraph.addEdge(1, 2, 1);
//    simpleGraph.addEdge(2, 1, 1);
    
    
    
    simpleGraph.addEdge(0, 1, -2);
    simpleGraph.addEdge(0, 3, -3);
    simpleGraph.addEdge(2, 1, -1);
    simpleGraph.addEdge(3, 2, -1);
    simpleGraph.addEdge(3, 4, -2);
    simpleGraph.addEdge(4, 2, -3);

//    int weight = simpleGraph.kruskalMST();
//    std::cout << "\nPESO KRUSKAL MST: " << weight << "\n";
//    std::cout << "\nKRUSKAL MST:\n";
//    simpleGraph.printMST();
//
//    int weightPrim = simpleGraph.primMST(simpleGraph.getNodeAtIndex(0));
//    std::cout << "\nPESO PRIM MST: " << weightPrim << "\n";
//    std::cout << "\nPRIM MST:\n";
//    simpleGraph.printMST();
//
    std::cout << "\nCAMMINO MINIMO BELLMAN-FORD:\n";
    bool wasAble = simpleGraph.bellmanFord(simpleGraph.getNodeAtIndex(0));
    if (wasAble) {
        std::vector<Node<char>> pathBellmanFord = simpleGraph.getMinimumPathToNode(simpleGraph.getNodeAtIndex(1));
        for (auto singleNode: pathBellmanFord) {
            std::cout << singleNode.getData() << "\n";
        }
    }
    
//    std::cout << "\nCAMMINO MINIMO DIJKSTRA:\n";
//    simpleGraph.dijkstra(simpleGraph.getNodeAtIndex(1));
//    std::vector<Node<char>> pathDijkstra = simpleGraph.getMinimumPathToNode(simpleGraph.getNodeAtIndex(0));
//
//    for (auto singleNode: pathDijkstra) {
//        std::cout << singleNode.getData() /**< " -  " << singleNode.getKey() */<< "\n";
//    }
    
    Node<char> * simpleNode = simpleGraph.getNodeAtIndex(0);
    
    return 0;
}
