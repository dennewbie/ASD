//
//  Node.hpp
//  esercizio_18_3_Laboratorio
//
//  Created by Denny Caruso on 27/11/2020.
//

#ifndef Node_hpp
#define Node_hpp

#include <list>
#include <limits>

#define WHITE 1
#define GRAY  2
#define BLACK 3

template <class T> class Node {
    template<class U> friend class Graph;
private:
    Node<T> * parent; //ptr al padre
    unsigned short int color;
    unsigned int dTime; //tempo in cui è stato scoperto il nodo
    unsigned int fTime; //tempo in cui è stata terminata la visita sul nodo
    T data;
    std::list <Node <T> *> * adjacentList;
    int key;
    int d; //stima superiore del peso del cammino minimo tra s e v
    void resetNode();
    void addEdge(Node * newEdge);
    std::list<Node<T> *> * getAdjacentList();
    
    void setColor(unsigned short int newColor);
    void setParent(Node * newParent);
    void set_dTime(unsigned int new_dTime);
    void set_fTime(unsigned int new_fTime);
    void setKey(int newKey);
    void setD(int newD);

public:
    Node(T data) {
        this->data = data;
        this->color = 0;
        this->parent = nullptr;
        this->dTime = std::numeric_limits<unsigned int>::max();
        this->fTime = std::numeric_limits<unsigned int>::max();
        this->adjacentList = new std::list<Node<T> *>;
        this->key = std::numeric_limits<int>::max();
        this->d = std::numeric_limits<int>::max();
    }
    
//    void addEdge(Node * newEdge);
//    std::list<Node<T> *> * getAdjacentList();
    
    T getData();
    
//    void setColor(unsigned short int newColor);
    unsigned short int getColor();
    
//    void setParent(Node * newParent);
    Node<T> * getParent();
    
//    void set_dTime(unsigned int new_dTime);
    unsigned int get_dTime();
    
//    void set_fTime(unsigned int new_fTime);
    unsigned int get_fTime();
    
//    void setKey(int newKey);
    int getKey();
    
//    void setD(int newD);
    int getD();
    
//    void resetNode();
};

template <class T> void Node<T>::addEdge(Node * newEdge) {
    this->adjacentList->push_back(newEdge);
}

template <class T> std::list<Node <T> *> * Node<T>::getAdjacentList() {
    return this->adjacentList;
}

template <class T> T Node<T>::getData() {
    return this->data;
}

template <class T> void Node<T>::setColor(unsigned short int newColor) {
    this->color = newColor;
}

template <class T> unsigned short int Node<T>::getColor() {
    return this->color;
}

template <class T> void Node<T>::setParent(Node * newParent) {
    this->parent = newParent;
}

template <class T> Node<T> * Node<T>::getParent() {
    return this->parent;
}

template <class T> void Node<T>::set_dTime(unsigned int new_dTime) {
    this->dTime = new_dTime;
}

template <class T> unsigned int Node<T>::get_dTime() {
    return this->dTime;
}

template <class T> void Node<T>::set_fTime(unsigned int new_fTime) {
    this->fTime = new_fTime;
}

template <class T> unsigned int Node<T>::get_fTime() {
    return this->new_fTime;
}

template <class T> void Node<T>::resetNode() {
    setColor(WHITE);
    setParent(nullptr);
    set_dTime(std::numeric_limits< unsigned int>::max());
    set_fTime(std::numeric_limits< unsigned int>::max());
    setKey(std::numeric_limits<int>::max());
    setD(std::numeric_limits<int>::max());
}

template <class T> void Node<T>::setKey(int newKey) {
    this->key = newKey;
}

template <class T> int Node<T>::getKey() {
    return this->key;
}

template <class T> void Node<T>::setD(int newD) {
    this->d = newD;
}

template <class T> int Node<T>::getD() {
    return this->d;
}

#endif /* Node_hpp */
