//
//  MinPriorityQueue.hpp
//  esercizio_10_2_Laboratorio
//
//  Created by Denny Caruso on 30/10/2020.
//

#ifndef MinPriorityQueue_hpp
#define MinPriorityQueue_hpp

#include "MinHeap.hpp"

template <class T> class MinPriorityQueue: private MinHeap<T> {
private:
    
public:
    MinPriorityQueue() {
        MinHeap<T>();
    }
    
    MinPriorityQueue(std::vector<T> newVector) {
        for (auto it: newVector) {
            insertNode(it);
        }
    }
    
    virtual ~MinPriorityQueue() { }
    
    T getMinimum();
    bool extractMinimum();
    void insertNode(T newNode);
    bool decreasePriorityAt(int i, T key);
    
    void printQueue() {
        for (int i = 0; i < this->getHeap().size(); i++) {
            std::cout << this->getHeap().at(i) << "\n";
        }
    }
    
    bool isInsideQueue(T newNode) {
        for (int i = 0; i < this->getHeap().size(); i++) {
            if (newNode == this->getHeap().at(i)) return true;
        }
        
        return false;
    }
    
    int getMinPQ_size() {
        return this->getHeapSize();
    }
    
    unsigned int getIndexOfNode(T newNode) {
        for (int i = 0; i < this->getHeap().size(); i++) {
            if (newNode->getKey() == this->getHeap().at(i)->getKey() && newNode->getData() == this->getHeap().at(i)->getData()) return i;
        }
        
        return -1;
    }
    
    void resetMinPQProperty() {
        this->buildMinHeap();
    }
};

template <class T> T MinPriorityQueue<T>::getMinimum() {
    return this->getHeap().at(0);
}

template <class T> bool MinPriorityQueue<T>::extractMinimum() {
    if (this->getHeapSize() < 0) return false;
    
//    T min = getMinimum();
//    std::cout << "\n" << min << "\n";
    this->heap.at(0) = this->heap.at(this->getHeapSize() - 1);
    this->setHeapSize(this->getHeapSize() - 1);
    this->minHeapify(0);
    this->heap.pop_back();
    return true;
}

template <class T> void MinPriorityQueue<T>::insertNode(T newNode) {
    this->insert(newNode);
}

template <class T> bool MinPriorityQueue<T>::decreasePriorityAt(int i, T key) {
    if (i > this->getHeapSize() - 1) return false;
    if (key->getKey() > this->getHeap().at(i)->getKey()) return false;
    
    this->changeValueAt(i, key);
    //fix with new PQ created
    this->buildMinHeap();
    return true;
}

#endif /* MinPriorityQueue_hpp */
