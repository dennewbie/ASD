//
//  main.cpp
//  esercizio_11_2_Laboratorio
//
//  Created by Denny Caruso on 02/11/2020.
//

//Radix Sort

#include <iostream>
#include <string>
using namespace std;

void printArray(string *array, int size) {
    for (int i = 0; i < size; i++) {
        cout << array[i] << "\n";
    }
    cout << "\n";
}

void radixSort(string *array, int size, int nDigits) {
    string *temp = new string[size];

    for(int i = nDigits - 1; i >= 0; i--) {
        int occourrences[26] = { 0 };

        for(int j = 0; j < size; j++) {
            if(array[j][i] == 'z') continue; //altrimenti crasha sull'ultima lettera
            occourrences[(array[j][i]) - 96] += 1;
        }

        for(int j = 2; j < 26; j++) {
            occourrences[j] += occourrences[j - 1];
        }
        
        for(int j = 0; j < size; j++) {
            temp[occourrences[(array[j][i]) - 97]] = array[j];
            occourrences[(array[j][i]) - 97] += 1;
        }

        for(int j = 0; j < size; j++) array[j] = temp[j];
//        std::cout << "HERE\n";
//        printArray(temp, size);
    }
}

int main(int argc, const char * argv[]) {
    string array[] = {
        "zzzz",
        "bbbb",
        "aabb",
        "bbaa",
        "cccc",
        "dddd",
        "ccaa",
        "ddaa"  };
    
    int size = sizeof(array) / sizeof(array[0]);
    printArray(array, size);
    radixSort(array, size, 4);
    printArray(array, size);
    return 0;
}
