//
//  MinHeap.hpp
//  esercizio_10_2_Laboratorio
//
//  Created by Denny Caruso on 30/10/2020.
//

#ifndef Heap_hpp
#define Heap_hpp

#include <iostream>
#include <vector>
#include <math.h>

template <class T> class MinHeap {
private:
    int heapSize;
    bool isHeap;
//    std::vector<T> heap;
//    void setHeapSize(int currentHeapSize);
    void setIsHeap(bool);
    
    int parent(int i);
    int left(int i);
    int right(int i);
    
//    void minHeapify(int i);
    void swap(T &firstNode, T &secondNode);
    
    void putSpaces(int numberOfSpaces);
    
protected:
    std::vector<T> heap;
    std::vector<T> getHeap();
    
    void minHeapify(int i);
    void setHeapSize(int currentHeapSize);
    
public:
    MinHeap() {
        this->heapSize = 0;
        this->isHeap = true;
    }
    
    MinHeap(std::vector<T> heap) {
        this->heap = heap;
        this->heapSize = 0;
        this->isHeap = false;
//        buildMinHeap();
    }
    
    virtual ~MinHeap() { }
    int getHeapSize();
    bool getIsHeap();
    void printHeap();
    void printArray();
    void printHeapTree();
    void buildMinHeap();
    void insert(T newNode);
    void heapSort();
    void changeValueAt(int i, T key);
};

template <class T> int MinHeap<T>::parent(int i){
    return (i - 1) / 2;
}

template <class T> int MinHeap<T>::left(int i){
    return (2 * i) + 1;
}

template <class T> int MinHeap<T>::right(int i){
    return (2 * i) + 2;
}

template <class T> void MinHeap<T>::printHeap() {
    for (int i = 0; i < getHeapSize(); i++) std::cout << getHeap().at(i) << "\n";
    std::cout << "\n\n";
}

template <class T> void MinHeap<T>::printArray() {
    for (auto node: this->heap) std::cout << node << "\n";
    std::cout << "\n\n";
}

template <class T> void MinHeap<T>::printHeapTree() {
    int j = 1, k = getHeapSize(), l = 0;
    putSpaces(k + k/2); k--;
    std::cout << getHeap().at(0) << "\n";
    
    for (int i = 1; i < getHeapSize(); i++) {
        if (l == j) {
            j = pow(2, j + 1);
            putSpaces(k - 1);
            k = (k + 1)/ 2;
            std::cout << getHeap().at(i) << "\n";
        } else {
            l++;
            putSpaces(k);
            std::cout << getHeap().at(i);
        }
    }
    std::cout << "\n\n";
}

template <class T> void MinHeap<T>::putSpaces(int numberOfSpaces) {
    for (int i = 0; i < numberOfSpaces; i++) std::cout <<" ";
}

template <class T> void MinHeap<T>::setHeapSize(int currentHeapSize) {
    this->heapSize = currentHeapSize;
}

template <class T> void MinHeap<T>::setIsHeap(bool newValueIsHeap) {
    this->isHeap = newValueIsHeap;
}

template <class T> std::vector<T> MinHeap<T>::getHeap() {
    return this->heap;
}

template <class T> int MinHeap<T>::getHeapSize() {
    return this->heapSize;
}

template <class T> bool MinHeap<T>::getIsHeap() {
    return this->isHeap;
}

template <class T> void MinHeap<T>::buildMinHeap() {
    setHeapSize((int) getHeap().size());
    
    for (int i = (getHeapSize() / 2) - 1; i >= 0; i--) minHeapify(i);
    setIsHeap(true);
}

template <class T> void MinHeap<T>::minHeapify(int index) {
    int minimum = index;
    int l = left(minimum), r = right(minimum);
    
    if (l < getHeapSize() && getHeap().at(l) < getHeap().at(minimum)) minimum = l;
    if (r < getHeapSize() && getHeap().at(r) < getHeap().at(minimum)) minimum = r;
    
    if (minimum != index) {
        swap(this->heap.at(index), this->heap.at(minimum));
        minHeapify(minimum);
    }
    setIsHeap(true);
}

template <class T> void MinHeap<T>::swap(T &firstNode, T &secondNode) {
    T temp = firstNode;
    firstNode = secondNode;
    secondNode = temp;
}

template <class T> void MinHeap<T>::insert(T newNode) {
    setHeapSize(getHeapSize() + 1);
    this->heap.push_back(newNode);
    
    int i = getHeapSize() - 1;
    while (i > 0 && getHeap().at(parent(i)) > getHeap().at(i)) {
        swap(this->heap.at(i), this->heap.at(parent(i)));
        i = parent(i);
    }
}

template <class T> void MinHeap<T>::heapSort() {
    buildMinHeap();
    for (int i = getHeapSize() - 1; i > 0; i--) {
        swap(this->heap.at(0), this->heap.at(i));
        setHeapSize(getHeapSize() - 1);
        minHeapify(0);
    }
    
    std::reverse(this->heap.begin(), this->heap.end());
}

template <class T> void MinHeap<T>::changeValueAt(int index, T key) {
    this->heap.at(index) = key;
    
    int i = getHeapSize() - 1;
    while (i > 0 && getHeap().at(parent(i)) > getHeap().at(i)) {
        swap(this->heap.at(i), this->heap.at(parent(i)));
        i = parent(i);
    }
}
#endif /* HeapMin_hpp */
