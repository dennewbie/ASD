//
//  Huffman.hpp
//  esercizio_17_1_Laboratorio
//
//  Created by Denny Caruso on 25/11/2020.
//

#ifndef Huffman_hpp
#define Huffman_hpp

#include "binaryTree.h"
#include "MinPriorityQueue.hpp"

#include <string>
#include <map>
#include <fstream>
#include <algorithm>


class Huffman {
private:
    std::fstream * inputFileStream;
    std::fstream * encodedFileStream;
    std::fstream * decodedFileStream;
    
    std::string inputFileName;
    std::string encodedFileName;
    std::string decodedFileName;
    
    std::vector<float> frequencyVector;
    
    Btree huffmanTree;
    std::map <char, float> frequencyMap;
    MinPriorityQueue<float> minPQ;
    
    void buildHuffmanTree();
    void initializeFileStream();
    void closeFileStream();
    void createFrequencyMap();
    void printMap();
    void calculateFrequencyForEachChar();
    void createFrequencyVector();
    void getCode(Node curr, std::string * encodedChar, float frequency, bool * flag);
    void fixupTree(Node *curr);
    
public:
    Huffman(std::fstream * inputFileStream, std::fstream * encodedFileStream, std::fstream * decodedFileStream, std::string inputFileName, std::string encodedFileName, std::string decodedFileName) {
        this->inputFileStream = inputFileStream;
        this->encodedFileStream = encodedFileStream;
        this->decodedFileStream = decodedFileStream;
        this->inputFileName = inputFileName;
        this->encodedFileName = encodedFileName;
        this->decodedFileName = decodedFileName;
        initializeFileStream();
        createFrequencyMap();
        createFrequencyVector();
        buildHuffmanTree();
    }
    
    ~Huffman() {
        closeFileStream();
    }
    
    void encodeFile();
    void decodeFile();
    
};

void Huffman::createFrequencyVector() {
    for (auto singleMapElement: this->frequencyMap) this->frequencyVector.push_back(singleMapElement.second);
}

void Huffman::createFrequencyMap() {
    std::string singleWord;

    while (*inputFileStream >> singleWord) {
        singleWord.erase(std::remove_if(singleWord.begin(), singleWord.end(), [](char c) { return (c == ',' || c== '.' || c == ' '); }));
        for (auto i = 0; i < singleWord.size(); i++) this->frequencyMap[singleWord.at(i)]++;
    }
    
    calculateFrequencyForEachChar();
}

void Huffman::calculateFrequencyForEachChar() {
    unsigned int totalOccurrences = 0;
    
    for (auto singleMapElement: this->frequencyMap) totalOccurrences += singleMapElement.second;
    for (auto & singleMapElement: this->frequencyMap) singleMapElement.second = (singleMapElement.second * 100) / totalOccurrences;
}

void Huffman::printMap() {
    std::cout << "\nMAP:\n";
    for (auto singleMapElement: frequencyMap) std::cout << std::setprecision(3) << "Key: " << singleMapElement.first << "\nValue: " << singleMapElement.second << "% \n\n";
    std::cout << "\n";
}

void Huffman::initializeFileStream() {
    this->inputFileStream->open(this->inputFileName.c_str());
    this->encodedFileStream->open(this->encodedFileName.c_str());
    this->decodedFileStream->open(this->decodedFileName.c_str());
    
    if (inputFileStream->fail() || encodedFileStream->fail() || decodedFileStream->fail()) exit(0);
}

void Huffman::closeFileStream() {
    this->inputFileStream->close();
    this->encodedFileStream->close();
    this->decodedFileStream->close();
}

void Huffman::buildHuffmanTree() {
    this->minPQ = MinPriorityQueue<float>(this->frequencyVector);
    
    unsigned int mapSize = (unsigned int) this->frequencyMap.size();
    float left, right, parent;
    
    for (auto i = 0; i < mapSize - 1; i++) {
        left = minPQ.getMinimum();
        minPQ.extractMinimum();
        right = minPQ.getMinimum();
        minPQ.extractMinimum();
        parent = left + right;
        minPQ.insertNode(parent);
        
        Node * z = new Node;
        z->left = new Node;
        z->left->left = nullptr;
        z->left->right = nullptr;
        z->right = new Node;
        z->right->left = nullptr;
        z->right->right = nullptr;
        z->value = parent;
        
        if (huffmanTree.root == nullptr) {
            z->value = left + right;
            z->left->value = left;
            z->right->value = right;
            huffmanTree.root = nullptr;
            huffmanTree.root = z;
        } else {
            Node * partialTree = huffmanTree.root;
            if (partialTree->value == left) {
                z->value = left + right;
                z->left = partialTree;
                z->right->value = right;
                huffmanTree.root = nullptr;
                huffmanTree.root = z;
            } else if (partialTree->value == right) {
                z->value = left + right;
                z->left->value = left;
                z->right = partialTree;
                huffmanTree.root = nullptr;
                huffmanTree.root = z;
            } else {
                //trova il ptr al nodo partialTree che ha stesso value in z
                /*
                 dovvresti andare a fare un array di alberi temporanei da unire man mano che li incontri al momento
                 dell'estrazione dalla minPQ all'albero principale
                 */
                
//                std::cout << "here\n";
//                node alfa = *partialTree;
//                z->value = left + right;
//                z->left->value = left;
//                z->right->value = right;
//                huffmanTree.root = new node;
//                huffmanTree.root->value = alfa.value + z->value;
//                huffmanTree.root->left = new node;
//                huffmanTree.root->right = new node;
//                huffmanTree.root->left->value = alfa.value;
//                huffmanTree.root->left->left = alfa.left;
//                huffmanTree.root->left->right = alfa.right;
//                huffmanTree.root->right = z;
            }
        }
    }
    std::cout << "\n";
//    for (auto i: this->frequencyMap) {
//        node *leaf = huffmanTree.search(i.second);
//        if (leaf != nullptr) {
//            leaf->left = nullptr;
//            leaf->right = nullptr;
//        }
//    }
    fixupTree(huffmanTree.root);
    
}

void Huffman::fixupTree(Node *curr) {
    if (curr == nullptr) return;
    
    if (curr->left == nullptr) {
        curr->right = nullptr;
    }
    
    if (curr->right == nullptr) {
        curr->left = nullptr;
    }
    
    fixupTree(curr->left);
    fixupTree(curr->right);
}

void Huffman::getCode(Node curr, std::string * encodedChar, float frequency, bool * flag) {
    if (curr.value != frequency) {
        if (curr.value < frequency) {
            *encodedChar = encodedChar->substr(0, encodedChar->length() - 1);
            return;
        }
        if (*flag == true) return;
        if (curr.left != nullptr) {
            encodedChar->append(std::to_string(0));
            getCode(*curr.left, encodedChar, frequency, flag);
        } else {
            *encodedChar = encodedChar->substr(0, encodedChar->length() - 1);
            return;
        }
        
        if (*flag == true) return;
        if (curr.right != nullptr) {
            encodedChar->append(std::to_string(1));
            getCode(*curr.right, encodedChar, frequency, flag);
        } else {
            *encodedChar = encodedChar->substr(0, encodedChar->length() - 1);
            return;
        }
    } else {
        *flag = true;
        return;
    }
}

void Huffman::encodeFile() {
    std::string singleWord = "";
    
    inputFileStream->close();
    inputFileStream->open(inputFileName.c_str());
    if (inputFileStream->fail()) exit(0);
    
    while (*inputFileStream >> singleWord) {
        singleWord.erase(std::remove_if(singleWord.begin(), singleWord.end(), [](char c) { return (c == ',' || c== '.' || c == ' '); }));

        for (auto i = 0; i < singleWord.size(); i++) {
            float frequency = frequencyMap[singleWord.at(i)];
            bool flag = false;
            std::string temp = "";
            getCode(*huffmanTree.root, &temp, frequency, &flag);
            *encodedFileStream << temp;
            std::cout << "\nSCRIVO: " << temp << "\n";
        }
    }
    
    printMap();
}

void Huffman::decodeFile() {
    std::string singleWord = "";
    std::string temp = "";
    Node curr = *huffmanTree.root;
    
    encodedFileStream->close();
    encodedFileStream->open(encodedFileName.c_str());
    if (encodedFileStream->fail()) exit(0);
    
    decodedFileStream->close();
    decodedFileStream->open(decodedFileName.c_str());
    if (decodedFileStream->fail()) exit(0);
    
    while (*encodedFileStream >> singleWord) {
        singleWord.erase(std::remove_if(singleWord.begin(), singleWord.end(), [](char c) { return (c == ',' || c== '.' || c == ' '); }));
        
        for (int i = 0; i < singleWord.size(); i++) {
            if (singleWord.at(i) == '0') {
                curr = *curr.left;
            } else {
                curr = *curr.right;
            }
            
            if (curr.right == nullptr && curr.left == nullptr) {
                for (auto it: frequencyMap) {
                    if (it.second == curr.value) {
                        temp = temp + it.first;
                        break;
                    }
                }
                curr = *huffmanTree.root;
            }
            
        }
        *decodedFileStream << temp;
        temp = "";
    }
}

#endif /* Huffman_hpp */
