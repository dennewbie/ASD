//
//  BinaryTree.h
//  esercizio_17_1_Laboratorio
//
//  Created by Denny Caruso on 24/11/2020.
//

#ifndef binaryTree_h
#define binaryTree_h

#include <iostream>

using namespace std;

struct Node {
    float value;
    bool isEmpty = false;
    Node * left;
    Node * right;
};

class Btree{
public:
    Btree();
    ~Btree();

    void insert(float key);
    Node * search(float_t key);
    void destroy_tree();
    void inorder_print();
    void postorder_print();
    void preorder_print();
    Node * root;

private:
    void destroy_tree(Node *leaf);
    void insert(float key, Node *leaf);
    Node *search(float key, Node *leaf);
    void inorder_print(Node *leaf);
    void postorder_print(Node *leaf);
    void preorder_print(Node *leaf);
};


Btree::Btree(){
    root = nullptr;
}

Btree::~Btree(){
    
}

//
//void btree::destroy_tree(node *leaf){
//    if(leaf != NULL){
//        destroy_tree(leaf->left);
//        destroy_tree(leaf->right);
//        delete leaf;
//    }
//}

void Btree::insert(float key, Node *leaf){
    if(key < leaf->value){
        if(leaf->left != NULL){
            insert(key, leaf->left);
        }else{
            leaf->left = new Node;
            leaf->left->value = key;
            leaf->left->left = NULL;
            leaf->left->right = NULL;
        }
    }else if(key >= leaf->value){
        if(leaf->right != NULL){
            insert(key, leaf->right);
        }else{
            leaf->right = new Node;
            leaf->right->value = key;
            leaf->right->right = NULL;
            leaf->right->left = NULL;
        }
    }
}

void Btree::insert(float key){
    if(root != NULL){
        insert(key, root);
    }else{
        root = new Node;
        root->value = key;
        root->left = NULL;
        root->right = NULL;
    }
}

Node *Btree::search(float key, Node *leaf){
    if(leaf != NULL){
        if(key == leaf->value){
            return leaf;
        }
        if(key < leaf->value){
            return search(key, leaf->left);
        }else{
            return search(key, leaf->right);
        }
    }else{
        return NULL;
    }
}

Node *Btree::search(float key){
    return search(key, root);
}

//
//void btree::destroy_tree(){
//    destroy_tree(root);
//}

void Btree::inorder_print(){
    inorder_print(root);
    cout << "\n";
}

void Btree::inorder_print(Node *leaf){
    if(leaf != NULL){
        inorder_print(leaf->left);
        cout << leaf->value << ",";
        inorder_print(leaf->right);
    }
}

void Btree::postorder_print(){
    postorder_print(root);
    cout << "\n";
}

void Btree::postorder_print(Node *leaf){
    if(leaf != NULL){
        inorder_print(leaf->left);
        inorder_print(leaf->right);
        cout << leaf->value << ",";
    }
}

void Btree::preorder_print(){
    preorder_print(root);
    cout << "\n";
}

void Btree::preorder_print(Node *leaf){
    if(leaf != NULL){
        cout << leaf->value << ",";
        inorder_print(leaf->left);
        inorder_print(leaf->right);
    }
}

#endif /* binaryTree_h */
