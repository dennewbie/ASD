//
//  main.cpp
//  esercizio_19_4_Laboratorio
//
//  Created by Denny Caruso on 30/11/2020.
//

/*
    Creare la struttura dati risultante dal seguente codice e
    mostrare il risultato delle ultime due funzioni
 */

#include "DisjointSet.h"
#include <iostream>

int main(int argc, const char * argv[]) {
    unsigned int inputValue = 16;
    DisjointSet disjoinSet = DisjointSet(inputValue);
    
    for (int i = 0; i < inputValue; i++) {
        disjoinSet.makeSet(i);
    }
    
    for (int i = 0; i < 15; i += 2) {
        disjoinSet.unionSet(i, i + 1);
    }
    
    for (int i = 0; i < 13; i += 4) {
        disjoinSet.unionSet(i, i + 2);
    }
    
    disjoinSet.unionSet(1, 5);
    disjoinSet.unionSet(11, 13);
    disjoinSet.unionSet(1, 10);
    unsigned int rappr_1 = disjoinSet.findSet(2);
    unsigned int rappr_2 = disjoinSet.findSet(9);
    
    std::cout << "RAPPR 1: " << rappr_1 << "\nRAPPR 2: " << rappr_2 << "\n\n";
}
