//
//  main.cpp
//  esercizio_21_1_Laboratorio
//
//  Created by Denny Caruso on 07/12/2020.
//

/*
    Progettare ed implementare una soluzione al problema delle N regine
 */

#include "Queens.hpp"

int main(int argc, const char * argv[]) {
    Queens queenProblem(10);

    if (queenProblem.solveOne(0) == false) {
        std::cout << "\nSoluzione inesistente...\n";
        return 0;
    } else {
        std::cout << "\nUna sola soluzione:" << std::endl;
        queenProblem.printBoard();
    }
    
    
    queenProblem.resetBoard();
    int nSolutions = queenProblem.solveAll(0);
    if (nSolutions == 0) {
        std::cout << "\nSoluzione inesistente...\n";
        return 0;
    } else {
        std::cout << "\nNumero Soluzioni: " << nSolutions << "\n";
    }
    
    return 0;
}
