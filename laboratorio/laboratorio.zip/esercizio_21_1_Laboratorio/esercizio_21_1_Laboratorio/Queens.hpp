//
//  Queens.hpp
//  esercizio_21_1_Laboratorio
//
//  Created by Denny Caruso on 07/12/2020.
//

#ifndef Queens_hpp
#define Queens_hpp

#include <iostream>
#include <vector>

class Queens {
private:
    int boardSize; //size scacchiera
    std::vector<bool> board;
    
    bool check(int rowIndex, int colIndex);
    
    void setBoardSize(int newBoardSize);
    void setBoard(std::vector<bool>);
    int getBoardSize();
    std::vector<bool> getBoard();

public:
    Queens(int boardSize) {
        setBoardSize(boardSize);
        setBoard(std::vector<bool>(boardSize * boardSize, false));
    }
    
    ~Queens() { };
    
    void printBoard();
    
    //Restituisce una soluzione
    bool solveOne(int col);
    //Restituisce il numero totale di soluzioni
    int solveAll(int col);
    
    void resetBoard();
};

void Queens::setBoardSize(int newBoardSize) {
    this->boardSize = newBoardSize;
}

void Queens::setBoard(std::vector<bool> newBoard) {
    this->board = newBoard;
}

int Queens::getBoardSize() {
    return this->boardSize;
}

std::vector<bool> Queens::getBoard() {
    return this->board;
}

void Queens::resetBoard() {
    for (auto i = 0; i < getBoardSize(); i++) {
        for (auto j = 0; j < getBoardSize(); j++) {
            this->board[i * getBoardSize() + j] = false;
        }
    }
}

bool Queens::check(int rowIndex, int colIndex) {
    //controllo la riga
    for (auto i = 0; i < colIndex; i++) {
        auto k = (rowIndex * getBoardSize()) + i;
        if (this->board.at(k)== true) return false;
    }
    
    //controllo la diagonale in alto a sinistra
    for (auto i = rowIndex, j = colIndex; i >= 0 && j >= 0; i--, j--) {
        int k = (i * getBoardSize()) + j;
        if (this->board.at(k) == true) return false;
    }
    
    //controllo la diagonale in basso a sinistra
    for (auto i = rowIndex, j = colIndex; j >= 0 && i < getBoardSize(); i++, j--) {
        int k = (i * getBoardSize()) + j;
        if (this->board.at(k) == true) return false;
    }
    
    return true;
}

void Queens::printBoard() {
//    static int k = 1;
//    std::cout << "\nSoluzione: " << k++ << "\n";
    
    for (auto i = 0; i < getBoardSize(); i++){
        for (auto j = 0; j < getBoardSize(); j++) std::cout << board.at(i * boardSize + j) << " ";
        std::cout << "\n";
    }
    
    std::cout << "\n";
}

bool Queens::solveOne(int colIndex) {
    if (colIndex >= getBoardSize()) return true;
    
    for (auto i = 0; i < getBoardSize(); i++) {
        if (check(i, colIndex)) {
            this->board[i * getBoardSize() + colIndex] = true;
            
            if (solveOne(colIndex + 1) == true) return true;
            
            this->board[i * getBoardSize() + colIndex] = false;
        }
    }
    
    return false;
}

int Queens::solveAll(int colIndex) {
    static int counter = 0;
    if (colIndex >= getBoardSize()) {
        counter++;
        
        printBoard();
        return counter;
    }
    
    bool res = false;
    
    for (auto i = 0; i < getBoardSize(); i++) {
        if (check(i, colIndex)) {
            this->board[i * getBoardSize() + colIndex] = true;
            
            res = solveAll(colIndex + 1) || res;
            
            this->board[i * getBoardSize() + colIndex] = false;
        }
    }
    
    return counter;
}

#endif /* Queens_hpp */
