//
//  main.cpp
//  esercizio_6_3_Laboratorio
//
//  Created by Denny Caruso on 16/10/2020.
//

/*
    Dato un insieme di N numeri, rimuovere gli elementi duplicati
 */

#include <iostream>
#include <forward_list>

std::forward_list<int> removeDuplicate(std::forward_list<int>);
void printList(std::forward_list<int>);

int main(int argc, const char * argv[]) {
    std::forward_list<int> numberList;
    numberList.push_front(20);  numberList.push_front(30);  numberList.push_front(130);  numberList.push_front(30);
    numberList.push_front(1);   numberList.push_front(20);  numberList.push_front(10);   numberList.push_front(1);
    numberList.push_front(13);  numberList.push_front(20);
    
    numberList.sort();
    std::cout << "\n\nPrima:\n";
    printList(numberList);
    numberList = removeDuplicate(numberList);
    std::cout << "\n\nDopo:\n";
    printList(numberList);
    
    return 0;
}

void printList(std::forward_list<int> flist) {
    for (std::forward_list<int>::iterator it = flist.begin(); it != flist.end(); it++) std::cout << *it << "\n";
}

std::forward_list<int> removeDuplicate(std::forward_list<int> numberList) {
    std::forward_list<int>::iterator temp = numberList.begin(), i;
    
    for (i = std::next(numberList.begin()); i != numberList.end(); i++) {
        if (*temp == *i) {
            numberList.erase_after(temp);
        } else {
            std::advance(temp, 1);
        }
    }
    
    return numberList;
}
