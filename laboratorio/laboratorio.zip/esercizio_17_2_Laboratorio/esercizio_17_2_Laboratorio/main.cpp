//
//  main.cpp
//  esercizio_17_2_Laboratorio
//
//  Created by Denny Caruso on 23/11/2020.
//

/*
     Bisogna pianificare un viaggio in autostrada entrando al km 0 ed uscendo al km N.
     • L'auto con serbatoio pieno ha un'autonomia di m km.
     • Esistono n stazioni di servizio ai km d[1...n] in cui è possibile fare il pieno.
     • Progettare un algoritmo greedy che consenta di minimizzare il numero di soste.
 */

#include <iostream>
#include <vector>

std::vector<int> findMinimumStation(std::vector<int> * stations, int km_N, int autonomy);

int main(int argc, const char * argv[]) {
    int km_N = 30;
    int autonomy = 5;
    std::vector<int> stations = { 1, 6, 11, 15, 17, 18, 19, 22, 25, 31 };
    
    std::vector<int> stops = findMinimumStation(&stations, km_N, autonomy);
    std::cout << "\nSTAZIONI IN CUI MI FERMO: \n";
    for (auto i: stops) std::cout << i << "\n";
    return 0;
}

std::vector<int> findMinimumStation(std::vector<int> * stations, int km_N, int autonomy) {
    int max = autonomy;
    std::vector<int> stops;
    
    for (auto i = 0; i < stations->size(); i++) {
        if (stations->at(i) > max) {
            if (i == 0) return stops;
            if ((stations->at(i) - (stations->at(i - 1) + autonomy)) > 0){
                return stops;
            }
            stops.push_back(stations->at(i - 1));
            max = stations->at(i - 1) + autonomy;
        }
    }
    
    if (max < km_N) stops.push_back(stations->at(stations->size() - 1));
    return stops;
}
