//
//  main.cpp
//  esercizio_11_3_Laboratorio
//
//  Created by Denny Caruso on 02/11/2020.
//

/*
    Progettare ed implementare un algoritmo che dato in input un array di stringhe
    le ordini in modo che ogni stringa sia una sottostringa delle successive
    Es.: [palmare, re, spalmare, mare]
        re
        mare
        palmare
        spalmare
 */

/*
#include <iostream>
using namespace std;
  
void printArraystring(string, int);
void sort(string array[], int size) {
    for (int i = 1 ; i < size; i++) {
        string temp = array[i];
        
        int j = i - 1;
        while (j >= 0 && temp.length() < array[j].length()) {
            array[j + 1] = array[j];
            j--;
        }
        array[j + 1] = temp;
    }
}

bool checkSubstringArray(string *array, int size) {
    for (int i = size - 1; i > 0; i--) {
        if (array[i].find(array[i - 1]) == std::string::npos) return false;
    }
    
    return true;
}
   
void printArray(string *array, int size) {
    for (int i = 0; i < size; i++) cout << array[i] << "\n";
    cout << "\n";
}
  
int main() {
    string array[] = { "palmare", "re", "spalmare", "mare" };
    int size = sizeof(array) / sizeof(array[0]);
    
    sort(array, size);
    bool checkProperty = checkSubstringArray(array, size);
    cout << std::boolalpha << checkProperty << "\n\n";
    
    printArray(array, size);
    return 0;
}

*/
 //MAX:
 #include <iostream>
 #include <vector>
 #include <string.h>
 #include <iterator>
 using namespace std;

 void print2D(vector<vector<string>> matrix) {
     for (int i = 0; i < matrix.size(); i++) {
         for (int j = 0; j < matrix[i].size(); j++)
             cout << matrix[i][j] << "\t";
         cout << endl;
     }
 }

 void printVector(vector<string> a) {
     for(int i = 0; i < a.size(); i++)
         cout << a[i] << "\t";
     cout << endl;
 }
 void printVector(vector<int> a) {
     for(int i = 0; i < a.size(); i++)
         cout << a[i] << "\t";
     cout << endl;
 }


 int getMax(vector<string> A) {
     string max = A[0];
     for(int i = 1; i < A.size(); i++)
         if(A[i].length() > max.length())
             max = A[i];
     return max.length();
 }


 vector<string> countingSort(vector<string> A) {
     int max = getMax(A);

     int lengthC = max + 1;
     vector<int> c(lengthC, 0);
     vector<string> output(A.size());

     for(int j = 0; j < A.size(); j++)
         c[A[j].length()]++;

     for(int i = 1; i < lengthC; i++)
         c[i] += c[i-1];

     for(int j = A.size() - 1; j >= 0; j--) {
         output[c[A[j].length()] - 1] = A[j];
         c[A[j].length()]--;
     }
     return output;
 }

// vector<vector<string>> func(vector<string> A, vector<string> output) {
//     vector<vector<string>> matrix;
//     for(int i = 0; i < A.size() - 1; i++) {
//         vector<string> temp;
//         temp.push_back(output[i]);
//         for(int j = i + 1; j < A.size(); j++) {
//             auto it = output[j].find(output[i]);
//             if(it != string::npos && output[i].length() < output[j].length())
//                     temp.push_back(output[j]);
//         }
//         if(temp.size() != 1)
//             matrix.push_back(temp);
//         temp.clear();
//     }
//     return matrix;
// }

 bool func(vector<string> output) {
     for(int i = 0; i < output.size() - 1; i++) {
         auto it = output[i+1].find(output[i]);
         if(it == string::npos || output[i].length() == output[i+1].length())
             return 0;
     }
     return 1;
 }

 int main() {
     vector<string> Vector = {"mare", "spalmare", "re", "palmare"};
     vector<string> output = countingSort(Vector);
     bool result;
     printVector(output);
 
//    auto matrix = func(Vector, output);
//     if(matrix.size())
//         print2D(matrix);
//     else
//         cout << "empty matrix" << endl;
    ((result = func(output))) ? cout << "Array di input valido" : cout << "Sequenza non valida";
    cout << endl;

     return 0;
 }


