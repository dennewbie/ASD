//
//  main.cpp
//  esercizio_21_2_Laboratorio
//
//  Created by Denny Caruso on 07/12/2020.
//

/*
    Un percorso Hamiltoniano in un grafo non orientato è un percorso che visita ogni vertice
    esattamente una volta.
 
    Un ciclo Hamiltoniano è un percorso Hamiltoniano tale che esiste un arco tra il primo
    e l'ultimo vertice del percorso.
 
    Progettare ed implementare un algoritmo in grado di determinare la presenza di un ciclo
    Hamiltoniano in un grafo e mostrarne i vertici.
 */

#include "Graph.hpp"

int main(int argc, const char * argv[]) {
    Graph simpleGraph(3);


    simpleGraph.addEdge(0, 1);
    simpleGraph.addEdge(1, 2);
    simpleGraph.addEdge(2, 0);
     
    simpleGraph.printMatrix();
    
    std::vector<int> path = std::vector<int>(simpleGraph.getNumVertices(), 0);
    
    int pos = 0;
    path.at(0) = pos;
    bool isHamiltonian = simpleGraph.hamiltonianCycle(path, pos);
    std::cout << "\nIl grafo è hamiltoniano: " << std::boolalpha<< isHamiltonian << "\n";
    
    if (isHamiltonian) for (auto i: path) std::cout << i << " ";
    std::cout << "\n\n";
    return 0;
}
