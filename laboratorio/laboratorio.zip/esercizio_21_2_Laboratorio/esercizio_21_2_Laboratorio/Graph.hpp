//
//  Graph.hpp
//  esercizio_21_2_Laboratorio
//
//  Created by Denny Caruso on 07/12/2020.
//

#ifndef Graph_hpp
#define Graph_hpp

// Adjacency Matrix representation in C++
#include <iostream>
#include <vector>

class Graph {
private:
    std::vector<bool> adjMatrix;
    int numVertices;
    
    void setNumVertices(int newNumVertices);
    void setAdjMatrix(std::vector<bool> newAdjMatrix);
    std::vector<bool> getMatrix();
    
    bool check(int index, std::vector<int> & path, int pos);
public:
    Graph(int numVertices) {
        setNumVertices(numVertices);
        setAdjMatrix(std::vector<bool>(numVertices * numVertices, false));
    }
    
    ~Graph() { }
    
    int getNumVertices();

    void addEdge(int i, int j);
    void removeEdge(int i, int j);

    void printMatrix();
    
    bool hamiltonianCycle(std::vector<int> & path, int pos);
};

#endif /* Graph_hpp */
