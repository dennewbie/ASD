//
//  Graph.cpp
//  esercizio_21_2_Laboratorio
//
//  Created by Denny Caruso on 07/12/2020.
//

#include "Graph.hpp"

void Graph::setNumVertices(int newNumVertices) {
    this->numVertices = newNumVertices;
}

void Graph::setAdjMatrix(std::vector<bool> newAdjMatrix) {
    this->adjMatrix = newAdjMatrix;
}
int Graph::getNumVertices() {
    return this->numVertices;
}

std::vector<bool> Graph::getMatrix() {
    return this->adjMatrix;
}

void Graph::printMatrix() {
    for (int i = 0; i < getNumVertices(); i++) {
        std::cout << i << " : ";
        for (int j = 0; j < getNumVertices(); j++) std::cout << this->adjMatrix[i * getNumVertices() + j] << " ";
        std::cout << "\n";
    }
}

void Graph::addEdge(int i, int j) {
    //grafo non orientato
    this->adjMatrix[i * getNumVertices() + j] = true;
    this->adjMatrix[j * getNumVertices() + i] = true;
}

void Graph::removeEdge(int i, int j) {
    this->adjMatrix[i * getNumVertices() + j] = false;
    this->adjMatrix[j * getNumVertices() + i] = false;
}

bool Graph::check(int index, std::vector<int> & path, int pos) {
    if (pos <= 0) pos++;
    // Verifico se il nodo è adiacente al precedente inserito
    int k = path.at(pos - 1) * getNumVertices() + index;
    if (this->adjMatrix.at(k) == false) {
        return false;
    }
  
    // Verifico se il vertice è già stato incluso nel path.
    for (int i = 0; i < pos; i++) {
        if (path.at(i) == index) return false;
    }
    
    // Il vertice dev'essere aggiunto
    return true;
}

bool Graph::hamiltonianCycle(std::vector<int> & path, int pos) {
    // Caso base: se ci sono tutti i vertici nel ciclo
    if (pos == getNumVertices()) {
        // Se c'è un arco dall'ultimo nodo al primo
        if (this->adjMatrix.at(path.at(pos - 1) * getNumVertices() + path.at(0)) == true) {
            return true;
        } else {
            return false;
        }
    }
  
    // Verifico i vertici per aggiungerli eventualmente al ciclo hamiltoniano
    for (int i = 0; i < getNumVertices(); i++) {
        // Verifico se il nodo può essere aggiunto al ciclo
        if (check(i, path, pos)) {
            path.at(pos) = i;
  
            if (hamiltonianCycle(path, pos + 1) == true) return true;
  
            // Backtracking
            path.at(pos) = -1;
        }
    }
    
    return false;
}
