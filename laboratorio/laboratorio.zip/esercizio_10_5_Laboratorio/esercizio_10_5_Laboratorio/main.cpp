//
//  main.cpp
//  esercizio_10_5_Laboratorio
//
//  Created by Denny Caruso on 30/10/2020.
//

/*
    Dato un array di n elementi, trovare il massimo numero di elementi
    distinti dopo aver rimosso k elementi (k<=n)
 */

#include <iostream>
#include <map>
#include <unordered_map>
#include <queue>
//
//int * getMaxDifferentElements(int *arr, int n, int k, int *nMaxDifferentElements);
//int getMaxIndexMap(std::map<int, int>);
//void printArray(int *arr, int n);
//
//int main(int argc, const char * argv[]) {
//    int arr[] = { 5, 4, 4, 3, 4, 6, 4, 2, 2, 2, 1, 1, 1 };
//    int size = sizeof(arr) / sizeof(arr[0]);
//
//    // k <= size
//    int k = 6;
//    int nMaxDifferentElements = 0;
//
//    printArray(arr, size);
//    int *retArr = getMaxDifferentElements(arr, size, k, &nMaxDifferentElements);
//    printArray(retArr, nMaxDifferentElements);
//
//    return 0;
//}
//
//int * getMaxDifferentElements(int *arr, int n, int k, int *nMaxDifferentElements) {
//    std::map<int, int> occourrences;
//
//    if (k > n) return nullptr;
//    for (int i = 0; i < n; i++) occourrences[arr[i]]++;
//
//    for (int i = 0; i < k; i++) {
//        for (auto it = occourrences.begin(); it != occourrences.end(); it++) {
//            std::cout << "CHIAVE: " << it->first << " VALORE: " << it->second << "\n";
//        }
//        std::cout << "\n";
//        int valueWithMostOccurrences = getMaxIndexMap(occourrences);
//        std::cout << "VALUE MOST: " << valueWithMostOccurrences << "\n";
//
//        if (occourrences.find(valueWithMostOccurrences)->second == 1) {
//            break;
//        } else {
//            if (occourrences.find(valueWithMostOccurrences)->second > k) {
//                occourrences.find(valueWithMostOccurrences)->second -= k;
//                break;
//            } else {
//                occourrences.find(valueWithMostOccurrences)->second -= 1;
//            }
//        }
//    }
//
//    int size = 0;
//    for (auto it = occourrences.begin(); it != occourrences.end(); it++) {
//        if (it->second == 1) size++;
//    }
//
//    int *retArray = new int [size], j = 0;
//
//    for (auto it = occourrences.begin(); it != occourrences.end(); it++) {
//        if (it->second == 1) retArray[j++] = it->first;
//    }
//
//    *nMaxDifferentElements = size;
//    return retArray;
//}
//
//int getMaxIndexMap(std::map<int, int> arrayMap) {
//    auto begin = arrayMap.begin();
//    int maxOcc = begin->second;
//    int maxVal = begin->first;
//
//    for (auto i: arrayMap) {
//        if (i.second > maxOcc) {
//            maxOcc = i.second;
//            maxVal = i.first;
//        }
//    }
//
//    return maxVal;
//}
//
//void printArray(int *arr, int n) {
//    for (int i = 0; i < n; i++) std::cout << arr[i] << "\n";
//    std::cout << "\n\n";
//}


//
//
// Approach: Following are the steps:
//
//    Build frequency map
//    Add all no with freq=1 to result and push others to min-Heap.
//    While K > 0, pick a top to reduce by 1 if freq==1 add to results.
//    Otherwise –k and push top-1 to min-heap.
 
 using namespace std;

 // function to find maximum distinct elements
 // after removing k elements
 int maxDistinctNum(int arr[], int n, int k) {
     unordered_map<int, int> numToFreq;
     
     // Build frequency map
     for(int i = 0 ; i < n ; i++) ++numToFreq[ arr[i] ];

     int result = 0;

     // Min-heap
     priority_queue<int, vector<int>, greater<int> > minHeap;
     
     // Add all number with freq=1 to
     // result and push others to minHeap
     for( auto p : numToFreq ) {
         if( p.second == 1 ) {// already distinct
             ++result;
         } else {
             minHeap.push( p.second );
         }
     }
     
     // Perform k operations
     while( k && !minHeap.empty() ) {
         
         // Pop the top() element
         auto t = minHeap.top();
         minHeap.pop();
          
         // Increment Result else Reduce t and k and Push it again
         if( t == 1 ) {
             ++result;
         } else {
             --t;
             --k;
             minHeap.push( t );
         }
     }
     
     while (k > 0) {
         result--;
         k--;
     }

     // Return result
     return result;
 }

 // Driver Code
 int main() {
     int arr[] = { 1, 2, 3, 4, 5, 6, 7 };
     int n = sizeof(arr) / sizeof(arr[0]);
     int k = 3;

     // Function Call
     cout << "Maximum distinct elements = " << maxDistinctNum(arr, n, k) << "\n";
     return 0;
 }

