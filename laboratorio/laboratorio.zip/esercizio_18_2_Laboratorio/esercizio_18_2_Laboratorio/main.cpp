//
//  main.cpp
//  esercizio_18_2_Laboratorio
//
//  Created by Denny Caruso on 27/11/2020.
//

/*
    Implementare l'ordinamento topologico
 */

#include <iostream>
#include "Graph.hpp"

int main(int argc, const char * argv[]) {
    Graph<char> simpleGraph;
    simpleGraph.addNode(new Node<char>('A')); // 0
    simpleGraph.addNode(new Node<char>('B')); // 1
    simpleGraph.addNode(new Node<char>('C')); // 2
    simpleGraph.addNode(new Node<char>('D')); // 3
    simpleGraph.addNode(new Node<char>('E')); // 4
    simpleGraph.addNode(new Node<char>('F')); // 5
    
    simpleGraph.getNodeAtIndex(0)->addEdge(simpleGraph.getNodeAtIndex(1));
    simpleGraph.getNodeAtIndex(1)->addEdge(simpleGraph.getNodeAtIndex(2));
    simpleGraph.getNodeAtIndex(2)->addEdge(simpleGraph.getNodeAtIndex(4));
    simpleGraph.getNodeAtIndex(0)->addEdge(simpleGraph.getNodeAtIndex(4));
    simpleGraph.getNodeAtIndex(2)->addEdge(simpleGraph.getNodeAtIndex(3));
    simpleGraph.getNodeAtIndex(4)->addEdge(simpleGraph.getNodeAtIndex(5));

    simpleGraph.printAdjacentList();
    
//    std::cout << "\nBFS Iterative:\n";
    simpleGraph.BFS_iterative(simpleGraph.getNodeAtIndex(0));
    
//    std::cout << "\nBFS Recursive:\n";
    std::queue<Node<char> *> inputQueue;
    inputQueue.push(simpleGraph.getNodeAtIndex(0));
    simpleGraph.BFS_recursive(&inputQueue);
//    std::cout << "\n\n";
    
//    std::cout << "\nDFS Iterative:\n";
    simpleGraph.DFS_iterative();
    
//    std::cout << "\nDFS Recursive:\n";
    simpleGraph.DFS_recursive();
    
    std::stack<Node<char> *> stackTopologicalOrder = simpleGraph.getTopologicalOrderStack();
    
    return 0;
}
