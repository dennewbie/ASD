//
//  Tester.hpp
//  esercizio_2_Laboratorio
//
//  Created by Denny Caruso on 02/10/2020.
//

#include <iostream>
#include <fstream>
#include <string>
#include <vector>

class Tester {
private:
    std::fstream problemInputFileStream;
    std::fstream solutionInputFileStream;
    std::fstream resultOutputFileStream;
    std::string problemFileName;
    std::string solutionFileName;
    std::string resultFileName;
    
protected:
    
    void openAllStreams(std::string, std::string, std::string);
    int getNumberOfLines(std::fstream &fileStream);
    
    int countCharactersRow(std::fstream &fileStream);
    void checkRow(int);
    std::string getRow(std::fstream &fileStream);
    
    void setPositionInFile(int, std::fstream &fileStream);
    void writeToOutputFile(char const *, std::fstream &fileStream);
    
public:
    Tester(std::string problemString, std::string solutionString, std::string resultString);
    ~Tester(){
        closeAllStreams();
    };
    
    
    void check();
    bool checkFileStream(std::fstream &fileStream);
    void closeAllStreams();
};
