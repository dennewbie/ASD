//
//  main.cpp
//  esercizio_2_Laboratorio
//
//  Created by Denny Caruso on 02/10/2020.
//

#include "Tester.hpp"

int main(int argc, const char * argv[]) {
    std::string problem = "problema.txt";
    std::string solution = "soluzione.txt";
    std::string result = "esito.txt";
    
    Tester tester(problem, solution, result);
    tester.check();
    return 0;
}
