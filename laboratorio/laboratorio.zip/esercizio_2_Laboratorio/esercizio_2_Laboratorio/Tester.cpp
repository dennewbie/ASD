//
//  Tester.cpp
//  esercizio_2_Laboratorio
//
//  Created by Denny Caruso on 02/10/2020.
//

#include "Tester.hpp"

Tester::Tester(std::string problemString, std::string solutionString, std::string resultString){
    this->problemFileName = problemString;
    this->solutionFileName = solutionString;
    this->resultFileName = resultString;
    
    openAllStreams(problemString, solutionString, resultString);
}

bool Tester::checkFileStream(std::fstream &fileStream) {
    return fileStream.fail();
}

void Tester::openAllStreams(std::string problemString, std::string solutionString, std::string resultString) {
    problemInputFileStream.open(problemString.c_str(), std::ios::in);
    solutionInputFileStream.open(solutionString.c_str(), std::ios::in);
    resultOutputFileStream.open(resultString.c_str(), std::ios::out);
    
    if (checkFileStream(problemInputFileStream)) std::cout << "Error while opening Input stream ..." << std::endl;
    if (checkFileStream(solutionInputFileStream)) std::cout << "Error while opening Input stream ..." << std::endl;
    if (checkFileStream(resultOutputFileStream)) std::cout << "Error while opening Output stream ..." << std::endl;
}

void Tester::check() {
    char const *wrongMessage = "Sbagliata\n";
    int nRowProblemFile = getNumberOfLines(this->problemInputFileStream);
    int nRowSolutionFile = getNumberOfLines(this->solutionInputFileStream);
    
    if (nRowProblemFile != nRowSolutionFile) {
        writeToOutputFile(wrongMessage, this->resultOutputFileStream);
    } else {
        closeAllStreams();
        openAllStreams(problemFileName, solutionFileName, resultFileName);
        for (int i = 0; i < nRowProblemFile; i++) checkRow(i);
    }
}

void Tester::checkRow(int rowIndex) {
    char const *wrongMessage = "Sbagliata\n", *successfulMessage = "Corretta\n";
    int nCharProblemFile = countCharactersRow(this->problemInputFileStream);
    int nCharSolutionFile = countCharactersRow(this->solutionInputFileStream);
    std::string rowProblem, rowSolution;
    
    setPositionInFile(rowIndex, this->problemInputFileStream);
    setPositionInFile(rowIndex, this->solutionInputFileStream);
    
    //Controllo numero caratteri nella riga
    if (nCharSolutionFile != (nCharProblemFile * 2) + 1) {
        writeToOutputFile(wrongMessage, this->resultOutputFileStream);
        return;
    } else {
        rowProblem = getRow(this->problemInputFileStream);
        rowSolution = getRow(this->solutionInputFileStream);

        //controllo esattezza segni di disuguaglianza nei 2 file
        for (int i = 0; i < rowProblem.length(); i++) {
            if (rowProblem.at(i) != rowSolution.at((i * 2) + 1)) {
                writeToOutputFile(wrongMessage, this->resultOutputFileStream);
                return;
            }
        }
        
        //Numeri da 1 a 9 MAX
        //Salvare i numeri
        std::vector<int> numbersArray(rowProblem.length() + 1);
        for (int i = 0; i < rowProblem.length() + 1; i++) {
            numbersArray[i] = (rowSolution[i * 2]);
            numbersArray[i] -= 48;
        }
        
        //Ordinamento numeri
        std::vector<int> numbersArrayCopy = numbersArray;
        std::sort(numbersArrayCopy.begin(), numbersArrayCopy.end());
        
        //Verificare che i numeri siano da 1 a N
        for (int i = 0; i < numbersArrayCopy.size(); i++) {
            if (i + 1 != numbersArrayCopy[i]) {
                writeToOutputFile(wrongMessage, this->resultOutputFileStream);
                return;
            }
        }
        
        //Verifica tutte le disugualianze
        for (int i = 0; i < rowProblem.length(); i++) {
            if (rowProblem[i] == '<') {
                if (!(numbersArray[i] < numbersArray[i + 1])) {
                    writeToOutputFile(wrongMessage, this->resultOutputFileStream);
                    return;
                }
            } else if (rowProblem[i] == '>') {
                if (!(numbersArray[i] > numbersArray[i + 1])) {
                    writeToOutputFile(wrongMessage, this->resultOutputFileStream);
                    return;
                }
            } else {
                writeToOutputFile(wrongMessage, this->resultOutputFileStream);
                return;
            }
        }
        
        writeToOutputFile(successfulMessage, this->resultOutputFileStream);
    }
}

int Tester::getNumberOfLines(std::fstream &fileStream) {
    int counter = 0;
    std::string row;
    while (getline(fileStream, row)) counter++;
    
    fileStream.seekg(std::ios_base::beg);
    return counter;
}

int Tester::countCharactersRow(std::fstream &fileStream) {
    int counter = 0;
    std::string row;
    getline(fileStream, row);
    
    while(row[counter] != '\0') counter++;
    fileStream.seekg(std::ios_base::beg);
    return counter;
}

void Tester::setPositionInFile(int nRows, std::fstream &fileStream) {
    std::string row;
    for (int i = 0; i < nRows; i++) getline(fileStream, row);
}

void Tester::writeToOutputFile(char const *message, std::fstream &fileStream) {
    fileStream << message;
}

std::string Tester::getRow(std::fstream &fileStream) {
    std::string row;
    getline(fileStream, row);
    fileStream.seekg(std::ios_base::beg);
    return row;
}

void Tester::closeAllStreams() {
    this->problemInputFileStream.close();
    this->solutionInputFileStream.close();
    this->resultOutputFileStream.close();
}
