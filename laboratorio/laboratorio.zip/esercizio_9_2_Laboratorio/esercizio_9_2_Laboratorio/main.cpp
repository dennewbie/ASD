//
//  main.cpp
//  esercizio_9_2_Laboratorio
//
//  Created by Denny Caruso on 26/10/2020.
//

/*
    Progettare ed implementare una algoritmo che, dato un Min-Heap ed un valore X,
    stampi la somma dei valori dei nodi minori di X.
 
    Es.: X=8 -> S=13
 */

#include <iostream>
#include "MinHeap.hpp"

template <class T> int sumElementsLessOfX(MinHeap<T> heap, int i, int x);

int main(int argc, const char * argv[]) {
    std::vector<int> testArray { 100, 25, 7, 36, 19, 17, 2, 1, 3 };
    MinHeap<int> integerHeap = MinHeap<int>(testArray);

    integerHeap.printHeap();
    integerHeap.buildMinHeap();
    integerHeap.printHeap();
    
    int sum = integerHeap.sumElementsLessOfX(0, 8);
    std::cout << sum << "\n";
    
    return 0;
}
