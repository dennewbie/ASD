//
//  main.cpp
//  esercizio_16_1_Laboratorio
//
//  Created by Denny Caruso on 20/11/2020.
//

/*
    Implementare l'algoritmo per il calcolo della distanza di editing:
        – Valore della soluzione ottima
        – Soluzione ottima
 */

#include <iostream>
#include <sstream>
#include <string>
#include <vector>

template <class T> void printMatrix(std::vector<std::vector<T>>);
bool areEqualThisChar(char c1, char c2);
std::vector<std::vector<int>> calculateEditingDistance(std::string firstString, std::string secondString, std::string * path);

int main(int argc, const char * argv[]) {
//    std::string firstString = "FRANCESCO", secondString = "GIANMATTEO";
    std::string firstString = "TASCA", secondString = "CARTAAA";
    std::string path;
    std::vector<std::vector<int>> matrix = calculateEditingDistance(firstString, secondString, &path);
    
    printMatrix(matrix);
    std::cout << "\nSequenza di operazioni:\n" << path << "\n";
    return 0;
}

std::vector<std::vector<int>> calculateEditingDistance(std::string firstString, std::string secondString, std::string * pathString) {
    auto firstStringLength = firstString.length(), secondStringLength = secondString.length();
    std::vector<std::vector<int>> matrix(firstStringLength + 1, std::vector<int>(secondStringLength + 1, 0));
    std::stringstream path;
    path << "\n";
    
    for (auto j = 1; j <= secondStringLength; j++) matrix.at(0).at(j) = j;
    for (auto i = 1; i <= firstStringLength; i++) matrix.at(i).at(0) = i;
    
    for (auto i = 1; i <= firstStringLength; i++) {
        for (auto j = 1; j <= secondStringLength; j++) {
            if (areEqualThisChar(firstString.at(i - 1), secondString.at(j - 1))) {
                matrix.at(i).at(j) = matrix.at(i - 1).at(j - 1);
            } else {
                auto up = matrix.at(i - 1).at(j), left = matrix.at(i).at(j - 1), diag = matrix.at(i - 1).at(j - 1);
                
                auto min = std::min(up, std::min(left, diag));
                matrix.at(i).at(j) = 1 + min;
            }
        }
    }
    
    int i = 0, j = 0;
    for (i = (int) firstStringLength; i > 0; i--) {
        for (j = (int) secondStringLength; j > 0; j--) {
            if (i <= 0) break;
            
            if (areEqualThisChar(firstString.at(i - 1), secondString.at(j - 1))) {
                path << "Nessuna operazione eseguita: " << firstString.at(i - 1) << " == " << secondString.at(j - 1) << "\n";
                i--;
            } else {
                auto up = matrix.at(i - 1).at(j), left = matrix.at(i).at(j - 1), diag = matrix.at(i - 1).at(j - 1);
                auto min = std::min(up, std::min(left, diag));
                
                if (min == up) {
                    path << "Cancello " << firstString.at(i - 1) << "\n";
                    i--;
                    j++;
                } else if (min == left) {
                    path << "Inserisco " << secondString.at(j - 1) << "\n";
                } else {
                    path << "Sostitusico " << firstString.at(i - 1) << " con " << secondString.at(j - 1) << "\n";
                    i--;
                }
            }
        }
    }
    
    if (i >= 0) path << "Cancello " << firstString.at(0) << "\n";
    *pathString = path.str();
    return matrix;
}

bool areEqualThisChar(char c1, char c2) {
    return (c1 == c2) ? true : false;
}

template <class T> void printMatrix(std::vector<std::vector<T>> matrix) {
    auto rows = matrix.size();
    auto cols = matrix.at(0).size();
    
    for (auto i = 0; i < rows; i++) {
        for (auto j = 0; j < cols; j++) std::cout << matrix.at(i).at(j) << "\t\t";
        std::cout << "\n";
    }
}
