//
//  main.cpp
//  esercizio_16_3_Laboratorio
//
//  Created by Denny Caruso on 20/11/2020.
//

/*
    Si consideri un esame con n problemi, ognuno dei quali vale v[i] punti e richiede t[i] minuti per essere risolto.
 
    Trovare un algoritmo che dati v[1,...,n] e t[1,...,n] ed un punteggio minimo V,
    trovi il sottoinsieme dei problemi che richiede il minor tempo possibile e permetta di superare l'esame
 */

#include <iostream>
#include <vector>

using namespace std;

std::vector<std::vector<int>> examZeroOne(std::vector<int>, std::vector<int>, int, std::vector<std::vector<bool>> &solMatrix, int valMax);
template <class T> void printMatrix(vector<vector<T>>);
void showSolution(vector<vector<bool>>, vector<int>, vector<int>, int, int);

int main () {
//    std::vector<int> objValues = {1, 1, 1, 2, 2, 2, 3, 3, 4, 8};
//    std::vector<int> objTime = {2, 2, 2, 3, 3, 3, 4, 4, 5, 8};
//    auto minimumGrade = 18;
//    auto valMaxGrade = 30;
//
    std::vector<int> objValues = {1, 2, 3, 4};
    std::vector<int> objTime = {2, 3, 4, 6 };
    auto minimumGrade = 5;
    auto valMaxGrade = 10;
    
    std::vector<std::vector<bool>> solMatrix(objValues.size() + 1, std::vector<bool>(minimumGrade + 1, 0));
    auto matrix = examZeroOne(objValues, objTime, minimumGrade + 1, solMatrix, valMaxGrade);
    
    std::cout << "Matrice dei possibili esercizi da svolgere\n\n";
    printMatrix(matrix);
    std::cout << "Matrice Bool Soluzione:\n\n";
    printMatrix(solMatrix);
    std::cout << "Esercizi da svolgere\n\n";
    
    showSolution(solMatrix, objTime, objValues, (int) objValues.size(), minimumGrade);
    std::cout << "\nVoto minimo " << minimumGrade << " raggiunto in " << matrix.at(objValues.size()).at(minimumGrade) << " minuti\n\n";
    return 0;
}

std::vector<std::vector<int>> examZeroOne (std::vector<int> objValues, std::vector<int> objTime, int minimumGrade, std::vector<std::vector<bool>> & solMatrix, int valMax) {
    auto n = objValues.size () + 1;
    std::vector<std::vector<int>> matrix(n, std::vector<int> (minimumGrade, 0));
    
    for (auto v = 1; v < minimumGrade; v++) matrix.at(0).at(v) = valMax;
    for (auto i = 1; i < n; i++) {
        for (auto j = 1; j < minimumGrade; j++) {
            if (j < objValues.at(i - 1)) {
                matrix.at(i).at(j) = matrix.at(i - 1).at(j);
                solMatrix.at(i).at(j) = false;
            } else if (matrix.at(i - 1).at(j) < matrix.at(i - 1).at(j - objValues.at(i - 1)) + objTime.at(i - 1)) {
                matrix.at(i).at(j) = matrix.at(i - 1).at(j);
                solMatrix.at(i).at(j) = false;
            } else {
                matrix.at(i).at(j) = matrix.at(i - 1).at(j - objValues.at(i - 1)) + objTime.at(i - 1);
                solMatrix.at(i).at(j) = true;
            }
        }
    }
    std::cout << "COSTRUZIONE:\n";
    printMatrix(matrix);
    std::cout << "\n\n";
    return matrix;
}

template <class T> void printMatrix(vector<vector<T>> matrix) {
    auto rows = matrix.size(), cols = matrix.at(0).size();
    for (auto i = 0; i < rows; i++) {
        for (auto j = 0; j < cols; j++) std::cout << matrix.at(i).at(j) << "\t";
        std::cout << "\n";
    }
    std::cout << "\n\n";
}

void showSolution(vector<vector<bool>> solMatrix, vector<int> objValues, vector<int> objTime, int i, int j) {
    if (i == 0) return;
    
    if (solMatrix.at(i).at(j) == false) {
        std::cout << "Esercizio " << i << " non svolto\n";
        i--;
    } else {
        std::cout << "Esercizio " << i << " svolto, tempo: " << objValues.at(i - 1) << "\n";
        i--;
        j =  j - objTime.at(i);
    }
    showSolution (solMatrix, objValues, objTime, i, j);
}
