//
//  Node.h
//  esercizio_13_1_Laboratorio
//
//  Created by Denny Caruso on 09/11/2020.
//

#ifndef Node_h
#define Node_h

template <class T> class Node {
private:
    int key;
    bool color; //0 black, 1 red
    Node * parent;
    Node * left;
    Node * right;
    T data;
    
public:
    Node() : parent { nullptr }, left { nullptr }, right { nullptr } { }
    
    Node(int key, T data) : parent { nullptr }, left { nullptr }, right { nullptr } {
        this->key = key;
        this->data = data;
    }
    
    int getKey() {
        return this->key;
    }
    
    void setParent(Node *newParent) {
        parent = newParent;
    }
    
    Node * getParent() {
        return this->parent;
    }
    
    void setLeft(Node *newLeft) {
        this->left = newLeft;
    }
    
    Node * getLeft() {
        return this->left;
    }
    
    void setRight(Node *newRight) {
        this->right = newRight;
    }
    
    Node * getRight() {
        return right;
    }
    
    T & getData() {
        return this->data;
    }
    
    virtual ~Node() { }
    
    void setColor(bool newColor);
    bool getColor();
};

template <class T> void Node<T>::setColor(bool newColor) {
    this->color = newColor;
}

template <class T> bool Node<T>::getColor() {
    return this->color;
}


#endif /* Node_h */
