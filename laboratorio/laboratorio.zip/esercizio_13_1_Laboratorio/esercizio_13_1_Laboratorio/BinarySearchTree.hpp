//
//  BinarySearchTree.hpp
//  esercizio_13_1_Laboratorio
//
//  Created by Denny Caruso on 09/11/2020.
//

#ifndef BinarySearchTree_hpp
#define BinarySearchTree_hpp

#include "Node.h"
#include <iostream>

template <class T> class BinarySearchTree {
private:
    Node<T> * root;
    void transplant(Node<T> * to, Node<T> * from);
    
protected:
    void setRoot(Node <T> *newRoot);

    void insertNode(int key, T data);
    void deleteNode(int key);
    
    //internal usage
    Node<T> * getRoot() {
        return root;
    }
    
    Node<T> * getMinimum(Node<T> * current);
    Node<T> * getMaximum(Node<T> * current);
    
    Node<T> * getPredecessor(Node<T> * current);
    Node<T> * getSuccessor(Node<T> * current);
    
    Node<T> * searchNode(int key, Node<T> *current);
    
    unsigned int getHeight(Node<T> * current);
    
public:
    BinarySearchTree() {
        root = nullptr;
    }
    
    virtual ~BinarySearchTree();
    
    void preorderVisit(int key);
    void inorderVisit(int key);
    void postorderVisit(int key);
    
    Node<T> getTreeRoot() {
        return *root;
    }
    
    int getRootKey() {
        return root->getKey();
    }
    
    //for user public usage
    Node<T> getMinimum(int key);
    Node<T> getMaximum(int key);
    
    Node<T> getPredecessor(int key);
    Node<T> getSuccessor(int key);
    
    Node<T> searchNodeWithKey(int key);
};

template <class T> void BinarySearchTree<T>::setRoot(Node<T> *newRoot) {
    this->root = newRoot;
}

template <class T> void BinarySearchTree<T>::transplant(Node<T> * to, Node<T> * from) {
    if (to->getParent() == nullptr) {
        setRoot(from);
    } else if (to == (to->getParent())->getLeft()) {
        (to->getParent())->setLeft(from);
    } else {
        (to->getParent())->setRight(from);
    }

    if (from != nullptr) from->setParent(to->getParent());
}

template <class T> BinarySearchTree<T>::~BinarySearchTree() {
    while (getRoot() != nullptr) deleteNode(getRoot()->getKey());
}

template <class T> void BinarySearchTree<T>::insertNode(int key, T data) {
    Node<T> * nodeToInsert = new Node<T>(key, data);
    Node<T> * parentNode = nullptr;
    Node<T> * currentNode = root;
    
    while (currentNode != nullptr){
        parentNode = currentNode;
        if (nodeToInsert->getKey() < currentNode->getKey()) {
            currentNode = currentNode->getLeft();
        } else {
            currentNode = currentNode->getRight();
        }
    }
    
    nodeToInsert->setParent(parentNode);
    
    if(parentNode == nullptr) {
        root = nodeToInsert;
    } else if (nodeToInsert->getKey() < parentNode->getKey()) {
        parentNode->setLeft(nodeToInsert);
    } else {
        parentNode->setRight(nodeToInsert);
    }
}

template <class T> void BinarySearchTree<T>::deleteNode(int key) {
    Node<T> * nodeToDelete = searchNode(key, getRoot());
    
    if (nodeToDelete == nullptr) return;
    
    if (nodeToDelete->getLeft() == nullptr) {
        transplant(nodeToDelete, nodeToDelete->getRight());
    } else if (nodeToDelete->getRight() == nullptr) {
        transplant(nodeToDelete, nodeToDelete->getLeft());
    } else {
        Node<T> * minimum = getMinimum(nodeToDelete->getRight());
        
        if ((minimum->getParent())->getKey() != nodeToDelete->getKey()) {
            transplant(minimum, minimum->getRight());
            minimum->setRight(nodeToDelete->getRight());
            (minimum->getRight())->setParent(minimum);
        }
        
        transplant(nodeToDelete, minimum);
        minimum->setLeft(nodeToDelete->getLeft());
        (minimum->getLeft())->setParent(minimum);
        
        delete nodeToDelete;
    }
}

template <class T> void BinarySearchTree<T>::preorderVisit(int key) {
    Node<T> * current = searchNode(key, this->getRoot());
    if (current != nullptr) {
        std::cout << current->getKey() << " ";
        if (current->getLeft() != nullptr) preorderVisit(current->getLeft()->getKey());
        if (current->getRight() != nullptr) preorderVisit(current->getRight()->getKey());
    }
}

template <class T> void BinarySearchTree<T>::inorderVisit(int key) {
    Node<T> * current = searchNode(key, this->getRoot());
    if (current != nullptr) {
        if (current->getLeft() != nullptr) inorderVisit(current->getLeft());
        std::cout << current->getKey() << " ";
        if (current->getRight() != nullptr) inorderVisit(current->getRight());
    }
}

template <class T> void BinarySearchTree<T>::postorderVisit(int key) {
    Node<T> * current = searchNode(key, this->getRoot());
    if (current != nullptr) {
        if (current->getLeft() != nullptr) postorderVisit(current->getLeft()->getKey());
        if (current->getRight() != nullptr) postorderVisit(current->getRight()->getKey());
        std::cout << current->getKey() << " ";
    }
}

template <class T> Node<T> * BinarySearchTree<T>::getMinimum(Node<T> * current) {
    while (current->getLeft() != nullptr) current = current->getLeft();
    return current;
}

template <class T> Node<T> * BinarySearchTree<T>::getMaximum(Node<T> * current) {
    while (current->getRight() != nullptr) current = current->getRight();
    return current;
}

template <class T> Node<T> * BinarySearchTree<T>::getPredecessor(Node<T> * current) {
    if (current->getLeft() != nullptr) return getMaximum(current->getLeft());
    
    Node<T> * parentNode = current->getParent();
    while (parentNode != nullptr && current == (parentNode->getLeft())) {
        current = parentNode;
        parentNode = parentNode->getParent();
    }
    
    return parentNode;
}

template <class T> Node<T> * BinarySearchTree<T>::getSuccessor(Node<T> * current) {
    if (current->getRight() != nullptr) return getMinimum(current->getRight());
    
    Node<T> * parentNode = current->getParent();
    while (parentNode != nullptr && current == (parentNode->getRight())) {
        current = parentNode;
        parentNode = parentNode->getParent();
    }
    
    return parentNode;
}

template <class T> Node<T> * BinarySearchTree<T>::searchNode(int key, Node <T> * current) {
    if (current == nullptr || key == current->getKey()) return current;
    if (key < current->getKey()) {
        return searchNode(key, current->getLeft());
    } else {
        return searchNode(key, current->getRight());
    }
}

template <class T> Node<T> BinarySearchTree<T>::getMinimum(int key) {
    Node<T> * current = searchNode(key, this->getRoot());
    
    while (current->getLeft() != nullptr) current = current->getLeft();
    return *current;
}

template <class T> Node<T> BinarySearchTree<T>::getMaximum(int key) {
    Node<T> * current = searchNode(key, this->getRoot());
    
    while (current->getRight() != nullptr) current = current->getRight();
    return *current;
}

template <class T> Node<T> BinarySearchTree<T>::getPredecessor(int key) {
    Node<T> * current = searchNode(key, this->getRoot());
    
    if (current->getLeft() != nullptr) return getMaximum(current->getLeft());
    
    Node<T> * parentNode = current->getParent();
    while (parentNode != nullptr && current == (parentNode->getLeft())) {
        current = parentNode;
        parentNode = parentNode->getParent();
    }
    
    return *parentNode;
}

template <class T> Node<T> BinarySearchTree<T>::getSuccessor(int key) {
    Node<T> * current = searchNode(key, this->getRoot());
    if (current->getRight() != nullptr) return getMinimum(current->getRight());
    
    Node<T> * parentNode = current->getParent();
    while (parentNode != nullptr && current == (parentNode->getRight())) {
        current = parentNode;
        parentNode = parentNode->getParent();
    }
    
    return *parentNode;
}

template <class T> Node<T> BinarySearchTree<T>::searchNodeWithKey(int key) {
    Node<T> * current = searchNode(key, this->getRoot());
    
    if (current == nullptr || key == current->getKey()) return current;
    if (key < current->getKey()) {
        return searchNode(key, current->getLeft());
    } else {
        return searchNode(key, current->getRight());
    }
}

template <class T> unsigned int BinarySearchTree<T>::getHeight(Node<T> * current) {
    if (current == nullptr) return 0;
    
    return 1 + std::max(getHeight(current->getLeft()), getHeight(current->getRight()));
}

#endif /* BinarySearchTree_hpp */
