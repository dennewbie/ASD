//
//  RBTree.hpp
//  esercizio_13_1_Laboratorio
//
//  Created by Denny Caruso on 09/11/2020.
//

#ifndef RBTree_hpp
#define RBTree_hpp

#include "BinarySearchTree.hpp"

template <class T> class RBTree: public BinarySearchTree<T> {
private:
    void leftRotate(Node<T> * current);
    void rightRotate(Node<T> * current);
    Node<T> * nilT;
    
public:
    RBTree() {
        BinarySearchTree<T>();
        this->nilT = new Node<T>();
        (this->nilT)->setColor(false);
        this->nilT = nullptr;
    }
    
    ~RBTree() { }
    void insertNodeRB(int key, T data);
};

template <class T> void RBTree<T>::leftRotate(Node<T> * x) {
    Node<T> * y = x->getRight();
    
    if (y == nilT) return;
    x->setRight(y->getLeft());
    
    if (y->getLeft() != nilT) {
        (y->getLeft())->setParent(x);
    }
    
    y->setParent(x->getParent());
    
    if (x->getParent() == nilT) {
        this->setRoot(y);
    } else if (x == (x->getParent()->getLeft())) {
        (x->getParent())->setLeft(y);
    } else {
        (x->getParent())->setRight(y);
    }
    
    y->setLeft(x);
    x->setParent(y);
}

template <class T> void RBTree<T>::rightRotate(Node<T> * x) {
    Node<T> * y = x->getLeft();
    
    if (y == nilT) return;
    x->setLeft(y->getRight());
    
    if (y->getRight() != nilT) {
        (y->getRight())->setParent(x);
    }
    
    y->setParent(x->getParent());
    
    if (x->getParent() == nilT) {
        this->setRoot(y);
    } else if (x == (x->getParent()->getRight())) {
        (x->getParent())->setRight(y);
    } else {
        (x->getParent())->setLeft(y);
    }
    
    y->setRight(x);
    x->setParent(y);
}

template <class T> void RBTree<T>::insertNodeRB(int key, T data) {
    this->insertNode(key, data);
    Node<T> * x = this->searchNode(key, this->getRoot());
//    x->setLeft(nullptr);
//    x->setRight(nullptr);
    x->setLeft(nilT);
    x->setRight(nilT);
//    (x->getLeft())->setColor(false);
//    (x->getRight())->setColor(false);
    x->setColor(true);
    
    while (x != this->getRoot() && (x->getParent()->getColor() == true)) {
        if (x->getParent() == ((x->getParent())->getParent())->getLeft()) {
            Node<T> * y = ((x->getParent())->getParent())->getRight();
            
            if (y != nilT && y->getColor() == true) {
                (x->getParent())->setColor(false);
                y->setColor(false);
                ((x->getParent())->getParent())->setColor(true);
                x = ((x->getParent())->getParent());
            } else {
                if (x == (x->getParent())->getRight()) {
                    x = x->getParent();
                    leftRotate(x);
                }
                
                (x->getParent())->setColor(false);
                ((x->getParent())->getParent())->setColor(true);
                rightRotate(((x->getParent())->getParent()));
            }
        } else {
            Node<T> * y = ((x->getParent())->getParent())->getLeft();
            
            if (y != nilT && y->getColor() == true) {
                (x->getParent())->setColor(false);
                y->setColor(false);
                ((x->getParent())->getParent())->setColor(true);
                x = ((x->getParent())->getParent());
            } else {
                if (x == (x->getParent())->getLeft()) {
                    x = x->getParent();
                    rightRotate(x);
                }
                
                (x->getParent())->setColor(false);
                ((x->getParent())->getParent())->setColor(true);
                leftRotate(((x->getParent())->getParent()));
            }
        }
    }
    
    (this->getRoot())->setColor(false);
}

#endif /* RBTree_hpp */
