//
//  main.cpp
//  esercizio_13_1_Laboratorio
//
//  Created by Denny Caruso on 09/11/2020.
//

/*
    Progettare ed implementare una classe RBTree derivata dalla classe ABR
    Progettare ed implementare un metodo per inserire un nuovo nodo
 */

#include "RBTree.hpp"
#include "Node.h"

int main(int argc, const char * argv[]) {
    RBTree<float> redBlackTree;
    
    redBlackTree.insertNodeRB(7, 20.0);
    redBlackTree.insertNodeRB(2, 20.0);
    redBlackTree.insertNodeRB(3, 20.0);
    redBlackTree.insertNodeRB(4, 20.0);
    redBlackTree.insertNodeRB(6, 20.0);
    redBlackTree.insertNodeRB(9, 20.0);
    redBlackTree.insertNodeRB(11, 20.0);
    redBlackTree.insertNodeRB(18, 20.0);
    redBlackTree.insertNodeRB(12, 20.0);
    redBlackTree.insertNodeRB(14, 20.0);
    redBlackTree.insertNodeRB(17, 20.0);
    redBlackTree.insertNodeRB(19, 20.0);
    redBlackTree.insertNodeRB(20, 20.0);
    redBlackTree.insertNodeRB(22, 20.0);
    
    std::cout << "PREORDER: \n\n";
    redBlackTree.preorderVisit(redBlackTree.getRootKey());
    std::cout << "\n\n";
    
    Node<float> min = redBlackTree.getMinimum(redBlackTree.getRootKey());
    std::cout << "MIN: " << min.getKey() << "\n";
    
    Node<float> max = redBlackTree.getMaximum(redBlackTree.getRootKey());
    std::cout << "MAX: " << max.getKey() << "\n";
    
    return 0;
}
