//
//  contenitore.cpp
//  esercizio_1_Laboratorio
//
//  Created by Denny Caruso on 28/09/2020.
//

#include "contenitore.hpp"

void Contenitore::versa(float litri) {
    //fare controllo massima eccedenza
    this->qt += litri;
}

void Contenitore::togli(float litri) {
    this->qt = this->getQt() - litri < 0.00 ? 0.00 : litri;
}

bool Anfora::isPiena() {
    return (this->getCapacita() == this->getQt());
}

bool Anfora::isVuota() {
    return (this->getQt() == 0);
}

void Anfora::riempi() {
    this->versa(this->getCapacita() - this->getQt());
}

void Anfora::svuota() {
    this->togli(this->getQt());
}

void Anfora::spostaContenuto(Anfora &anforaDoveSpostareIlContenuto) {
    if (!isVuota()) {
        if (!anforaDoveSpostareIlContenuto.isPiena()) {
            float litriSpostati = anforaDoveSpostareIlContenuto.getCapacita() - anforaDoveSpostareIlContenuto.getQt();
            if (litriSpostati > getQt()) litriSpostati = getQt();
            
            anforaDoveSpostareIlContenuto.versa(litriSpostati);
            togli(litriSpostati);
        }
    }
}
