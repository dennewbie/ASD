//
//  main.cpp
//  esercizio_7_2_Laboratorio
//
//  Created by Denny Caruso on 19/10/2020.
//

/*
    Progettare ed implementare una procedura Merge ricorsiva
 */

#include <iostream>

//void mergeSort(int *arr, int low, int high);
void merge(int *arr1, int *arr2, int *arr3, int nElemSx, int nElemDx);
void copyPaste(int *arr1, int *arr2, int size);
void printArray(int *arr, int size);

int main(int argc, const char * argv[]) {
    int arr[] = { 10, 12, 14, 16, 11, 13, 15, 17 };
    int size = (sizeof(arr) / sizeof(arr[0])), center = size / 2;
    int *resultArray = new int[size];

    merge(arr, arr + center, resultArray, center, (size - center));
    copyPaste(arr, resultArray, size);
    delete [] resultArray;
    
    printArray(arr, size);
    return 0;
}

void merge(int *firstArray, int *secondArray, int *outputArray, int nElementFirstArray, int nElementSecondArray) {
    if (nElementFirstArray > 0 && nElementSecondArray > 0) {
        if (firstArray[0] < secondArray[0]) {
            outputArray[0] = firstArray[0];
            merge(firstArray + 1, secondArray, outputArray + 1, nElementFirstArray - 1, nElementSecondArray);
        } else {
            outputArray[0] = secondArray[0];
            merge(firstArray, secondArray + 1, outputArray + 1, nElementFirstArray, nElementSecondArray - 1);
        }
    } else if (nElementFirstArray > 0) {
        outputArray[0] = firstArray[0];
        merge(firstArray + 1, secondArray, outputArray + 1, nElementFirstArray - 1, nElementSecondArray);
    } else if (nElementSecondArray > 0) {
        outputArray[0] = secondArray[0];
        merge(firstArray, secondArray + 1, outputArray + 1, nElementFirstArray, nElementSecondArray - 1);
    }
}

void copyPaste(int *arr1, int *arr2, int size) {
    for (int i = 0; i < size; i++) arr1[i] = arr2[i];
}

void printArray(int *arr, int size) {
    std::cout << "\n----------\n";
    for (int i = 0; i < size; i++) std::cout << arr[i] << "\n";
    std::cout << "\n----------\n";
}

//
//void mergeSort(int *arr, int low, int high) {
//    if (low < high) {
//        int mid = (low + high) / 2;
//        mergeSort(arr, low, mid);
//        mergeSort(arr, mid + 1, high);
//
//        int *resultArray = new int[high - low + 1];
//
//        std::cout << "LOW: " << low << " MID: " << mid << " HIGH: " << high << "\n";
////        merge(arr, arr + mid + 1, resultArray, mid + 1, high - mid + 1);
//        merge(arr, arr + mid + 1, resultArray, mid + 1, high - mid);
//        copyPaste(arr, resultArray, high - low + 1);
//        printArray(arr, high - low + 1);
//    }
//}
