//
//  HashTable.cpp
//  esercizio_22_1_1_Laboratorio
//
//  Created by Denny Caruso on 12/12/2020.
//

#include "HashTable.hpp"

unsigned int HashTable::hashFunctionDivsion(int key) {
    return (key % getDim());
}

unsigned int HashTable::hashFunctionMultiplication(int key) {
    unsigned int unsignedKey = (unsigned int) key;
    double value = unsignedKey * knutSuggestion;
    return (floor(getDim() * fmod(value, 1.0)));
}

void HashTable::setDim(unsigned int newDim) {
    this->dim = newDim;
}

void HashTable::setTable(std::vector<std::list<int>> newTable) {
    this->table = newTable;
}

unsigned int HashTable::getDim() {
    return this->dim;
}

std::vector<std::list<int>> HashTable::getTable() {
    return this->table;
}

void HashTable::hashInsert(int key) {
    auto index = hashFunctionDivsion(key);
//    auto index = hashFunctionMultiplication(key);
    table.at(index).push_front(key);
}

void HashTable::hashDelete(int key) {
    auto index = hashFunctionDivsion(key);
//    auto index = hashFunctionMultiplication(key);
    auto it = table.at(index).begin();
    
    for (it = table.at(index).begin(); it != table.at(index).end(); it++) {
        if (*it == key) break;
    }
    
    if (it != table.at(index).end()) {
        table.at(index).erase(it);
    }
}

bool HashTable::hashSearch(int key) {
    auto index = hashFunctionDivsion(key);
//    auto index = hashFunctionMultiplication(key);
    
    for (auto it = table.at(index).begin(); it != table.at(index).end(); it++) {
        if (*it == key) return true;
    }
    
    return false;
}

void HashTable::displayHash() {
    std::cout << "\n";
    for (auto i = 0; i < getDim(); i++) {
        std::cout << i;
        for (auto x: table.at(i)) std::cout << " --> " << x;
        
        std::cout << "\n";
    }
    std::cout << "\n";
}

bool HashTable::containsThisMap(HashTable anotherMap) {
    for (auto & singleList: anotherMap.table) {
        if (singleList.size() > 0) {
            for (auto & singleNodeList: singleList) {
                if (!hashSearch(singleNodeList) == false) return false;
            }
        }
    }
    
    return true;
}

