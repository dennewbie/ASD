//
//  main.cpp
//  esercizio_22_3_Laboratorio
//
//  Created by Denny Caruso on 12/12/2020.
//

/*
    Verificare se due insiemi sono disgiunti
 */

#include "HashTable.hpp"

int main(int argc, const char * argv[]) {
    int arr_1[] = { 15, 11, 27, 8, 12, 20 };
    int arrSize_1 = sizeof(arr_1) / sizeof(arr_1[0]);
    
    int arr_2[] = { 1, 2, 3 };
    int arrSize_2 = sizeof(arr_2) / sizeof(arr_2[0]);
    
    HashTable simpleHashTable_1(7);
    for (auto i = 0; i < arrSize_1; i++) simpleHashTable_1.hashInsert(arr_1[i]);
    simpleHashTable_1.displayHash();
    
    HashTable simpleHashTable_2(4);
    for (auto i = 0; i < arrSize_2; i++) simpleHashTable_2.hashInsert(arr_2[i]);
    simpleHashTable_2.displayHash();
    
    
    bool result = simpleHashTable_1.containsThisMap(simpleHashTable_2);
    std::cout << std::boolalpha << "\nFirst map contains second? " << result << "\n\n";
    return 0;
}
