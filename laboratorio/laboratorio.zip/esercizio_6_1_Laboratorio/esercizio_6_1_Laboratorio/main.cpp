//
//  main.cpp
//  esercizio_6_1_Laboratorio
//
//  Created by Denny Caruso on 15/10/2020.
//

/*
    Dato un insieme di N numeri, trovare il k-esimo numero più grande
 */

#include <iostream>

void insertionSort(int *, int);
int get_kMaxElement(int *, int);

int main(int argc, const char * argv[]) {
    int array[] = { 100, 30, 130, 50, 1 , 20, 10, 11, 13 };
    int size = ( sizeof(array) / sizeof(array[0]) );
    insertionSort(array, size);
    
    int kElement = 9;
    
    if (kElement <= size) {
        int kMaxElement = get_kMaxElement(array, kElement - 1);
        std::cout << "Il k-esimo numero più grande con k = " << kElement << " è: " << kMaxElement << std::endl;
    } else {
        std::cout << "K > size array" << std::endl;
    }
    return 0;
}

void insertionSort(int *arr, int size) {
    int i, key, j;
    for (i = 1; i < size; i++) {
        key = arr[i];
        j = i - 1;

        while (j >= 0 && arr[j] > key) {
            arr[j + 1] = arr[j];
            j--;
        }
        arr[j + 1] = key;
    }
}

int get_kMaxElement(int *array, int k) {
    return array[k];
}
