//
//  main.cpp
//  esercizio_10_3_Laboratorio
//
//  Created by Denny Caruso on 30/10/2020.
//

/*
    Scrivere una procedura per convertire un min-heap in max-heap
 */

#include "MinHeap.hpp"

int main(int argc, const char * argv[]) {
    std::vector<int> testArray { 10, 1, 50, 80, 90, 100, 12, 23, 30, 11, 4, 1, 2 };
    MinHeap<int> integerHeap = MinHeap<int>(testArray);
    
    integerHeap.buildMinHeap();
    integerHeap.printHeap();
    integerHeap.convertToMaxHeap();
    integerHeap.printArray();
    return 0;
}
