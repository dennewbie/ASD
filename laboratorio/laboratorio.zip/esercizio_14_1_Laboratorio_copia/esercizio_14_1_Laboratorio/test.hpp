//
//  test.hpp
//  esercizio_14_1_Laboratorio
//
//  Created by Denny Caruso on 18/01/21.
//

#ifndef test_hpp
#define test_hpp

#include "RBTree.hpp"

template <class T> class test: private RBTree<T> {
public:
    void foo() {
        
        
    }
};

#endif /* test_hpp */
