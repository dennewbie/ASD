//
//  RBTree.hpp
//  esercizio_14_1_Laboratorio
//
//  Created by Denny Caruso on 14/11/2020.
//

#ifndef RBTree_hpp
#define RBTree_hpp

#include "BinarySearchTree.hpp"

template <class T> class RBTree: public BinarySearchTree<T> {
private:
    void leftRotate(Node<T> * current);
    void rightRotate(Node<T> * current);
    
    void transplantRB(Node<T> * to, Node<T> * from);
    void deleteFixupRB(Node<T> * x);
    
public:
    RBTree() {
        BinarySearchTree<T>();
    }
    
    ~RBTree() { }
    void insertNodeRB(int key, T data);
    void deleteNodeRB(int key);
};

template <class T> void RBTree<T>::leftRotate(Node<T> * x) {
    Node <T> * y= x->getRight();
    x->setRight(y->getLeft());
    if (y->getLeft() != this->getNilTNode()) y->getLeft()->setParent(x);
    
    y->setParent(x->getParent());
    if (x->getParent() == nullptr) {
        this->setRoot(y);
    } else if (x == (x->getParent()->getLeft())){
        x->getParent()->setLeft(y);
    } else {
        x->getParent()->setRight(y);
    }
    y->setLeft(x);
    x->setParent(y);
}

template <class T> void RBTree<T>::rightRotate(Node<T> * x) {
    Node <T> *y = x->getLeft();
    x->setLeft(y->getRight());
    if (y->getRight() != this->getNilTNode()) y->getRight()->setParent(x);
    
    y->setParent(x->getParent());
    if (x->getParent() == nullptr){
        this->setRoot(y);
    } else if (x == x->getParent()->getLeft()){
        x->getParent()->setLeft(y);
    } else {
        x->getParent()->setRight(y);
    }
    y->setRight(x);
    x->setParent(y);
}

template <class T> void RBTree<T>::insertNodeRB(int key, T data) {
    this->insertNode(key, data);
    Node<T> * x = this->searchNode(key, this->getRoot());
    x->setColor(RED);
    
    while (x != this->getRoot() && (x->getParent()->getColor() == RED)) {
        if (x->getParent() == ((x->getParent())->getParent())->getLeft()) {
            Node<T> * y = ((x->getParent())->getParent())->getRight();
            
            if (y != this->getNilTNode() && y->getColor() == RED) {
                (x->getParent())->setColor(BLACK);
                y->setColor(BLACK);
                ((x->getParent())->getParent())->setColor(RED);
                x = ((x->getParent())->getParent());
            } else {
                if (x == (x->getParent())->getRight()) {
                    x = x->getParent();
                    leftRotate(x);
                }
                
                (x->getParent())->setColor(BLACK);
                ((x->getParent())->getParent())->setColor(RED);
                rightRotate(((x->getParent())->getParent()));
            }
        } else {
            Node<T> * y = ((x->getParent())->getParent())->getLeft();
            
            if (y != this->getNilTNode() && y->getColor() == RED) {
                (x->getParent())->setColor(BLACK);
                y->setColor(BLACK);
                ((x->getParent())->getParent())->setColor(RED);
                x = ((x->getParent())->getParent());
            } else {
                if (x == (x->getParent())->getLeft()) {
                    x = x->getParent();
                    rightRotate(x);
                }
                
                (x->getParent())->setColor(BLACK);
                ((x->getParent())->getParent())->setColor(RED);
                leftRotate(((x->getParent())->getParent()));
            }
        }
    }
    
    (this->getRoot())->setColor(BLACK);
}

template <class T> void RBTree<T>::transplantRB(Node<T> * to, Node<T> * from) {
    if (to->getParent() == this->getNilTNode() || to->getParent() == nullptr) {
        this->setRoot(from);
    } else if (to == (to->getParent())->getLeft()) {
        (to->getParent())->setLeft(from);
    } else {
        (to->getParent())->setRight(from);
    }
    
    from->setParent(to->getParent());
}

template <class T> void RBTree<T>::deleteNodeRB(int key) {
    Node<T> * z = this->searchNode(key, this->getRoot());
    Node<T> * x;
    Node<T> * y;
    bool yOriginalColor;

    y = z;
    yOriginalColor = y->getColor();
    
    if (z->getLeft() == this->getNilTNode()) {
        x = z->getRight();
        transplantRB(z, z->getRight());
    } else if (z->getRight() == this->getNilTNode()) {
        x = z->getLeft();
        transplantRB(z, z->getLeft());
    } else {
        y = this->getMinimum(z->getRight());
        yOriginalColor = y->getColor();
        x = y->getRight();
        
        if (y->getParent() == z) {
            x->setParent(y);
        } else {
            transplantRB(y, y->getRight());
            y->setRight(z->getRight());
            (y->getRight())->setParent(y);
        }
        
        transplantRB(z, y);
        
        y->setLeft(z->getLeft());
        (y->getLeft())->setParent(y);
        y->setColor(z->getColor());
    }
    
    if (yOriginalColor == BLACK) deleteFixupRB(x);
}

template <class T> void RBTree<T>::deleteFixupRB(Node<T> * x) {
    Node <T> * w;
    while (x != this->getRoot() && x->getColor() == BLACK) {
        if (x == (x->getParent())->getLeft()) {
            w = (x->getParent())->getRight();
            
            if (w->getColor() == RED) {
                w->setColor(BLACK);
                (x->getParent())->setColor(RED);
                this->leftRotate(x->getParent());
                w = (x->getParent())->getRight();
            }
            
            if ((w->getLeft())->getColor() == BLACK && (w->getRight())->getColor() == BLACK) {
                w->setColor(RED);
                x = x->getParent();
            } else {
                if ((w->getRight())->getColor() == BLACK) {
                    (w->getLeft())->setColor(BLACK);
                    w->setColor(RED);
                    this->rightRotate(w);
                    w = (x->getParent())->getRight();
                }
                
                w->setColor((x->getParent()->getColor()));
                (x->getParent())->setColor(BLACK);
                (w->getRight())->setColor(BLACK);
                this->leftRotate(x->getParent());
                x = this->getRoot();
            }
        } else {
            w = (x->getParent())->getLeft();
            
            if (w->getColor() == RED) {
                w->setColor(BLACK);
                (x->getParent())->setColor(RED);
                this->rightRotate(x->getParent());
                w = (x->getParent())->getLeft();
            }
            
            if ((w->getRight())->getColor() == BLACK && (w->getLeft())->getColor() == BLACK) {
                w->setColor(RED);
                x = x->getParent();
            } else {
                if ((w->getLeft())->getColor() == BLACK) {
                    (w->getRight())->setColor(BLACK);
                    w->setColor(RED);
                    this->leftRotate(w);
                    w = (x->getParent())->getLeft();
                }
                
                w->setColor((x->getParent()->getColor()));
                (x->getParent())->setColor(BLACK);
                (w->getLeft())->setColor(BLACK);
                this->rightRotate(x->getParent());
                x = this->getRoot();
            }
        }
    }
    x->setColor(BLACK);
}

#endif /* RBTree_hpp */
