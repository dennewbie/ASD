//
//  main.cpp
//  esercizio_14_1_Laboratorio
//
//  Created by Denny Caruso on 14/11/2020.
//

/*
    Progettare ed implementare una classe RBTree derivata dalla classe ABR
    Aggiungere la cancellazione del nodo alla classe RBTree
 */

#include "RBTree.hpp"
#include "Node.h"
#include "test.hpp"

int main(int argc, const char * argv[]) {
    RBTree<float> redBlackTree;
    
    redBlackTree.insertNodeRB(7, 20.0);
    redBlackTree.insertNodeRB(2, 20.0);
    redBlackTree.insertNodeRB(3, 20.0);
    redBlackTree.insertNodeRB(4, 20.0);
    redBlackTree.insertNodeRB(6, 20.0);
    redBlackTree.insertNodeRB(9, 20.0);
    redBlackTree.insertNodeRB(11, 20.0);
    redBlackTree.insertNodeRB(18, 20.0);
    redBlackTree.insertNodeRB(12, 20.0);
    redBlackTree.insertNodeRB(14, 20.0);
    redBlackTree.insertNodeRB(17, 20.0);
    redBlackTree.insertNodeRB(19, 20.0);
    redBlackTree.insertNodeRB(20, 20.0);
    redBlackTree.insertNodeRB(22, 20.0);
    
    std::cout << "PREORDER: \n\n";
    redBlackTree.preorderVisit(redBlackTree.getRootKey());
    std::cout << "\n\n";
    
//    redBlackTree.deleteNodeRB(6);
//    redBlackTree.deleteNodeRB(4);
//    redBlackTree.deleteNodeRB(20);
//    redBlackTree.deleteNodeRB(12);
    std::cout << "\n\nElimino 7...\nElimino 4...\nElimino 20...\nElimino 12...\n\n";
    
    Node<float> min = redBlackTree.getMinimum(redBlackTree.getRootKey());
    std::cout << "MIN: " << min.getKey() << "\n";
    
    Node<float> * max = redBlackTree.getMaximum(redBlackTree.searchNode(7, redBlackTree.getRoot()));
    std::cout << "MAX: " << max->getKey() << "\n";
    
    max->setParent(nullptr);
    max->setColor(RED);
    
    std::cout << "PREORDER: \n\n";
    redBlackTree.preorderVisit(redBlackTree.getRootKey());
    std::cout << "\n\n";
    
    
    test<int> tempTest;
    tempTest.foo();
    return 0;
}
