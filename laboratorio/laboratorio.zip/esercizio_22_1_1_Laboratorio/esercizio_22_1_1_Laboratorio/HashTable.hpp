//
//  HashTable.hpp
//  esercizio_22_1_1_Laboratorio
//
//  Created by Denny Caruso on 12/12/2020.
//

#ifndef HashTable_hpp
#define HashTable_hpp

#include <iostream>
#include <list>
#include <vector>
#define knutSuggestion 0.6180339887

template<typename T> class HashTable {
private:
    unsigned int dim;
    std::vector<std::list<T>> table;
    unsigned int hashFunctionDivsion(T key);
    unsigned int hashFunctionMultiplication(T key);
    
    void setDim(unsigned int newDim);
    void setTable(std::vector<std::list<T>> newTable);
    
    std::vector<std::list<T>> getTable();
    
public:
    HashTable(unsigned int N) {
        setDim(N);
        setTable(std::vector<std::list<T>>(getDim()));
    }
    
    unsigned int getDim();
    
    void hashInsert(T key);
    void hashDelete(T key);
    bool hashSearch(T key);
    void displayHash();
};

template <typename T> unsigned int HashTable<T>::hashFunctionDivsion(T key) {
    return (key % getDim());
}

template <typename T> unsigned int HashTable<T>::hashFunctionMultiplication(T key) {
//    unsigned int unsignedKey = (unsigned int) key;
//    double value = unsignedKey * knutSuggestion;
//    return (floor(getDim() * fmod(value, 1.0)));
    
    double value = key * knutSuggestion;
    return (floor(getDim() * fmod(value, 1.0)));
}

template <typename T> void HashTable<T>::setDim(unsigned int newDim) {
    this->dim = newDim;
}

template <typename T> void HashTable<T>::setTable(std::vector<std::list<T>> newTable) {
    this->table = newTable;
}

template <typename T> unsigned int HashTable<T>::getDim() {
    return this->dim;
}

template <typename T> std::vector<std::list<T>> HashTable<T>::getTable() {
    return this->table;
}

template <typename T> void HashTable<T>::hashInsert(T key) {
    auto index = hashFunctionDivsion(key);
//    auto index = hashFunctionMultiplication(key);
    table.at(index).push_front(key);
}

template <typename T> void HashTable<T>::hashDelete(T key) {
    auto index = hashFunctionDivsion(key);
//    auto index = hashFunctionMultiplication(key);
    auto it = table.at(index).begin();
    
    for (it = table.at(index).begin(); it != table.at(index).end(); it++) {
        if (*it == key) break;
    }
    
    if (it != table.at(index).end()) {
        table.at(index).erase(it);
    }
}

template <typename T> bool HashTable<T>::hashSearch(T key) {
    auto index = hashFunctionDivsion(key);
//    auto index = hashFunctionMultiplication(key);
    
    for (auto it = table.at(index).begin(); it != table.at(index).end(); it++) {
        if (*it == key) return true;
    }
    
    return false;
}

template <typename T> void HashTable<T>::displayHash() {
    std::cout << "\n";
    for (auto i = 0; i < getDim(); i++) {
        std::cout << i;
        for (auto x: table.at(i)) std::cout << " --> " << x;
        
        std::cout << "\n";
    }
    std::cout << "\n";
}

#endif /* HashTable_hpp */
