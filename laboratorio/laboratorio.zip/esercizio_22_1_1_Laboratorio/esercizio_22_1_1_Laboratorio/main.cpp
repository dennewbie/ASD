//
//  main.cpp
//  esercizio_22_1_1_Laboratorio
//
//  Created by Denny Caruso on 12/12/2020.
//

/*
    Implementare una hash map con concatenamento
 */

#include "HashTable.hpp"
#include <string>

int main(int argc, const char * argv[]) {
    // array that contains keys to be mapped
    int arr[] = { 15, 11, 27, 8, 12, 20, 37, 34, 33, 1, 2, -10, -20, 100 };
    int arrSize = sizeof(arr) / sizeof(arr[0]);
    
    HashTable<int> simpleHashTable(7);
    
    for (auto i = 0; i < arrSize; i++) simpleHashTable.hashInsert(arr[i]);
    simpleHashTable.displayHash();
    simpleHashTable.hashDelete(12);
    simpleHashTable.displayHash();
    
    return 0;
}
