//
//  main.cpp
//  esercizio_14_2_Laboratorio
//
//  Created by Denny Caruso on 14/11/2020.
//

/*
    Dato un ABR, trovare la coppia di nodi padre-figlio con la minima differenza tra le chiavi
 */

#include "BinarySearchTree.hpp"

int main(int argc, const char * argv[]) {
    BinarySearchTree<float> binSrchTree;
    binSrchTree.insertNode(50, 1.00);
    binSrchTree.insertNode(30, 2.00);
    binSrchTree.insertNode(80, 3.00);
    binSrchTree.insertNode(10, 4.00);
    binSrchTree.insertNode(40, 5.00);
    binSrchTree.insertNode(60, 6.00);
    binSrchTree.insertNode(90, 7.00);
    binSrchTree.insertNode(55, 8.00);
    binSrchTree.insertNode(65, 9.00);
    
    std::cout << "\n\n";
    binSrchTree.preorderVisit(50);
    std::cout << "\n\n";
    
    int minDiff = (binSrchTree.getRootKey() - binSrchTree.getTreeRoot().getLeft()->getKey());
    Node<float> minNode = Node<float>();
    binSrchTree.lessDifferenceBetweenFatherAndChildNode(50, &minDiff, &minNode);
    
    std::cout << "MIN DIFF: " << minDiff << "\n" << "NODE PARENT: " << minNode.getParent()->getKey() << "\nNODE CHILD: "<< minNode
    .getKey() << "\n";
    return 0;
}
